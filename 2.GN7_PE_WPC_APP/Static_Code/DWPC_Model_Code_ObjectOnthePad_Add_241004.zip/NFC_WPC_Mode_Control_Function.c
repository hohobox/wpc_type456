/*
 * File: NFC_WPC_Mode_Control_Function.c
 *
 * Code generated for Simulink model 'App_Model'.
 *
 * Model version                  : 1.622
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Fri Oct  4 15:38:22 2024
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "App_Model_types.h"
#include "NFC_WPC_Mode_Control_Function.h"
#include "rtwtypes.h"
#include "App_Model.h"

/* Named constants for Chart: '<S187>/WPC_Mode_Control' */
#define App_Model_IN_OperationMode_OFF ((uint8)1U)
#define App_Model_IN_OperationMode_ON  ((uint8)2U)

/* Named constants for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
#define A_event_StartTimer_LPCDOffDelay (11)
#define A_event_StartTimer_OffLPCDDelay (15)
#define A_event_StartTimer_PICCOffDelay (17)
#define App_IN_NFCSearchingOffDelay_Off ((uint8)1U)
#define App_M_IN_NFCSearchingTimeout_On ((uint8)2U)
#define App_Mo_IN_NFCTimeOutConfirm_Off ((uint8)1U)
#define App_Mo_IN_PhnLeftChattering_Off ((uint8)1U)
#define App_Mod_IN_NFCTimeOutConfirm_On ((uint8)2U)
#define App_Mod_IN_PICCLPCDOffDelay_Off ((uint8)1U)
#define App_Mod_IN_PhnLeftChattering_On ((uint8)2U)
#define App_Mode_IN_DeviceStateWait_Off ((uint8)1U)
#define App_Mode_IN_PICCLPCDOffDelay_On ((uint8)2U)
#define App_Model_CALL_EVENT_ny        (-1)
#define App_Model_IN_DeviceStateWait_On ((uint8)2U)
#define App_Model_IN_LPCDOffDelay_Off  ((uint8)1U)
#define App_Model_IN_LPCDOffDelay_On   ((uint8)2U)
#define App_Model_IN_OffLPCDDelay_Off  ((uint8)1U)
#define App_Model_IN_OffLPCDDelay_On   ((uint8)2U)
#define App_Model_IN_OperationMode_LPCD ((uint8)1U)
#define App_Model_IN_OperationMode_NFC ((uint8)2U)
#define App_Model_IN_OperationMode_Off ((uint8)3U)
#define App_Model_IN_OperationMode_Picc ((uint8)4U)
#define App_Model_IN_OperationMode_WPC ((uint8)5U)
#define App_Model_IN_PICCOffDelay_Off  ((uint8)1U)
#define App_Model_IN_PICCOffDelay_On   ((uint8)2U)
#define App_Model_IN_PhnLeftHolding_Off ((uint8)1U)
#define App_Model_IN_PhnLeftHolding_On ((uint8)2U)
#define App__IN_NFCSearchingOffDelay_On ((uint8)2U)
#define App__IN_NFCSearchingTimeout_Off ((uint8)1U)
#define event_CancelTimer_LPCDOffDelay (1)
#define event_CancelTimer_NFCSearchingO (2)
#define event_CancelTimer_NFCSearchingT (3)
#define event_CancelTimer_NFCTimeOutCon (4)
#define event_CancelTimer_OffLPCDDelay (5)
#define event_CancelTimer_PICCLPCDOffDe (6)
#define event_CancelTimer_PICCOffDelay (7)
#define event_CancelTimer_PhnLeftChatte (8)
#define event_StartTimer_NFCSearchingOf (12)
#define event_StartTimer_NFCSearchingTi (13)
#define event_StartTimer_NFCTimeOutConf (14)
#define event_StartTimer_PICCLPCDOffDel (16)
#define event_StartTimer_PhnLeftChatter (18)

/* Named constants for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
#define A_IN_NFCSearchingOffDelay_Off_n ((uint8)1U)
#define Ap_IN_NFCSearchingOffDelay_On_k ((uint8)2U)
#define Ap_IN_NFCSearchingTimeout_Off_j ((uint8)1U)
#define App_IN_NFCSearchingTimeout_On_n ((uint8)2U)
#define App_M_IN_NFCTimeOutConfirm_On_h ((uint8)2U)
#define App_M_IN_PICCLPCDOffDelay_Off_l ((uint8)1U)
#define App_M_IN_PhnLeftChattering_On_i ((uint8)2U)
#define App_Mo_IN_DeviceStateWait_Off_h ((uint8)1U)
#define App_Mo_IN_PICCLPCDOffDelay_On_c ((uint8)2U)
#define App_Mod_IN_DeviceStateWait_On_d ((uint8)2U)
#define App_Mod_IN_OperationMode_LPCD_m ((uint8)1U)
#define App_Mod_IN_OperationMode_Picc_o ((uint8)4U)
#define App_Mod_IN_PhnLeftHolding_Off_f ((uint8)1U)
#define App_Mode_IN_OperationMode_NFC_f ((uint8)2U)
#define App_Mode_IN_OperationMode_Off_j ((uint8)3U)
#define App_Mode_IN_OperationMode_WPC_h ((uint8)5U)
#define App_Mode_IN_PhnLeftHolding_On_m ((uint8)2U)
#define App_Model_CALL_EVENT_p         (-1)
#define App_Model_IN_LPCDOffDelay_Off_c ((uint8)1U)
#define App_Model_IN_LPCDOffDelay_On_g ((uint8)2U)
#define App_Model_IN_OffLPCDDelay_On_b ((uint8)2U)
#define App_Model_IN_PICCOffDelay_Off_k ((uint8)1U)
#define App_Model_IN_PICCOffDelay_On_d ((uint8)2U)
#define App__IN_NFCTimeOutConfirm_Off_f ((uint8)1U)
#define App__IN_PhnLeftChattering_Off_c ((uint8)1U)
#define event_CancelTimer_LPCDOffDela_i (1)
#define event_CancelTimer_NFCSearchin_e (2)
#define event_CancelTimer_NFCSearchin_k (3)
#define event_CancelTimer_NFCTimeOutC_g (4)
#define event_CancelTimer_OffLPCDDela_o (5)
#define event_CancelTimer_PICCLPCDOff_k (6)
#define event_CancelTimer_PICCOffDela_h (7)
#define event_CancelTimer_PhnLeftChat_h (8)
#define event_StartTimer_LPCDOffDelay_i (11)
#define event_StartTimer_NFCSearching_c (13)
#define event_StartTimer_NFCSearching_h (12)
#define event_StartTimer_NFCTimeOutCo_i (14)
#define event_StartTimer_OffLPCDDelay_m (15)
#define event_StartTimer_PICCLPCDOffD_f (16)
#define event_StartTimer_PICCOffDelay_b (17)
#define event_StartTimer_PhnLeftChatt_g (18)

/* Forward declaration for local functions */
static void App_Model_NFCTimeOutConfirm(void);
static void App_Model_NFCSearchingOffDelay(void);
static void App_Model_LPCDOffDelay(void);
static void App_Model_NFCSearchingTimeout(void);
static void App_Model_PICCOffDelay(void);
static void A_exit_atomic_OperationMode_NFC(void);
static void App_Mo_NFCSearchingOffDetection(void);
static void App_Model_NFCDetectionCheck(void);
static void enter_atomic_OperationMode_NFC(void);
static void App_Model_LPCDOff_Check(Bool rtu_PreProcessIn_p);
static void enter_atomic_OperationMode_LPCD(Bool rtu_PreProcessIn_p);
static void App_Model_PICCLPCDOffDelay(void);
static void enter_atomic_OperationMode_Picc(void);
static void App_Model_OffLPCDDelay(void);
static void App_Model_OffLPCD_Check(void);
static void App_Model_PhnLeftChattering(void);
static void App_Mode_DrDoorPhnLeftHoldCheck(Bool rtu_PreProcessIn_p, Bool rtu_PreProcessIn_go, C_WPCWarning rtu_PreProcessIn_mc, Bool rtu_PreProcessIn_k);
static void enter_atomic_OperationMode_Off(Bool rtu_PreProcessIn_p, Bool rtu_PreProcessIn_go, C_WPCWarning rtu_PreProcessIn_mc, Bool rtu_PreProcessIn_k);
static void WPC_NFC_Mode_Control_Function_S(LC_IAUWPCNFCcmd rtu_PreProcessIn_c, Bool rtu_PreProcessIn_p, IAU_OwnerPhnRegRVal rtu_PreProcessIn_a, OwnerPairingAdvertisingReq rtu_PreProcessIn_m,
  C_WPCOnOffNvalueSet rtu_PreProcessIn_i, OnThePad rtu_PreProcessIn_ak, Bool rtu_PreProcessIn_e, Bool rtu_PreProcessIn_h, WPCStatus rtu_PreProcessIn_g, Bool rtu_PreProcessIn_go, C_WPCWarning
  rtu_PreProcessIn_mc, Bool rtu_PreProcessIn_k, Bool rtu_PreProcessIn_i2);

/* Forward declaration for local functions */
static void App_Model_NFCTimeOutConfirm_e(void);
static void App_Mode_NFCSearchingOffDelay_p(void);
static void App_Model_LPCDOffDelay_j(void);
static void App_Model_NFCSearchingTimeout_k(void);
static void App_Model_PICCOffDelay_k(void);
static void exit_atomic_OperationMode_NFC_c(void);
static void App__NFCSearchingOffDetection_b(void);
static void App_Model_NFCDetectionCheck_h(void);
static void enter_atomic_OperationMode_NF_k(void);
static void App_Model_LPCDOff_Check_h(Bool rtu_PreProcessIn_c);
static void enter_atomic_OperationMode_LP_c(Bool rtu_PreProcessIn_c);
static void App_Model_PICCLPCDOffDelay_j(void);
static void enter_atomic_OperationMode_Pi_m(void);
static void App_Model_OffLPCDDelay_k(void);
static void App_Model_OffLPCD_Check_p(void);
static void App_Model_PhnLeftChattering_h(void);
static void App_Mo_DrDoorPhnLeftHoldCheck_h(Bool rtu_PreProcessIn_c, Bool rtu_PreProcessIn_cp, C_WPCWarning rtu_PreProcessIn_h, Bool rtu_PreProcessIn_ai);
static void enter_atomic_OperationMode_Of_n(Bool rtu_PreProcessIn_c, Bool rtu_PreProcessIn_cp, C_WPCWarning rtu_PreProcessIn_h, Bool rtu_PreProcessIn_ai);
static void WPC_NFC_Mode_Control_Function_c(Bool rtu_PreProcessIn_c, LC_IAUWPCNFCcmd rtu_PreProcessIn_e, C_WPCOnOffNvalueSet rtu_PreProcessIn_m, IAU_OwnerPhnRegRVal rtu_PreProcessIn_j,
  OwnerPairingAdvertisingReq rtu_PreProcessIn_l, OnThePad rtu_PreProcessIn_b, Bool rtu_PreProcessIn_k, Bool rtu_PreProcessIn_p, WPCStatus rtu_PreProcessIn_mb, Bool rtu_PreProcessIn_cp, C_WPCWarning
  rtu_PreProcessIn_h, Bool rtu_PreProcessIn_ai, Bool rtu_PreProcessIn_hl);

/*
 * Output and update for action system:
 *    '<S181>/WPC_Mode_Control'
 *    '<S361>/WPC_Mode_Control'
 */
void App_Model_WPC_Mode_Control(Bool rtu_R_Local_L_IGN1_IN, C_WPCOnOffNvalueSet rtu_WPCSWOption, Bool rtu_R_Local_sbBatStateFault, WPCStatus *rty_WPC_Status, DW_WPC_Mode_Control_App_Model_T *localDW)
{
  /* Chart: '<S187>/WPC_Mode_Control' */
  if (localDW->is_active_c4_NFC_WPC_Mode_Contr == 0U) {
    localDW->is_active_c4_NFC_WPC_Mode_Contr = 1U;
    localDW->is_WpcNfcModeControl = App_Model_IN_OperationMode_OFF;

    /* SignalConversion generated from: '<S187>/WPC_Status' */
    *rty_WPC_Status = ModeOff;
  } else if (localDW->is_WpcNfcModeControl == App_Model_IN_OperationMode_OFF) {
    /* SignalConversion generated from: '<S187>/WPC_Status' */
    *rty_WPC_Status = ModeOff;

    /* 2. */
    if ((rtu_WPCSWOption == WPC_On) && (rtu_R_Local_L_IGN1_IN == On) && (rtu_R_Local_sbBatStateFault != On)) {
      /* Non_GFS */
      localDW->is_WpcNfcModeControl = App_Model_IN_OperationMode_ON;

      /* SignalConversion generated from: '<S187>/WPC_Status' */
      *rty_WPC_Status = WPCMode;
    }
  } else {
    /* SignalConversion generated from: '<S187>/WPC_Status' */
    /* case IN_OperationMode_ON: */
    *rty_WPC_Status = WPCMode;

    /* 1. */
    if ((rtu_R_Local_L_IGN1_IN == Off) || (rtu_WPCSWOption == WPC_Off) || (rtu_R_Local_sbBatStateFault == On)) {
      /* Non_GFS */
      localDW->is_WpcNfcModeControl = App_Model_IN_OperationMode_OFF;

      /* SignalConversion generated from: '<S187>/WPC_Status' */
      *rty_WPC_Status = ModeOff;
    }
  }

  /* End of Chart: '<S187>/WPC_Mode_Control' */
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_NFCTimeOutConfirm(void)
{
  switch (App_Model_DW.is_NFCTimeOutConfirm_f) {
   case App_Mo_IN_NFCTimeOutConfirm_Off:
    if (App_Model_DW.sfEvent_go == event_StartTimer_NFCTimeOutConf) {
      App_Model_DW.is_NFCTimeOutConfirm_f = App_Mod_IN_NFCTimeOutConfirm_On;
    }
    break;

   case App_Mod_IN_NFCTimeOutConfirm_On:
    {
      switch (App_Model_DW.sfEvent_go) {
       case event_CancelTimer_NFCTimeOutCon:
        App_Model_DW.is_NFCTimeOutConfirm_f = App_Mo_IN_NFCTimeOutConfirm_Off;
        App_Model_DW.Timer_NFCTimeOutConfirm_j = 0U;
        break;

       case event_StartTimer_NFCTimeOutConf:
        App_Model_DW.Timer_NFCTimeOutConfirm_j = 0U;
        App_Model_DW.is_NFCTimeOutConfirm_f = App_Mod_IN_NFCTimeOutConfirm_On;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_NFCTimeOutConfirm_j + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_NFCTimeOutConfirm_j + 1U < App_Model_DW.Timer_NFCTimeOutConfirm_j) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_NFCTimeOutConfirm_j = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_NFCSearchingOffDelay(void)
{
  switch (App_Model_DW.is_NFCSearchingOffDelay_b) {
   case App_IN_NFCSearchingOffDelay_Off:
    if (App_Model_DW.sfEvent_go == event_StartTimer_NFCSearchingOf) {
      App_Model_DW.is_NFCSearchingOffDelay_b = App__IN_NFCSearchingOffDelay_On;
    }
    break;

   case App__IN_NFCSearchingOffDelay_On:
    {
      switch (App_Model_DW.sfEvent_go) {
       case event_CancelTimer_NFCSearchingO:
        App_Model_DW.is_NFCSearchingOffDelay_b = App_IN_NFCSearchingOffDelay_Off;
        App_Model_DW.Timer_NFCSearchingOffDelay_e = 0U;
        break;

       case event_StartTimer_NFCSearchingOf:
        App_Model_DW.Timer_NFCSearchingOffDelay_e = 0U;
        App_Model_DW.is_NFCSearchingOffDelay_b = App__IN_NFCSearchingOffDelay_On;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_NFCSearchingOffDelay_e + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_NFCSearchingOffDelay_e + 1U < App_Model_DW.Timer_NFCSearchingOffDelay_e) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_NFCSearchingOffDelay_e = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_LPCDOffDelay(void)
{
  switch (App_Model_DW.is_LPCDOffDelay_n) {
   case App_Model_IN_LPCDOffDelay_Off:
    if (App_Model_DW.sfEvent_go == A_event_StartTimer_LPCDOffDelay) {
      App_Model_DW.is_LPCDOffDelay_n = App_Model_IN_LPCDOffDelay_On;
      App_Model_DW.b_Timer_LPCDOffDelay_is_Runni_j = true;
    }
    break;

   case App_Model_IN_LPCDOffDelay_On:
    {
      switch (App_Model_DW.sfEvent_go) {
       case event_CancelTimer_LPCDOffDelay:
        App_Model_DW.is_LPCDOffDelay_n = App_Model_IN_LPCDOffDelay_Off;
        App_Model_DW.b_Timer_LPCDOffDelay_is_Runni_j = false;
        App_Model_DW.Timer_LPCDOffDelay_o = 0U;
        break;

       case A_event_StartTimer_LPCDOffDelay:
        App_Model_DW.Timer_LPCDOffDelay_o = 0U;
        App_Model_DW.is_LPCDOffDelay_n = App_Model_IN_LPCDOffDelay_On;
        App_Model_DW.b_Timer_LPCDOffDelay_is_Runni_j = true;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_LPCDOffDelay_o + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_LPCDOffDelay_o + 1U < App_Model_DW.Timer_LPCDOffDelay_o) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_LPCDOffDelay_o = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_NFCSearchingTimeout(void)
{
  switch (App_Model_DW.is_NFCSearchingTimeout_i) {
   case App__IN_NFCSearchingTimeout_Off:
    if (App_Model_DW.sfEvent_go == event_StartTimer_NFCSearchingTi) {
      App_Model_DW.is_NFCSearchingTimeout_i = App_M_IN_NFCSearchingTimeout_On;
    }
    break;

   case App_M_IN_NFCSearchingTimeout_On:
    {
      switch (App_Model_DW.sfEvent_go) {
       case event_CancelTimer_NFCSearchingT:
        App_Model_DW.is_NFCSearchingTimeout_i = App__IN_NFCSearchingTimeout_Off;
        App_Model_DW.Timer_NFCSearchingTimeout_h = 0U;
        break;

       case event_StartTimer_NFCSearchingTi:
        App_Model_DW.Timer_NFCSearchingTimeout_h = 0U;
        App_Model_DW.is_NFCSearchingTimeout_i = App_M_IN_NFCSearchingTimeout_On;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_NFCSearchingTimeout_h + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_NFCSearchingTimeout_h + 1U < App_Model_DW.Timer_NFCSearchingTimeout_h) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_NFCSearchingTimeout_h = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_PICCOffDelay(void)
{
  switch (App_Model_DW.is_PICCOffDelay_k) {
   case App_Model_IN_PICCOffDelay_Off:
    if (App_Model_DW.sfEvent_go == A_event_StartTimer_PICCOffDelay) {
      App_Model_DW.is_PICCOffDelay_k = App_Model_IN_PICCOffDelay_On;
    }
    break;

   case App_Model_IN_PICCOffDelay_On:
    {
      switch (App_Model_DW.sfEvent_go) {
       case event_CancelTimer_PICCOffDelay:
        App_Model_DW.is_PICCOffDelay_k = App_Model_IN_PICCOffDelay_Off;
        App_Model_DW.Timer_PICCOffDelay_g = 0U;
        break;

       case A_event_StartTimer_PICCOffDelay:
        App_Model_DW.Timer_PICCOffDelay_g = 0U;
        App_Model_DW.is_PICCOffDelay_k = App_Model_IN_PICCOffDelay_On;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_PICCOffDelay_g + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_PICCOffDelay_g + 1U < App_Model_DW.Timer_PICCOffDelay_g) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_PICCOffDelay_g = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void A_exit_atomic_OperationMode_NFC(void)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_go;
  App_Model_DW.sfEvent_go = event_CancelTimer_NFCTimeOutCon;
  if (App_Model_DW.is_active_NFCTimeOutConfirm_k != 0U) {
    App_Model_NFCTimeOutConfirm();
  }

  App_Model_DW.sfEvent_go = event_CancelTimer_NFCSearchingO;
  if (App_Model_DW.is_active_NFCSearchingOffDela_g != 0U) {
    App_Model_NFCSearchingOffDelay();
  }

  App_Model_DW.sfEvent_go = event_CancelTimer_NFCSearchingT;
  if (App_Model_DW.is_active_NFCSearchingTimeout_j != 0U) {
    App_Model_NFCSearchingTimeout();
  }

  App_Model_DW.sfEvent_go = b_previousEvent;
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Mo_NFCSearchingOffDetection(void)
{
  if ((App_Model_DW.Input_IAUWPCNFCcmd_1_prev_o != App_Model_DW.Input_IAUWPCNFCcmd_1_start_c) && (App_Model_DW.Input_IAUWPCNFCcmd_1_start_c == WPCNFCDeselect_Stop)) {
    sint32 c_previousEvent;
    c_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_StartTimer_NFCSearchingOf;
    if (App_Model_DW.is_active_NFCSearchingOffDela_g != 0U) {
      App_Model_NFCSearchingOffDelay();
    }

    App_Model_DW.sfEvent_go = c_previousEvent;
  } else if ((App_Model_DW.Input_IAUWPCNFCcmd_1_prev_o != App_Model_DW.Input_IAUWPCNFCcmd_1_start_c) && (App_Model_DW.Input_IAUWPCNFCcmd_1_start_c == WPCNFCPolling_Search)) {
    sint32 c_previousEvent;
    c_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_CancelTimer_NFCSearchingO;
    if (App_Model_DW.is_active_NFCSearchingOffDela_g != 0U) {
      App_Model_NFCSearchingOffDelay();
    }

    App_Model_DW.sfEvent_go = c_previousEvent;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_NFCDetectionCheck(void)
{
  /* hasChangedTo(Receive_Flag_NFCDetection, On) ||... */
  if (((App_Model_DW.INT_NFCDetectOrder_prev_k != App_Model_DW.INT_NFCDetectOrder_start_b) && (App_Model_DW.INT_NFCDetectOrder_start_b == 1)) || ((App_Model_DW.Input_IAUWPCNFCcmd_1_prev_o !=
        App_Model_DW.Input_IAUWPCNFCcmd_1_start_c) && (App_Model_DW.Input_IAUWPCNFCcmd_1_start_c == WPCNFCPolling_Search))) {
    sint32 b_previousEvent;
    b_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_CancelTimer_NFCSearchingT;
    if (App_Model_DW.is_active_NFCSearchingTimeout_j != 0U) {
      App_Model_NFCSearchingTimeout();
    }

    App_Model_DW.sfEvent_go = b_previousEvent;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void enter_atomic_OperationMode_NFC(void)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_go;
  App_Model_DW.sfEvent_go = event_StartTimer_NFCTimeOutConf;
  if (App_Model_DW.is_active_NFCTimeOutConfirm_k != 0U) {
    App_Model_NFCTimeOutConfirm();
  }

  App_Model_DW.sfEvent_go = event_StartTimer_NFCSearchingTi;
  if (App_Model_DW.is_active_NFCSearchingTimeout_j != 0U) {
    App_Model_NFCSearchingTimeout();
  }

  App_Model_DW.sfEvent_go = b_previousEvent;
  App_Mo_NFCSearchingOffDetection();
  App_Model_NFCDetectionCheck();
  App_Model_B.Output_OPT_WPCStatus_a = NFCMode;
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_LPCDOff_Check(Bool rtu_PreProcessIn_p)
{
  if ((rtu_PreProcessIn_p == Off) && (!App_Model_DW.b_Timer_LPCDOffDelay_is_Runni_j)) {
    sint32 c_previousEvent;
    c_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = A_event_StartTimer_LPCDOffDelay;
    if (App_Model_DW.is_active_LPCDOffDelay_e != 0U) {
      App_Model_LPCDOffDelay();
    }

    App_Model_DW.sfEvent_go = c_previousEvent;
  } else if (rtu_PreProcessIn_p == On) {
    sint32 c_previousEvent;
    c_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_CancelTimer_LPCDOffDelay;
    if (App_Model_DW.is_active_LPCDOffDelay_e != 0U) {
      App_Model_LPCDOffDelay();
    }

    App_Model_DW.sfEvent_go = c_previousEvent;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void enter_atomic_OperationMode_LPCD(Bool rtu_PreProcessIn_p)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_go;
  App_Model_DW.sfEvent_go = event_CancelTimer_NFCTimeOutCon;
  if (App_Model_DW.is_active_NFCTimeOutConfirm_k != 0U) {
    App_Model_NFCTimeOutConfirm();
  }

  App_Model_DW.sfEvent_go = event_CancelTimer_NFCSearchingO;
  if (App_Model_DW.is_active_NFCSearchingOffDela_g != 0U) {
    App_Model_NFCSearchingOffDelay();
  }

  App_Model_DW.sfEvent_go = event_CancelTimer_LPCDOffDelay;
  if (App_Model_DW.is_active_LPCDOffDelay_e != 0U) {
    App_Model_LPCDOffDelay();
  }

  App_Model_DW.sfEvent_go = b_previousEvent;
  App_Model_B.Output_OPT_WPCStatus_a = LPCDMode;
  App_Model_LPCDOff_Check(rtu_PreProcessIn_p);
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_PICCLPCDOffDelay(void)
{
  switch (App_Model_DW.is_PICCLPCDOffDelay_l) {
   case App_Mod_IN_PICCLPCDOffDelay_Off:
    if (App_Model_DW.sfEvent_go == event_StartTimer_PICCLPCDOffDel) {
      App_Model_DW.is_PICCLPCDOffDelay_l = App_Mode_IN_PICCLPCDOffDelay_On;
    }
    break;

   case App_Mode_IN_PICCLPCDOffDelay_On:
    {
      switch (App_Model_DW.sfEvent_go) {
       case event_CancelTimer_PICCLPCDOffDe:
        App_Model_DW.is_PICCLPCDOffDelay_l = App_Mod_IN_PICCLPCDOffDelay_Off;
        App_Model_DW.Timer_PICCLPCDOffDelay_c = 0U;
        break;

       case event_StartTimer_PICCLPCDOffDel:
        App_Model_DW.Timer_PICCLPCDOffDelay_c = 0U;
        App_Model_DW.is_PICCLPCDOffDelay_l = App_Mode_IN_PICCLPCDOffDelay_On;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_PICCLPCDOffDelay_c + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_PICCLPCDOffDelay_c + 1U < App_Model_DW.Timer_PICCLPCDOffDelay_c) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_PICCLPCDOffDelay_c = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void enter_atomic_OperationMode_Picc(void)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_go;
  App_Model_DW.sfEvent_go = A_event_StartTimer_PICCOffDelay;
  if (App_Model_DW.is_active_PICCOffDelay_o != 0U) {
    App_Model_PICCOffDelay();
  }

  App_Model_DW.sfEvent_go = event_StartTimer_PICCLPCDOffDel;
  if (App_Model_DW.is_active_PICCLPCDOffDelay_d != 0U) {
    App_Model_PICCLPCDOffDelay();
  }

  App_Model_DW.sfEvent_go = b_previousEvent;
  App_Model_B.Output_OPT_WPCStatus_a = PICCMode;
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_OffLPCDDelay(void)
{
  switch (App_Model_DW.is_OffLPCDDelay_e) {
   case App_Model_IN_OffLPCDDelay_Off:
    if (App_Model_DW.sfEvent_go == A_event_StartTimer_OffLPCDDelay) {
      App_Model_DW.is_OffLPCDDelay_e = App_Model_IN_OffLPCDDelay_On;
    }
    break;

   case App_Model_IN_OffLPCDDelay_On:
    {
      switch (App_Model_DW.sfEvent_go) {
       case event_CancelTimer_OffLPCDDelay:
        App_Model_DW.is_OffLPCDDelay_e = App_Model_IN_OffLPCDDelay_Off;
        App_Model_DW.Timer_OffLPCDDelay_i = 0U;
        break;

       case A_event_StartTimer_OffLPCDDelay:
        App_Model_DW.Timer_OffLPCDDelay_i = 0U;
        App_Model_DW.is_OffLPCDDelay_e = App_Model_IN_OffLPCDDelay_On;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_OffLPCDDelay_i + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_OffLPCDDelay_i + 1U < App_Model_DW.Timer_OffLPCDDelay_i) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_OffLPCDDelay_i = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_OffLPCD_Check(void)
{
  if (((App_Model_DW.INT_OPT_WPCStatus_2_prev != App_Model_DW.INT_OPT_WPCStatus_2_start) && (App_Model_DW.INT_OPT_WPCStatus_2_start == PICCMode)) || ((App_Model_DW.INT_OPT_WPCStatus_2_prev !=
        App_Model_DW.INT_OPT_WPCStatus_2_start) && (App_Model_DW.INT_OPT_WPCStatus_2_start == LPCDMode))) {
    sint32 b_previousEvent;
    b_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = A_event_StartTimer_OffLPCDDelay;
    if (App_Model_DW.is_active_OffLPCDDelay_d != 0U) {
      App_Model_OffLPCDDelay();
    }

    App_Model_DW.sfEvent_go = b_previousEvent;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Model_PhnLeftChattering(void)
{
  switch (App_Model_DW.is_PhnLeftChattering_g) {
   case App_Mo_IN_PhnLeftChattering_Off:
    if (App_Model_DW.sfEvent_go == event_StartTimer_PhnLeftChatter) {
      App_Model_DW.is_PhnLeftChattering_g = App_Mod_IN_PhnLeftChattering_On;
      App_Model_DW.b_Timer_PhnLeftChattering_is__j = true;
    }
    break;

   case App_Mod_IN_PhnLeftChattering_On:
    {
      switch (App_Model_DW.sfEvent_go) {
       case event_CancelTimer_PhnLeftChatte:
        App_Model_DW.is_PhnLeftChattering_g = App_Mo_IN_PhnLeftChattering_Off;
        App_Model_DW.b_Timer_PhnLeftChattering_is__j = false;
        App_Model_DW.Timer_PhnLeftChattering_b = 0U;
        break;

       case event_StartTimer_PhnLeftChatter:
        App_Model_DW.Timer_PhnLeftChattering_b = 0U;
        App_Model_DW.is_PhnLeftChattering_g = App_Mod_IN_PhnLeftChattering_On;
        App_Model_DW.b_Timer_PhnLeftChattering_is__j = true;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_PhnLeftChattering_b + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_PhnLeftChattering_b + 1U < App_Model_DW.Timer_PhnLeftChattering_b) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_PhnLeftChattering_b = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void App_Mode_DrDoorPhnLeftHoldCheck(Bool rtu_PreProcessIn_p, Bool rtu_PreProcessIn_go, C_WPCWarning rtu_PreProcessIn_mc, Bool rtu_PreProcessIn_k)
{
  if (((rtu_PreProcessIn_p == Off) && (rtu_PreProcessIn_mc == WPCWarningOff) && (rtu_PreProcessIn_k == Off) && (((App_Model_DW.Input_b_DrvDrSw_prev_h != App_Model_DW.Input_b_DrvDrSw_start_c) &&
         (App_Model_DW.Input_b_DrvDrSw_start_c == On)) || ((App_Model_DW.Input_b_DrvDrSw_prev_h != App_Model_DW.Input_b_DrvDrSw_start_c) && (App_Model_DW.Input_b_DrvDrSw_start_c == Off)))) ||
      ((App_Model_DW.Timer_PhnLeftChattering_b >= 600U) || ((App_Model_DW.Input_PhnLeftChk_Enable_prev_o != App_Model_DW.Input_PhnLeftChk_Enable_start_c) &&
        (App_Model_DW.Input_PhnLeftChk_Enable_start_c == Off)))) {
    sint32 d_previousEvent;
    App_Model_DW.Var_DrDoorPhnLftHoldComplete_n = On;
    d_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_CancelTimer_PhnLeftChatte;
    if (App_Model_DW.is_active_PhnLeftChattering_i != 0U) {
      App_Model_PhnLeftChattering();
    }

    App_Model_DW.sfEvent_go = d_previousEvent;
  } else if ((!App_Model_DW.b_Timer_PhnLeftChattering_is__j) && (rtu_PreProcessIn_p == Off) && (rtu_PreProcessIn_mc == Cellphoneonthepad) && (rtu_PreProcessIn_k == On) && (rtu_PreProcessIn_go == On))
  {
    sint32 d_previousEvent;
    App_Model_DW.Var_DrDoorPhnLftHoldComplete_n = Off;
    d_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_StartTimer_PhnLeftChatter;
    if (App_Model_DW.is_active_PhnLeftChattering_i != 0U) {
      App_Model_PhnLeftChattering();
    }

    App_Model_DW.sfEvent_go = d_previousEvent;
  } else if (rtu_PreProcessIn_p == On) {
    sint32 d_previousEvent;
    App_Model_DW.Var_DrDoorPhnLftHoldComplete_n = Off;
    d_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_CancelTimer_PhnLeftChatte;
    if (App_Model_DW.is_active_PhnLeftChattering_i != 0U) {
      App_Model_PhnLeftChattering();
    }

    App_Model_DW.sfEvent_go = d_previousEvent;
  }
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void enter_atomic_OperationMode_Off(Bool rtu_PreProcessIn_p, Bool rtu_PreProcessIn_go, C_WPCWarning rtu_PreProcessIn_mc, Bool rtu_PreProcessIn_k)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_go;
  App_Model_DW.sfEvent_go = event_CancelTimer_NFCTimeOutCon;
  if (App_Model_DW.is_active_NFCTimeOutConfirm_k != 0U) {
    App_Model_NFCTimeOutConfirm();
  }

  App_Model_DW.sfEvent_go = event_CancelTimer_NFCSearchingO;
  if (App_Model_DW.is_active_NFCSearchingOffDela_g != 0U) {
    App_Model_NFCSearchingOffDelay();
  }

  App_Model_DW.sfEvent_go = event_CancelTimer_LPCDOffDelay;
  if (App_Model_DW.is_active_LPCDOffDelay_e != 0U) {
    App_Model_LPCDOffDelay();
  }

  App_Model_DW.sfEvent_go = event_CancelTimer_PICCOffDelay;
  if (App_Model_DW.is_active_PICCOffDelay_o != 0U) {
    App_Model_PICCOffDelay();
  }

  App_Model_DW.sfEvent_go = b_previousEvent;
  App_Model_B.Output_OPT_WPCStatus_a = ModeOff;

  /* Output_WPC_NFCDetection = NFCDetection_Off; */
  App_Model_OffLPCD_Check();

  /* OffToLPCDforFollow */
  b_previousEvent = App_Model_DW.sfEvent_go;
  App_Model_DW.sfEvent_go = event_CancelTimer_PhnLeftChatte;
  if (App_Model_DW.is_active_PhnLeftChattering_i != 0U) {
    App_Model_PhnLeftChattering();
  }

  App_Model_DW.sfEvent_go = b_previousEvent;
  App_Model_DW.Var_DrDoorPhnLftHoldComplete_n = Off;
  App_Mode_DrDoorPhnLeftHoldCheck(rtu_PreProcessIn_p, rtu_PreProcessIn_go, rtu_PreProcessIn_mc, rtu_PreProcessIn_k);
}

/* Function for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
static void WPC_NFC_Mode_Control_Function_S(LC_IAUWPCNFCcmd rtu_PreProcessIn_c, Bool rtu_PreProcessIn_p, IAU_OwnerPhnRegRVal rtu_PreProcessIn_a, OwnerPairingAdvertisingReq rtu_PreProcessIn_m,
  C_WPCOnOffNvalueSet rtu_PreProcessIn_i, OnThePad rtu_PreProcessIn_ak, Bool rtu_PreProcessIn_e, Bool rtu_PreProcessIn_h, WPCStatus rtu_PreProcessIn_g, Bool rtu_PreProcessIn_go, C_WPCWarning
  rtu_PreProcessIn_mc, Bool rtu_PreProcessIn_k, Bool rtu_PreProcessIn_i2)
{
  sint32 l_previousEvent;
  boolean guard1;
  boolean guard2;
  boolean guard3;
  boolean guard4;
  guard1 = false;
  guard2 = false;
  guard3 = false;
  guard4 = false;
  switch (App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k) {
   case App_Model_IN_OperationMode_LPCD:
    {
      C_WPCOnOffNvalueSet tmp;
      App_Model_B.Output_OPT_WPCStatus_a = LPCDMode;

      /* 1 */
      tmp = App_Model_DW.Input_OPT_WPCSWOption_start_l;
      if (((rtu_PreProcessIn_i == WPC_On) && (rtu_PreProcessIn_p == On) && (rtu_PreProcessIn_c != WPCNFCPolling_Search) && ((rtu_PreProcessIn_a == OwnerPhnReg__Enable) || (rtu_PreProcessIn_m !=
             OwnerPairingAdvertisingReq__StartEnable))) || ((App_Model_DW.Input_OPT_WPCSWOption_prev_o != tmp) && (tmp == WPC_On))) {
        l_previousEvent = App_Model_DW.sfEvent_go;
        App_Model_DW.sfEvent_go = event_CancelTimer_LPCDOffDelay;
        if (App_Model_DW.is_active_LPCDOffDelay_e != 0U) {
          App_Model_LPCDOffDelay();
        }

        App_Model_DW.sfEvent_go = event_CancelTimer_PICCLPCDOffDe;
        if (App_Model_DW.is_active_PICCLPCDOffDelay_d != 0U) {
          App_Model_PICCLPCDOffDelay();
        }

        App_Model_DW.sfEvent_go = l_previousEvent;
        App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_WPC;
        App_Model_B.Output_OPT_WPCStatus_a = WPCMode;

        /* Output_WPC_NFCDetection = NFCDetection_Off; */
      } else {
        LC_IAUWPCNFCcmd tmp_0;

        /* 2 ]%Nidec%SWOff_Devided_240701 */
        tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_2_start_b;
        if ((rtu_PreProcessIn_g == NFCMode) || ((App_Model_DW.INT_LPCDWakeUpOrder_prev_g != App_Model_DW.INT_LPCDWakeUpOrder_start_l) && (App_Model_DW.INT_LPCDWakeUpOrder_start_l == 2)) ||
            ((App_Model_DW.Input_IAUWPCNFCcmd_2_prev_j != tmp_0) && (tmp_0 == WPCNFCPolling_Search)) || ((rtu_PreProcessIn_p == On) && (rtu_PreProcessIn_m != OwnerPairingAdvertisingReq__StartEnable) &&
             (rtu_PreProcessIn_i == WPC_Off) && (rtu_PreProcessIn_g != PICCMode))) {
          /* 240704 */
          /* &&...%Nidec_Prevention of oscillation
             SWOffDevided_ChangePriority_5to3_240701 */
          guard1 = true;
        } else {
          /* 3%Nidec */
          tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_1_start_c;
          if (((App_Model_DW.INT_LPCDWakeUpOrder_prev_g != App_Model_DW.INT_LPCDWakeUpOrder_start_l) && (App_Model_DW.INT_LPCDWakeUpOrder_start_l == 1)) || ((App_Model_DW.Input_IAUWPCNFCcmd_1_prev_o
                != tmp_0) && (tmp_0 == WPCNFCPolling_Search)) || ((App_Model_DW.Input_b_IGN1_IN_prev_l != App_Model_DW.Input_b_IGN1_IN_start_o) && (App_Model_DW.Input_b_IGN1_IN_start_o == On))) {
            /* SWOffDevided_ChangePriority_3to4_240701 */
            l_previousEvent = App_Model_DW.sfEvent_go;
            App_Model_DW.sfEvent_go = event_CancelTimer_LPCDOffDelay;
            if (App_Model_DW.is_active_LPCDOffDelay_e != 0U) {
              App_Model_LPCDOffDelay();
            }

            App_Model_DW.sfEvent_go = event_CancelTimer_PICCLPCDOffDe;
            if (App_Model_DW.is_active_PICCLPCDOffDelay_d != 0U) {
              App_Model_PICCLPCDOffDelay();
            }

            App_Model_DW.sfEvent_go = l_previousEvent;
            App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_NFC;
            enter_atomic_OperationMode_NFC();
          } else {
            WPCStatus tmp_1;

            /* 4 */
            tmp_1 = App_Model_DW.INT_OPT_WPCStatus_2_start;
            if ((rtu_PreProcessIn_p == Off) && ((App_Model_DW.Timer_LPCDOffDelay_o >= 6000U) || (App_Model_DW.Timer_PICCLPCDOffDelay_c >= 6000U) || ((App_Model_DW.INT_OPT_WPCStatus_2_prev != tmp_1) &&
                  (tmp_1 == ModeOff)))) {
              /* Nidec_Simultaneously */
              guard1 = true;
            } else {
              /* Outputs for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' incorporates:
               *  ActionPort: '<S188>/Action Port'
               */
              /* SwitchCase: '<S181>/Switch Case' incorporates:
               *  Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6'
               */
              App_Model_LPCDOff_Check(rtu_PreProcessIn_p);

              /* End of Outputs for SubSystem: '<S181>/WPC_NFCModeControl_compact' */
            }
          }
        }
      }
    }
    break;

   case App_Model_IN_OperationMode_NFC:
    {
      LC_IAUWPCNFCcmd tmp_0;
      App_Model_B.Output_OPT_WPCStatus_a = NFCMode;
      tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_1_start_c;
      if ((App_Model_DW.Input_IAUWPCNFCcmd_1_prev_o != tmp_0) && (tmp_0 == WPCNFCPolling_Search)) {
        A_exit_atomic_OperationMode_NFC();
        App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_NFC;
        enter_atomic_OperationMode_NFC();
      } else {
        /* %WPC2Lead, WPC1Follow or WPC2NFCOnly_Nidec */
        tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_2_start_b;

        /* Outputs for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' incorporates:
         *  ActionPort: '<S188>/Action Port'
         */
        /* SwitchCase: '<S181>/Switch Case' incorporates:
         *  Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6'
         */
        if (((rtu_PreProcessIn_g == NFCMode) && ((App_Model_DW.INT_NFCDetectOrder_prev_k != App_Model_DW.INT_NFCDetectOrder_start_b) && (App_Model_DW.INT_NFCDetectOrder_start_b == 2))) ||
            ((App_Model_DW.Input_IAUWPCNFCcmd_2_prev_j != tmp_0) && (tmp_0 == WPCNFCPolling_Search))) {
          /* 240626InNFC */
          A_exit_atomic_OperationMode_NFC();
          App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_Off;
          enter_atomic_OperationMode_Off(rtu_PreProcessIn_p, rtu_PreProcessIn_go, rtu_PreProcessIn_mc, rtu_PreProcessIn_k);

          /* 20.5s60s */
        } else if ((rtu_PreProcessIn_p == On) && (rtu_PreProcessIn_i == WPC_On) && ((App_Model_DW.Timer_NFCSearchingOffDelay_e >= 50U) || (App_Model_DW.Timer_NFCTimeOutConfirm_j >= 6000U) ||
                    (App_Model_DW.Timer_NFCSearchingTimeout_h >= 150U))) {
          /* 1.5 */
          A_exit_atomic_OperationMode_NFC();
          App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_WPC;
          App_Model_B.Output_OPT_WPCStatus_a = WPCMode;

          /* Output_WPC_NFCDetection = NFCDetection_Off; */

          /* 3. */
        } else if (((rtu_PreProcessIn_p == Off) && (App_Model_DW.Timer_NFCSearchingOffDelay_e >= 50U)) || ((rtu_PreProcessIn_p == On) && (rtu_PreProcessIn_i == WPC_Off) &&
                    (App_Model_DW.Timer_NFCSearchingOffDelay_e >= 50U))) {
          /* 0.5s */
          A_exit_atomic_OperationMode_NFC();
          App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_Picc;
          enter_atomic_OperationMode_Picc();

          /* 4. */
          /* 50.5s60s */
        } else if ((App_Model_DW.Timer_NFCSearchingOffDelay_e >= 50U) || (App_Model_DW.Timer_NFCTimeOutConfirm_j >= 6000U) || (App_Model_DW.Timer_NFCSearchingTimeout_h >= 150U)) {
          /* 1.5 */
          A_exit_atomic_OperationMode_NFC();
          App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_LPCD;
          enter_atomic_OperationMode_LPCD(rtu_PreProcessIn_p);
        } else {
          App_Mo_NFCSearchingOffDetection();
          App_Model_NFCDetectionCheck();
        }

        /* End of Outputs for SubSystem: '<S181>/WPC_NFCModeControl_compact' */
      }
    }
    break;

   case App_Model_IN_OperationMode_Off:
    App_Model_B.Output_OPT_WPCStatus_a = ModeOff;

    /* 1 */
    if ((rtu_PreProcessIn_g == LPCDMode) && (rtu_PreProcessIn_c != WPCNFCPolling_Search) && (App_Model_DW.Timer_OffLPCDDelay_i >= 10U)) {
      /* 0.1sec Hold in Off for tes */
      guard2 = true;
    } else if ((App_Model_DW.INT_OPT_WPCStatus_2_prev != App_Model_DW.INT_OPT_WPCStatus_2_start) && (App_Model_DW.INT_OPT_WPCStatus_2_start == PICCMode)) {
      /* Nidec%PriorityChange5>2_240701 */
      l_previousEvent = App_Model_DW.sfEvent_go;
      App_Model_DW.sfEvent_go = event_CancelTimer_OffLPCDDelay;
      if (App_Model_DW.is_active_OffLPCDDelay_d != 0U) {
        App_Model_OffLPCDDelay();
      }

      App_Model_DW.sfEvent_go = l_previousEvent;
      App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_Picc;
      enter_atomic_OperationMode_Picc();

      /* 2 */
    } else if (((App_Model_DW.Var_DrDoorPhnLftHoldComplete__n != App_Model_DW.Var_DrDoorPhnLftHoldComplete__i) && (App_Model_DW.Var_DrDoorPhnLftHoldComplete__i == On)) || ((rtu_PreProcessIn_p == On) &&
                (rtu_PreProcessIn_m == OwnerPairingAdvertisingReq__StartEnable) && (rtu_PreProcessIn_i == WPC_Off) && (rtu_PreProcessIn_g != WPCMode))) {
      /* Scene#2-0+SWOff_240701 */
      guard2 = true;

      /* Outputs for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' incorporates:
       *  ActionPort: '<S188>/Action Port'
       */
      /* SwitchCase: '<S181>/Switch Case' incorporates:
       *  Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6'
       */
      /* 3
         INT_OPT_WPCStatus_2 != NFCMode &&...240626_PreventSimultaneouslyPolling */
    } else if (rtu_PreProcessIn_c == WPCNFCPolling_Search) {
      l_previousEvent = App_Model_DW.sfEvent_go;
      App_Model_DW.sfEvent_go = event_CancelTimer_OffLPCDDelay;
      if (App_Model_DW.is_active_OffLPCDDelay_d != 0U) {
        App_Model_OffLPCDDelay();
      }

      App_Model_DW.sfEvent_go = l_previousEvent;
      App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_NFC;
      enter_atomic_OperationMode_NFC();

      /* 4 */
    } else if ((rtu_PreProcessIn_p == On) && (rtu_PreProcessIn_i == WPC_On) && (rtu_PreProcessIn_g != NFCMode)) {
      /* &&...%for Dual 240111%PriorityChange4->5_240701
         INT_OPT_WPCStatus_2 != LPCDMode]%SWOffDividedCase_240701 */
      l_previousEvent = App_Model_DW.sfEvent_go;
      App_Model_DW.sfEvent_go = event_CancelTimer_OffLPCDDelay;
      if (App_Model_DW.is_active_OffLPCDDelay_d != 0U) {
        App_Model_OffLPCDDelay();
      }

      App_Model_DW.sfEvent_go = l_previousEvent;
      App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_WPC;
      App_Model_B.Output_OPT_WPCStatus_a = WPCMode;

      /* Output_WPC_NFCDetection = NFCDetection_Off; */
    } else {
      App_Model_OffLPCD_Check();

      /* OffToLPCDforFollow */
      App_Mode_DrDoorPhnLeftHoldCheck(rtu_PreProcessIn_p, rtu_PreProcessIn_go, rtu_PreProcessIn_mc, rtu_PreProcessIn_k);

      /* End of Outputs for SubSystem: '<S181>/WPC_NFCModeControl_compact' */
    }
    break;

   case App_Model_IN_OperationMode_Picc:
    {
      App_Model_B.Output_OPT_WPCStatus_a = PICCMode;

      /* 1 */
      if (rtu_PreProcessIn_e == On) {
        /* NFC1 & 2 OnThePad_Off */
        /* PhnRemoveMode
           Output_WPC_NFCDetection = NFCDetection_Off; */
        l_previousEvent = App_Model_DW.sfEvent_go;
        App_Model_DW.sfEvent_go = event_CancelTimer_PICCOffDelay;
        if (App_Model_DW.is_active_PICCOffDelay_o != 0U) {
          App_Model_PICCOffDelay();
        }

        App_Model_DW.sfEvent_go = l_previousEvent;
        App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_LPCD;

        /* Outputs for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' incorporates:
         *  ActionPort: '<S188>/Action Port'
         */
        /* SwitchCase: '<S181>/Switch Case' incorporates:
         *  Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6'
         */
        enter_atomic_OperationMode_LPCD(rtu_PreProcessIn_p);

        /* End of Outputs for SubSystem: '<S181>/WPC_NFCModeControl_compact' */

        /* 2 */
      } else if ((rtu_PreProcessIn_p == Off) && (App_Model_DW.Timer_PICCOffDelay_g >= 6000U)) {
        guard3 = true;
      } else {
        LC_IAUWPCNFCcmd tmp_0;

        /* 3 */
        tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_1_start_c;
        if ((App_Model_DW.Input_IAUWPCNFCcmd_1_prev_o != tmp_0) && (tmp_0 == WPCNFCPolling_Search)) {
          /* PhnRemoveMode
             Output_WPC_NFCDetection = NFCDetection_Off; */
          l_previousEvent = App_Model_DW.sfEvent_go;
          App_Model_DW.sfEvent_go = event_CancelTimer_PICCOffDelay;
          if (App_Model_DW.is_active_PICCOffDelay_o != 0U) {
            App_Model_PICCOffDelay();
          }

          App_Model_DW.sfEvent_go = l_previousEvent;
          App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_NFC;
          enter_atomic_OperationMode_NFC();

          /* 45sec */
        } else if ((rtu_PreProcessIn_p == On) && (rtu_PreProcessIn_i == WPC_On) && ((rtu_PreProcessIn_ak == OnThePad_On) || ((rtu_PreProcessIn_ak == OnThePad_Default) &&
                     (App_Model_DW.Timer_PICCOffDelay_g >= 500U)) || (rtu_PreProcessIn_g == WPCMode))) {
          /* TransitionMerge_240912 */
          /* PhnRemoveMode
             Output_WPC_NFCDetection = NFCDetection_Off; */
          l_previousEvent = App_Model_DW.sfEvent_go;
          App_Model_DW.sfEvent_go = event_CancelTimer_PICCOffDelay;
          if (App_Model_DW.is_active_PICCOffDelay_o != 0U) {
            App_Model_PICCOffDelay();
          }

          App_Model_DW.sfEvent_go = l_previousEvent;
          App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_WPC;
          App_Model_B.Output_OPT_WPCStatus_a = WPCMode;

          /* Output_WPC_NFCDetection = NFCDetection_Off; */

          /* 240112_Simultenously ModeOff_Nidec */
        } else if (((rtu_PreProcessIn_p == Off) && ((App_Model_DW.INT_OPT_WPCStatus_2_prev != App_Model_DW.INT_OPT_WPCStatus_2_start) && (App_Model_DW.INT_OPT_WPCStatus_2_start == ModeOff))) ||
                   ((App_Model_DW.INT_OPT_WPCStatus_2_prev != App_Model_DW.INT_OPT_WPCStatus_2_start) && (App_Model_DW.INT_OPT_WPCStatus_2_start == NFCMode)) || ((rtu_PreProcessIn_i == WPC_Off) &&
                    ((rtu_PreProcessIn_g == WPCMode) || (App_Model_DW.Timer_PICCOffDelay_g >= 6000U)))) {
          /* 240626 */
          /* WPCSWOffALL_Case_240911 */
          guard3 = true;
        } else {
          /* %WPCSWOption_Off Case */
        }
      }
    }
    break;

   case App_Model_IN_OperationMode_WPC:
    {
      App_Model_B.Output_OPT_WPCStatus_a = WPCMode;
      if (rtu_PreProcessIn_g == LPCDMode) {
        /* WhileWPC2isSWOff, WPC2MoveFromOFFtoLPCD */
        guard4 = true;
      } else {
        LC_IAUWPCNFCcmd tmp_0;

        /* 1 */
        tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_1_start_c;
        if ((App_Model_DW.Input_IAUWPCNFCcmd_1_prev_o != tmp_0) && (tmp_0 == WPCNFCPolling_Search) && (rtu_PreProcessIn_g != NFCMode)) {
          /* WaitingforNFCCom */
          App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_NFC;
          enter_atomic_OperationMode_NFC();

          /* 2%When WPC1&2 are Both ChargingOnThePad_Off || ObjectOnthePad_Off */
        } else if (((rtu_PreProcessIn_h == On) || (rtu_PreProcessIn_i2 == On)) && ((rtu_PreProcessIn_a == OwnerPhnReg__Disable) || (rtu_PreProcessIn_a == OwnerPhnReg__Default) || (rtu_PreProcessIn_a ==
          OwnerPhnReg__Invalid)) && (rtu_PreProcessIn_m == OwnerPairingAdvertisingReq__StartEnable)) {
          App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_Picc;
          enter_atomic_OperationMode_Picc();

          /* 3 */
        } else if ((rtu_PreProcessIn_p == Off) || (rtu_PreProcessIn_i == WPC_Off) || (rtu_PreProcessIn_g == NFCMode)) {
          /* PollingSearchDivided_240626 */
          guard4 = true;
        }
      }
    }
    break;
  }

  if (guard4) {
    App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_Off;

    /* Outputs for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' incorporates:
     *  ActionPort: '<S188>/Action Port'
     */
    /* SwitchCase: '<S181>/Switch Case' incorporates:
     *  Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6'
     */
    enter_atomic_OperationMode_Off(rtu_PreProcessIn_p, rtu_PreProcessIn_go, rtu_PreProcessIn_mc, rtu_PreProcessIn_k);

    /* End of Outputs for SubSystem: '<S181>/WPC_NFCModeControl_compact' */
  }

  if (guard3) {
    /* PhnRemoveMode
       Output_WPC_NFCDetection = NFCDetection_Off; */
    l_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_CancelTimer_PICCOffDelay;
    if (App_Model_DW.is_active_PICCOffDelay_o != 0U) {
      App_Model_PICCOffDelay();
    }

    App_Model_DW.sfEvent_go = l_previousEvent;
    App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_Off;

    /* Outputs for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' incorporates:
     *  ActionPort: '<S188>/Action Port'
     */
    /* SwitchCase: '<S181>/Switch Case' incorporates:
     *  Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6'
     */
    enter_atomic_OperationMode_Off(rtu_PreProcessIn_p, rtu_PreProcessIn_go, rtu_PreProcessIn_mc, rtu_PreProcessIn_k);

    /* End of Outputs for SubSystem: '<S181>/WPC_NFCModeControl_compact' */
  }

  if (guard2) {
    l_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_CancelTimer_OffLPCDDelay;
    if (App_Model_DW.is_active_OffLPCDDelay_d != 0U) {
      App_Model_OffLPCDDelay();
    }

    App_Model_DW.sfEvent_go = l_previousEvent;
    App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_LPCD;

    /* Outputs for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' incorporates:
     *  ActionPort: '<S188>/Action Port'
     */
    /* SwitchCase: '<S181>/Switch Case' incorporates:
     *  Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6'
     */
    enter_atomic_OperationMode_LPCD(rtu_PreProcessIn_p);

    /* End of Outputs for SubSystem: '<S181>/WPC_NFCModeControl_compact' */
  }

  if (guard1) {
    l_previousEvent = App_Model_DW.sfEvent_go;
    App_Model_DW.sfEvent_go = event_CancelTimer_LPCDOffDelay;
    if (App_Model_DW.is_active_LPCDOffDelay_e != 0U) {
      App_Model_LPCDOffDelay();
    }

    App_Model_DW.sfEvent_go = event_CancelTimer_PICCLPCDOffDe;
    if (App_Model_DW.is_active_PICCLPCDOffDelay_d != 0U) {
      App_Model_PICCLPCDOffDelay();
    }

    App_Model_DW.sfEvent_go = l_previousEvent;
    App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_Off;

    /* Outputs for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' incorporates:
     *  ActionPort: '<S188>/Action Port'
     */
    /* SwitchCase: '<S181>/Switch Case' incorporates:
     *  Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6'
     */
    enter_atomic_OperationMode_Off(rtu_PreProcessIn_p, rtu_PreProcessIn_go, rtu_PreProcessIn_mc, rtu_PreProcessIn_k);

    /* End of Outputs for SubSystem: '<S181>/WPC_NFCModeControl_compact' */
  }
}

/* System initialize for atomic system: '<S18>/NFC_WPC_Mode_Control_Function' */
void NFC_WPC_Mode_Control_Funct_Init(WPCStatus *rty_WPCStatus)
{
  /* SystemInitialize for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' */
  /* SystemInitialize for Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
  App_Model_DW.sfEvent_go = App_Model_CALL_EVENT_ny;
  App_Model_B.Output_OPT_WPCStatus_a = WPCMode;
  App_Model_DW.INT_OPT_WPCStatus_2_prev = WPCMode;
  App_Model_DW.INT_OPT_WPCStatus_2_start = WPCMode;
  App_Model_DW.Input_OPT_WPCSWOption_prev_o = WPC_On;
  App_Model_DW.Input_OPT_WPCSWOption_start_l = WPC_On;

  /* End of SystemInitialize for SubSystem: '<S181>/WPC_NFCModeControl_compact' */

  /* SystemInitialize for Merge: '<S181>/Merge' */
  *rty_WPCStatus = WPCMode;
}

/* Output and update for atomic system: '<S18>/NFC_WPC_Mode_Control_Function' */
void A_NFC_WPC_Mode_Control_Function(Bool rtu_PreProcessIn, LC_IAUWPCNFCcmd rtu_PreProcessIn_c, Bool rtu_PreProcessIn_p, IAU_OwnerPhnRegRVal rtu_PreProcessIn_a, OwnerPairingAdvertisingReq
  rtu_PreProcessIn_m, C_WPCOnOffNvalueSet rtu_PreProcessIn_i, OnThePad rtu_PreProcessIn_ak, Bool rtu_PreProcessIn_e, Bool rtu_PreProcessIn_h, WPCStatus rtu_PreProcessIn_g, uint8 rtu_PreProcessIn_n,
  uint8 rtu_PreProcessIn_hg, Bool rtu_PreProcessIn_go, C_WPCWarning rtu_PreProcessIn_mc, Bool rtu_PreProcessIn_k, LC_IAUWPCNFCcmd rtu_PreProcessIn_n5, Bool rtu_PreProcessIn_i2, Bool
  rtu_PreProcessIn_mg, WPCStatus *rty_WPCStatus)
{
  /* SwitchCase: '<S181>/Switch Case' */
  switch (rtu_PreProcessIn) {
   case Off:
    /* Outputs for IfAction SubSystem: '<S181>/WPC_Mode_Control' incorporates:
     *  ActionPort: '<S187>/Action Port'
     */
    App_Model_WPC_Mode_Control(rtu_PreProcessIn_p, rtu_PreProcessIn_i, rtu_PreProcessIn_mg, rty_WPCStatus, &App_Model_DW.WPC_Mode_Control);

    /* End of Outputs for SubSystem: '<S181>/WPC_Mode_Control' */
    break;

   case On:
    {
      /* Outputs for IfAction SubSystem: '<S181>/WPC_NFCModeControl_compact' incorporates:
       *  ActionPort: '<S188>/Action Port'
       */
      /* Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */
      App_Model_DW.sfEvent_go = App_Model_CALL_EVENT_ny;
      App_Model_DW.INT_NFCDetectOrder_prev_k = App_Model_DW.INT_NFCDetectOrder_start_b;
      App_Model_DW.INT_NFCDetectOrder_start_b = rtu_PreProcessIn_hg;
      App_Model_DW.Input_IAUWPCNFCcmd_1_prev_o = App_Model_DW.Input_IAUWPCNFCcmd_1_start_c;
      App_Model_DW.Input_IAUWPCNFCcmd_1_start_c = rtu_PreProcessIn_c;
      App_Model_DW.INT_OPT_WPCStatus_2_prev = App_Model_DW.INT_OPT_WPCStatus_2_start;
      App_Model_DW.INT_OPT_WPCStatus_2_start = rtu_PreProcessIn_g;
      App_Model_DW.Input_b_DrvDrSw_prev_h = App_Model_DW.Input_b_DrvDrSw_start_c;
      App_Model_DW.Input_b_DrvDrSw_start_c = rtu_PreProcessIn_go;
      App_Model_DW.Input_PhnLeftChk_Enable_prev_o = App_Model_DW.Input_PhnLeftChk_Enable_start_c;
      App_Model_DW.Input_PhnLeftChk_Enable_start_c = rtu_PreProcessIn_k;
      App_Model_DW.Var_DrDoorPhnLftHoldComplete__n = App_Model_DW.Var_DrDoorPhnLftHoldComplete__i;
      App_Model_DW.Var_DrDoorPhnLftHoldComplete__i = App_Model_DW.Var_DrDoorPhnLftHoldComplete_n;
      App_Model_DW.INT_LPCDWakeUpOrder_prev_g = App_Model_DW.INT_LPCDWakeUpOrder_start_l;
      App_Model_DW.INT_LPCDWakeUpOrder_start_l = rtu_PreProcessIn_n;
      App_Model_DW.Input_IAUWPCNFCcmd_2_prev_j = App_Model_DW.Input_IAUWPCNFCcmd_2_start_b;
      App_Model_DW.Input_IAUWPCNFCcmd_2_start_b = rtu_PreProcessIn_n5;
      App_Model_DW.Input_b_IGN1_IN_prev_l = App_Model_DW.Input_b_IGN1_IN_start_o;
      App_Model_DW.Input_b_IGN1_IN_start_o = rtu_PreProcessIn_p;
      App_Model_DW.Input_OPT_WPCSWOption_prev_o = App_Model_DW.Input_OPT_WPCSWOption_start_l;
      App_Model_DW.Input_OPT_WPCSWOption_start_l = rtu_PreProcessIn_i;
      if (App_Model_DW.is_active_c36_NFC_WPC_Mode_Cont == 0U) {
        App_Model_DW.INT_NFCDetectOrder_prev_k = rtu_PreProcessIn_hg;
        App_Model_DW.Input_IAUWPCNFCcmd_1_prev_o = rtu_PreProcessIn_c;
        App_Model_DW.INT_OPT_WPCStatus_2_prev = rtu_PreProcessIn_g;
        App_Model_DW.Input_b_DrvDrSw_prev_h = rtu_PreProcessIn_go;
        App_Model_DW.Input_PhnLeftChk_Enable_prev_o = rtu_PreProcessIn_k;
        App_Model_DW.INT_LPCDWakeUpOrder_prev_g = rtu_PreProcessIn_n;
        App_Model_DW.Input_IAUWPCNFCcmd_2_prev_j = rtu_PreProcessIn_n5;
        App_Model_DW.Input_b_IGN1_IN_prev_l = rtu_PreProcessIn_p;
        App_Model_DW.Input_OPT_WPCSWOption_prev_o = rtu_PreProcessIn_i;
        App_Model_DW.is_active_c36_NFC_WPC_Mode_Cont = 1U;
        App_Model_DW.is_active_NFCTimeOutConfirm_k = 1U;
        App_Model_DW.is_NFCTimeOutConfirm_f = App_Mo_IN_NFCTimeOutConfirm_Off;
        App_Model_DW.Timer_NFCTimeOutConfirm_j = 0U;
        App_Model_DW.is_active_NFCSearchingOffDela_g = 1U;
        App_Model_DW.is_NFCSearchingOffDelay_b = App_IN_NFCSearchingOffDelay_Off;
        App_Model_DW.Timer_NFCSearchingOffDelay_e = 0U;
        App_Model_DW.is_active_DeviceStateWait_j = 1U;
        App_Model_DW.is_DeviceStateWait_l = App_Mode_IN_DeviceStateWait_Off;
        App_Model_DW.Timer_DeviceStateWait_i = 0U;
        App_Model_DW.is_active_LPCDOffDelay_e = 1U;
        App_Model_DW.is_LPCDOffDelay_n = App_Model_IN_LPCDOffDelay_Off;
        App_Model_DW.b_Timer_LPCDOffDelay_is_Runni_j = false;
        App_Model_DW.Timer_LPCDOffDelay_o = 0U;
        App_Model_DW.is_active_NFCSearchingTimeout_j = 1U;
        App_Model_DW.is_NFCSearchingTimeout_i = App__IN_NFCSearchingTimeout_Off;
        App_Model_DW.Timer_NFCSearchingTimeout_h = 0U;
        App_Model_DW.is_active_PhnLeftHolding_i = 1U;
        App_Model_DW.is_PhnLeftHolding_d = App_Model_IN_PhnLeftHolding_Off;
        App_Model_DW.Timer_PhnLeftHolding_o = 0U;
        App_Model_DW.is_active_PICCOffDelay_o = 1U;
        App_Model_DW.is_PICCOffDelay_k = App_Model_IN_PICCOffDelay_Off;
        App_Model_DW.Timer_PICCOffDelay_g = 0U;
        App_Model_DW.is_active_WPC_NFC_Mode_Contro_e = 1U;

        /* Default */
        App_Model_DW.is_WPC_NFC_Mode_Control_Funct_k = App_Model_IN_OperationMode_Off;
        enter_atomic_OperationMode_Off(rtu_PreProcessIn_p, rtu_PreProcessIn_go, rtu_PreProcessIn_mc, rtu_PreProcessIn_k);
        App_Model_DW.is_active_OffLPCDDelay_d = 1U;
        App_Model_DW.is_OffLPCDDelay_e = App_Model_IN_OffLPCDDelay_Off;
        App_Model_DW.Timer_OffLPCDDelay_i = 0U;
        App_Model_DW.is_active_PICCLPCDOffDelay_d = 1U;
        App_Model_DW.is_PICCLPCDOffDelay_l = App_Mod_IN_PICCLPCDOffDelay_Off;
        App_Model_DW.Timer_PICCLPCDOffDelay_c = 0U;
        App_Model_DW.is_active_PhnLeftChattering_i = 1U;
        App_Model_DW.is_PhnLeftChattering_g = App_Mo_IN_PhnLeftChattering_Off;
        App_Model_DW.b_Timer_PhnLeftChattering_is__j = false;
        App_Model_DW.Timer_PhnLeftChattering_b = 0U;
      } else {
        uint32 qY;
        if (App_Model_DW.is_active_NFCTimeOutConfirm_k != 0U) {
          App_Model_NFCTimeOutConfirm();
        }

        if (App_Model_DW.is_active_NFCSearchingOffDela_g != 0U) {
          App_Model_NFCSearchingOffDelay();
        }

        if (App_Model_DW.is_active_DeviceStateWait_j != 0U) {
          switch (App_Model_DW.is_DeviceStateWait_l) {
           case App_Mode_IN_DeviceStateWait_Off:
            break;

           case App_Model_IN_DeviceStateWait_On:
            qY = App_Model_DW.Timer_DeviceStateWait_i + /*MW:OvSatOk*/ 1U;
            if (App_Model_DW.Timer_DeviceStateWait_i + 1U < App_Model_DW.Timer_DeviceStateWait_i) {
              qY = MAX_uint32_T;
            }

            App_Model_DW.Timer_DeviceStateWait_i = qY;
            break;
          }
        }

        if (App_Model_DW.is_active_LPCDOffDelay_e != 0U) {
          App_Model_LPCDOffDelay();
        }

        if (App_Model_DW.is_active_NFCSearchingTimeout_j != 0U) {
          App_Model_NFCSearchingTimeout();
        }

        if (App_Model_DW.is_active_PhnLeftHolding_i != 0U) {
          switch (App_Model_DW.is_PhnLeftHolding_d) {
           case App_Model_IN_PhnLeftHolding_Off:
            break;

           case App_Model_IN_PhnLeftHolding_On:
            qY = App_Model_DW.Timer_PhnLeftHolding_o + /*MW:OvSatOk*/ 1U;
            if (App_Model_DW.Timer_PhnLeftHolding_o + 1U < App_Model_DW.Timer_PhnLeftHolding_o) {
              qY = MAX_uint32_T;
            }

            App_Model_DW.Timer_PhnLeftHolding_o = qY;
            break;
          }
        }

        if (App_Model_DW.is_active_PICCOffDelay_o != 0U) {
          App_Model_PICCOffDelay();
        }

        if (App_Model_DW.is_active_WPC_NFC_Mode_Contro_e != 0U) {
          WPC_NFC_Mode_Control_Function_S(rtu_PreProcessIn_c, rtu_PreProcessIn_p, rtu_PreProcessIn_a, rtu_PreProcessIn_m, rtu_PreProcessIn_i, rtu_PreProcessIn_ak, rtu_PreProcessIn_e,
            rtu_PreProcessIn_h, rtu_PreProcessIn_g, rtu_PreProcessIn_go, rtu_PreProcessIn_mc, rtu_PreProcessIn_k, rtu_PreProcessIn_i2);
        }

        if (App_Model_DW.is_active_OffLPCDDelay_d != 0U) {
          App_Model_OffLPCDDelay();
        }

        if (App_Model_DW.is_active_PICCLPCDOffDelay_d != 0U) {
          App_Model_PICCLPCDOffDelay();
        }

        if (App_Model_DW.is_active_PhnLeftChattering_i != 0U) {
          App_Model_PhnLeftChattering();
        }
      }

      /* End of Chart: '<S188>/NFC_WPC_Mode_Control_MPPEPP_1_r6' */

      /* SignalConversion: '<S188>/Signal Conversion1' */
      *rty_WPCStatus = App_Model_B.Output_OPT_WPCStatus_a;

      /* End of Outputs for SubSystem: '<S181>/WPC_NFCModeControl_compact' */
    }
    break;
  }

  /* End of SwitchCase: '<S181>/Switch Case' */
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_NFCTimeOutConfirm_e(void)
{
  switch (App_Model_DW.is_NFCTimeOutConfirm) {
   case App__IN_NFCTimeOutConfirm_Off_f:
    if (App_Model_DW.sfEvent_n == event_StartTimer_NFCTimeOutCo_i) {
      App_Model_DW.is_NFCTimeOutConfirm = App_M_IN_NFCTimeOutConfirm_On_h;
    }
    break;

   case App_M_IN_NFCTimeOutConfirm_On_h:
    {
      switch (App_Model_DW.sfEvent_n) {
       case event_CancelTimer_NFCTimeOutC_g:
        App_Model_DW.is_NFCTimeOutConfirm = App__IN_NFCTimeOutConfirm_Off_f;
        App_Model_DW.Timer_NFCTimeOutConfirm = 0U;
        break;

       case event_StartTimer_NFCTimeOutCo_i:
        App_Model_DW.Timer_NFCTimeOutConfirm = 0U;
        App_Model_DW.is_NFCTimeOutConfirm = App_M_IN_NFCTimeOutConfirm_On_h;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_NFCTimeOutConfirm + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_NFCTimeOutConfirm + 1U < App_Model_DW.Timer_NFCTimeOutConfirm) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_NFCTimeOutConfirm = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Mode_NFCSearchingOffDelay_p(void)
{
  switch (App_Model_DW.is_NFCSearchingOffDelay) {
   case A_IN_NFCSearchingOffDelay_Off_n:
    if (App_Model_DW.sfEvent_n == event_StartTimer_NFCSearching_h) {
      App_Model_DW.is_NFCSearchingOffDelay = Ap_IN_NFCSearchingOffDelay_On_k;
    }
    break;

   case Ap_IN_NFCSearchingOffDelay_On_k:
    {
      switch (App_Model_DW.sfEvent_n) {
       case event_CancelTimer_NFCSearchin_e:
        App_Model_DW.is_NFCSearchingOffDelay = A_IN_NFCSearchingOffDelay_Off_n;
        App_Model_DW.Timer_NFCSearchingOffDelay = 0U;
        break;

       case event_StartTimer_NFCSearching_h:
        App_Model_DW.Timer_NFCSearchingOffDelay = 0U;
        App_Model_DW.is_NFCSearchingOffDelay = Ap_IN_NFCSearchingOffDelay_On_k;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_NFCSearchingOffDelay + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_NFCSearchingOffDelay + 1U < App_Model_DW.Timer_NFCSearchingOffDelay) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_NFCSearchingOffDelay = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_LPCDOffDelay_j(void)
{
  switch (App_Model_DW.is_LPCDOffDelay) {
   case App_Model_IN_LPCDOffDelay_Off_c:
    if (App_Model_DW.sfEvent_n == event_StartTimer_LPCDOffDelay_i) {
      App_Model_DW.is_LPCDOffDelay = App_Model_IN_LPCDOffDelay_On_g;
      App_Model_DW.b_Timer_LPCDOffDelay_is_Running = true;
    }
    break;

   case App_Model_IN_LPCDOffDelay_On_g:
    {
      switch (App_Model_DW.sfEvent_n) {
       case event_CancelTimer_LPCDOffDela_i:
        App_Model_DW.is_LPCDOffDelay = App_Model_IN_LPCDOffDelay_Off_c;
        App_Model_DW.b_Timer_LPCDOffDelay_is_Running = false;
        App_Model_DW.Timer_LPCDOffDelay = 0U;
        break;

       case event_StartTimer_LPCDOffDelay_i:
        App_Model_DW.Timer_LPCDOffDelay = 0U;
        App_Model_DW.is_LPCDOffDelay = App_Model_IN_LPCDOffDelay_On_g;
        App_Model_DW.b_Timer_LPCDOffDelay_is_Running = true;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_LPCDOffDelay + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_LPCDOffDelay + 1U < App_Model_DW.Timer_LPCDOffDelay) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_LPCDOffDelay = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_NFCSearchingTimeout_k(void)
{
  switch (App_Model_DW.is_NFCSearchingTimeout) {
   case Ap_IN_NFCSearchingTimeout_Off_j:
    if (App_Model_DW.sfEvent_n == event_StartTimer_NFCSearching_c) {
      App_Model_DW.is_NFCSearchingTimeout = App_IN_NFCSearchingTimeout_On_n;
    }
    break;

   case App_IN_NFCSearchingTimeout_On_n:
    {
      switch (App_Model_DW.sfEvent_n) {
       case event_CancelTimer_NFCSearchin_k:
        App_Model_DW.is_NFCSearchingTimeout = Ap_IN_NFCSearchingTimeout_Off_j;
        App_Model_DW.Timer_NFCSearchingTimeout = 0U;
        break;

       case event_StartTimer_NFCSearching_c:
        App_Model_DW.Timer_NFCSearchingTimeout = 0U;
        App_Model_DW.is_NFCSearchingTimeout = App_IN_NFCSearchingTimeout_On_n;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_NFCSearchingTimeout + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_NFCSearchingTimeout + 1U < App_Model_DW.Timer_NFCSearchingTimeout) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_NFCSearchingTimeout = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_PICCOffDelay_k(void)
{
  switch (App_Model_DW.is_PICCOffDelay) {
   case App_Model_IN_PICCOffDelay_Off_k:
    if (App_Model_DW.sfEvent_n == event_StartTimer_PICCOffDelay_b) {
      App_Model_DW.is_PICCOffDelay = App_Model_IN_PICCOffDelay_On_d;
    }
    break;

   case App_Model_IN_PICCOffDelay_On_d:
    {
      switch (App_Model_DW.sfEvent_n) {
       case event_CancelTimer_PICCOffDela_h:
        App_Model_DW.is_PICCOffDelay = App_Model_IN_PICCOffDelay_Off_k;
        App_Model_DW.Timer_PICCOffDelay = 0U;
        break;

       case event_StartTimer_PICCOffDelay_b:
        App_Model_DW.Timer_PICCOffDelay = 0U;
        App_Model_DW.is_PICCOffDelay = App_Model_IN_PICCOffDelay_On_d;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_PICCOffDelay + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_PICCOffDelay + 1U < App_Model_DW.Timer_PICCOffDelay) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_PICCOffDelay = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void exit_atomic_OperationMode_NFC_c(void)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_n;
  App_Model_DW.sfEvent_n = event_CancelTimer_NFCTimeOutC_g;
  if (App_Model_DW.is_active_NFCTimeOutConfirm != 0U) {
    App_Model_NFCTimeOutConfirm_e();
  }

  App_Model_DW.sfEvent_n = event_CancelTimer_NFCSearchin_e;
  if (App_Model_DW.is_active_NFCSearchingOffDelay != 0U) {
    App_Mode_NFCSearchingOffDelay_p();
  }

  App_Model_DW.sfEvent_n = event_CancelTimer_NFCSearchin_k;
  if (App_Model_DW.is_active_NFCSearchingTimeout != 0U) {
    App_Model_NFCSearchingTimeout_k();
  }

  App_Model_DW.sfEvent_n = b_previousEvent;
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App__NFCSearchingOffDetection_b(void)
{
  if ((App_Model_DW.Input_IAUWPCNFCcmd_2_prev != App_Model_DW.Input_IAUWPCNFCcmd_2_start) && (App_Model_DW.Input_IAUWPCNFCcmd_2_start == WPCNFCDeselect_Stop)) {
    sint32 c_previousEvent;
    c_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_StartTimer_NFCSearching_h;
    if (App_Model_DW.is_active_NFCSearchingOffDelay != 0U) {
      App_Mode_NFCSearchingOffDelay_p();
    }

    App_Model_DW.sfEvent_n = c_previousEvent;
  } else if ((App_Model_DW.Input_IAUWPCNFCcmd_2_prev != App_Model_DW.Input_IAUWPCNFCcmd_2_start) && (App_Model_DW.Input_IAUWPCNFCcmd_2_start == WPCNFCPolling_Search)) {
    sint32 c_previousEvent;
    c_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_CancelTimer_NFCSearchin_e;
    if (App_Model_DW.is_active_NFCSearchingOffDelay != 0U) {
      App_Mode_NFCSearchingOffDelay_p();
    }

    App_Model_DW.sfEvent_n = c_previousEvent;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_NFCDetectionCheck_h(void)
{
  /* hasChangedTo(Receive_Flag_NFCDetection, On) ||... */
  if (((App_Model_DW.INT_NFCDetectOrder_prev != App_Model_DW.INT_NFCDetectOrder_start) && (App_Model_DW.INT_NFCDetectOrder_start == 2)) || ((App_Model_DW.Input_IAUWPCNFCcmd_2_prev !=
        App_Model_DW.Input_IAUWPCNFCcmd_2_start) && (App_Model_DW.Input_IAUWPCNFCcmd_2_start == WPCNFCPolling_Search))) {
    sint32 b_previousEvent;
    b_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_CancelTimer_NFCSearchin_k;
    if (App_Model_DW.is_active_NFCSearchingTimeout != 0U) {
      App_Model_NFCSearchingTimeout_k();
    }

    App_Model_DW.sfEvent_n = b_previousEvent;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void enter_atomic_OperationMode_NF_k(void)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_n;
  App_Model_DW.sfEvent_n = event_StartTimer_NFCTimeOutCo_i;
  if (App_Model_DW.is_active_NFCTimeOutConfirm != 0U) {
    App_Model_NFCTimeOutConfirm_e();
  }

  App_Model_DW.sfEvent_n = event_StartTimer_NFCSearching_c;
  if (App_Model_DW.is_active_NFCSearchingTimeout != 0U) {
    App_Model_NFCSearchingTimeout_k();
  }

  App_Model_DW.sfEvent_n = b_previousEvent;
  App__NFCSearchingOffDetection_b();
  App_Model_NFCDetectionCheck_h();
  App_Model_B.Output_OPT_WPCStatus = NFCMode;
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_LPCDOff_Check_h(Bool rtu_PreProcessIn_c)
{
  if ((rtu_PreProcessIn_c == Off) && (!App_Model_DW.b_Timer_LPCDOffDelay_is_Running)) {
    sint32 c_previousEvent;
    c_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_StartTimer_LPCDOffDelay_i;
    if (App_Model_DW.is_active_LPCDOffDelay != 0U) {
      App_Model_LPCDOffDelay_j();
    }

    App_Model_DW.sfEvent_n = c_previousEvent;
  } else if (rtu_PreProcessIn_c == On) {
    sint32 c_previousEvent;
    c_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_CancelTimer_LPCDOffDela_i;
    if (App_Model_DW.is_active_LPCDOffDelay != 0U) {
      App_Model_LPCDOffDelay_j();
    }

    App_Model_DW.sfEvent_n = c_previousEvent;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void enter_atomic_OperationMode_LP_c(Bool rtu_PreProcessIn_c)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_n;
  App_Model_DW.sfEvent_n = event_CancelTimer_NFCTimeOutC_g;
  if (App_Model_DW.is_active_NFCTimeOutConfirm != 0U) {
    App_Model_NFCTimeOutConfirm_e();
  }

  App_Model_DW.sfEvent_n = event_CancelTimer_NFCSearchin_e;
  if (App_Model_DW.is_active_NFCSearchingOffDelay != 0U) {
    App_Mode_NFCSearchingOffDelay_p();
  }

  App_Model_DW.sfEvent_n = event_CancelTimer_LPCDOffDela_i;
  if (App_Model_DW.is_active_LPCDOffDelay != 0U) {
    App_Model_LPCDOffDelay_j();
  }

  App_Model_DW.sfEvent_n = b_previousEvent;
  App_Model_B.Output_OPT_WPCStatus = LPCDMode;
  App_Model_LPCDOff_Check_h(rtu_PreProcessIn_c);
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_PICCLPCDOffDelay_j(void)
{
  switch (App_Model_DW.is_PICCLPCDOffDelay) {
   case App_M_IN_PICCLPCDOffDelay_Off_l:
    if (App_Model_DW.sfEvent_n == event_StartTimer_PICCLPCDOffD_f) {
      App_Model_DW.is_PICCLPCDOffDelay = App_Mo_IN_PICCLPCDOffDelay_On_c;
    }
    break;

   case App_Mo_IN_PICCLPCDOffDelay_On_c:
    {
      switch (App_Model_DW.sfEvent_n) {
       case event_CancelTimer_PICCLPCDOff_k:
        App_Model_DW.is_PICCLPCDOffDelay = App_M_IN_PICCLPCDOffDelay_Off_l;
        App_Model_DW.Timer_PICCLPCDOffDelay = 0U;
        break;

       case event_StartTimer_PICCLPCDOffD_f:
        App_Model_DW.Timer_PICCLPCDOffDelay = 0U;
        App_Model_DW.is_PICCLPCDOffDelay = App_Mo_IN_PICCLPCDOffDelay_On_c;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_PICCLPCDOffDelay + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_PICCLPCDOffDelay + 1U < App_Model_DW.Timer_PICCLPCDOffDelay) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_PICCLPCDOffDelay = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void enter_atomic_OperationMode_Pi_m(void)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_n;
  App_Model_DW.sfEvent_n = event_StartTimer_PICCOffDelay_b;
  if (App_Model_DW.is_active_PICCOffDelay != 0U) {
    App_Model_PICCOffDelay_k();
  }

  App_Model_DW.sfEvent_n = event_StartTimer_PICCLPCDOffD_f;
  if (App_Model_DW.is_active_PICCLPCDOffDelay != 0U) {
    App_Model_PICCLPCDOffDelay_j();
  }

  App_Model_DW.sfEvent_n = b_previousEvent;
  App_Model_B.Output_OPT_WPCStatus = PICCMode;
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_OffLPCDDelay_k(void)
{
  switch (App_Model_DW.is_OffLPCDDelay) {
   case App_Model_IN_LPCDOffDelay_Off_c:
    if (App_Model_DW.sfEvent_n == event_StartTimer_OffLPCDDelay_m) {
      App_Model_DW.is_OffLPCDDelay = App_Model_IN_OffLPCDDelay_On_b;
    }
    break;

   case App_Model_IN_OffLPCDDelay_On_b:
    {
      switch (App_Model_DW.sfEvent_n) {
       case event_CancelTimer_OffLPCDDela_o:
        App_Model_DW.is_OffLPCDDelay = App_Model_IN_LPCDOffDelay_Off_c;
        App_Model_DW.Timer_OffLPCDDelay = 0U;
        break;

       case event_StartTimer_OffLPCDDelay_m:
        App_Model_DW.Timer_OffLPCDDelay = 0U;
        App_Model_DW.is_OffLPCDDelay = App_Model_IN_OffLPCDDelay_On_b;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_OffLPCDDelay + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_OffLPCDDelay + 1U < App_Model_DW.Timer_OffLPCDDelay) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_OffLPCDDelay = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_OffLPCD_Check_p(void)
{
  if (((App_Model_DW.INT_OPT_WPCStatus_1_prev != App_Model_DW.INT_OPT_WPCStatus_1_start) && (App_Model_DW.INT_OPT_WPCStatus_1_start == PICCMode)) || ((App_Model_DW.INT_OPT_WPCStatus_1_prev !=
        App_Model_DW.INT_OPT_WPCStatus_1_start) && (App_Model_DW.INT_OPT_WPCStatus_1_start == LPCDMode))) {
    sint32 b_previousEvent;
    b_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_StartTimer_OffLPCDDelay_m;
    if (App_Model_DW.is_active_OffLPCDDelay != 0U) {
      App_Model_OffLPCDDelay_k();
    }

    App_Model_DW.sfEvent_n = b_previousEvent;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Model_PhnLeftChattering_h(void)
{
  switch (App_Model_DW.is_PhnLeftChattering) {
   case App__IN_PhnLeftChattering_Off_c:
    if (App_Model_DW.sfEvent_n == event_StartTimer_PhnLeftChatt_g) {
      App_Model_DW.is_PhnLeftChattering = App_M_IN_PhnLeftChattering_On_i;
      App_Model_DW.b_Timer_PhnLeftChattering_is_Ru = true;
    }
    break;

   case App_M_IN_PhnLeftChattering_On_i:
    {
      switch (App_Model_DW.sfEvent_n) {
       case event_CancelTimer_PhnLeftChat_h:
        App_Model_DW.is_PhnLeftChattering = App__IN_PhnLeftChattering_Off_c;
        App_Model_DW.b_Timer_PhnLeftChattering_is_Ru = false;
        App_Model_DW.Timer_PhnLeftChattering = 0U;
        break;

       case event_StartTimer_PhnLeftChatt_g:
        App_Model_DW.Timer_PhnLeftChattering = 0U;
        App_Model_DW.is_PhnLeftChattering = App_M_IN_PhnLeftChattering_On_i;
        App_Model_DW.b_Timer_PhnLeftChattering_is_Ru = true;
        break;

       default:
        {
          uint32 qY;
          qY = App_Model_DW.Timer_PhnLeftChattering + /*MW:OvSatOk*/ 1U;
          if (App_Model_DW.Timer_PhnLeftChattering + 1U < App_Model_DW.Timer_PhnLeftChattering) {
            qY = MAX_uint32_T;
          }

          App_Model_DW.Timer_PhnLeftChattering = qY;
        }
        break;
      }
    }
    break;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void App_Mo_DrDoorPhnLeftHoldCheck_h(Bool rtu_PreProcessIn_c, Bool rtu_PreProcessIn_cp, C_WPCWarning rtu_PreProcessIn_h, Bool rtu_PreProcessIn_ai)
{
  if (((rtu_PreProcessIn_c == Off) && (rtu_PreProcessIn_h == WPCWarningOff) && (rtu_PreProcessIn_ai == Off) && (((App_Model_DW.Input_b_DrvDrSw_prev != App_Model_DW.Input_b_DrvDrSw_start) &&
         (App_Model_DW.Input_b_DrvDrSw_start == On)) || ((App_Model_DW.Input_b_DrvDrSw_prev != App_Model_DW.Input_b_DrvDrSw_start) && (App_Model_DW.Input_b_DrvDrSw_start == Off)))) ||
      ((App_Model_DW.Timer_PhnLeftChattering >= 600U) || ((App_Model_DW.Input_PhnLeftChk_Enable_prev != App_Model_DW.Input_PhnLeftChk_Enable_start) && (App_Model_DW.Input_PhnLeftChk_Enable_start ==
         Off)))) {
    sint32 d_previousEvent;
    App_Model_DW.Var_DrDoorPhnLftHoldComplete = On;
    d_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_CancelTimer_PhnLeftChat_h;
    if (App_Model_DW.is_active_PhnLeftChattering != 0U) {
      App_Model_PhnLeftChattering_h();
    }

    App_Model_DW.sfEvent_n = d_previousEvent;
  } else if ((!App_Model_DW.b_Timer_PhnLeftChattering_is_Ru) && (rtu_PreProcessIn_c == Off) && (rtu_PreProcessIn_h == Cellphoneonthepad) && (rtu_PreProcessIn_ai == On) && (rtu_PreProcessIn_cp == On))
  {
    sint32 d_previousEvent;
    App_Model_DW.Var_DrDoorPhnLftHoldComplete = Off;
    d_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_StartTimer_PhnLeftChatt_g;
    if (App_Model_DW.is_active_PhnLeftChattering != 0U) {
      App_Model_PhnLeftChattering_h();
    }

    App_Model_DW.sfEvent_n = d_previousEvent;
  } else if (rtu_PreProcessIn_c == On) {
    sint32 d_previousEvent;
    App_Model_DW.Var_DrDoorPhnLftHoldComplete = Off;
    d_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_CancelTimer_PhnLeftChat_h;
    if (App_Model_DW.is_active_PhnLeftChattering != 0U) {
      App_Model_PhnLeftChattering_h();
    }

    App_Model_DW.sfEvent_n = d_previousEvent;
  }
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void enter_atomic_OperationMode_Of_n(Bool rtu_PreProcessIn_c, Bool rtu_PreProcessIn_cp, C_WPCWarning rtu_PreProcessIn_h, Bool rtu_PreProcessIn_ai)
{
  sint32 b_previousEvent;
  b_previousEvent = App_Model_DW.sfEvent_n;
  App_Model_DW.sfEvent_n = event_CancelTimer_NFCTimeOutC_g;
  if (App_Model_DW.is_active_NFCTimeOutConfirm != 0U) {
    App_Model_NFCTimeOutConfirm_e();
  }

  App_Model_DW.sfEvent_n = event_CancelTimer_NFCSearchin_e;
  if (App_Model_DW.is_active_NFCSearchingOffDelay != 0U) {
    App_Mode_NFCSearchingOffDelay_p();
  }

  App_Model_DW.sfEvent_n = event_CancelTimer_LPCDOffDela_i;
  if (App_Model_DW.is_active_LPCDOffDelay != 0U) {
    App_Model_LPCDOffDelay_j();
  }

  App_Model_DW.sfEvent_n = event_CancelTimer_PICCOffDela_h;
  if (App_Model_DW.is_active_PICCOffDelay != 0U) {
    App_Model_PICCOffDelay_k();
  }

  App_Model_DW.sfEvent_n = b_previousEvent;
  App_Model_B.Output_OPT_WPCStatus = ModeOff;
  App_Model_OffLPCD_Check_p();

  /* OffToLPCDforFollow */
  b_previousEvent = App_Model_DW.sfEvent_n;
  App_Model_DW.sfEvent_n = event_CancelTimer_PhnLeftChat_h;
  if (App_Model_DW.is_active_PhnLeftChattering != 0U) {
    App_Model_PhnLeftChattering_h();
  }

  App_Model_DW.sfEvent_n = b_previousEvent;
  App_Model_DW.Var_DrDoorPhnLftHoldComplete = Off;
  App_Mo_DrDoorPhnLeftHoldCheck_h(rtu_PreProcessIn_c, rtu_PreProcessIn_cp, rtu_PreProcessIn_h, rtu_PreProcessIn_ai);
}

/* Function for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
static void WPC_NFC_Mode_Control_Function_c(Bool rtu_PreProcessIn_c, LC_IAUWPCNFCcmd rtu_PreProcessIn_e, C_WPCOnOffNvalueSet rtu_PreProcessIn_m, IAU_OwnerPhnRegRVal rtu_PreProcessIn_j,
  OwnerPairingAdvertisingReq rtu_PreProcessIn_l, OnThePad rtu_PreProcessIn_b, Bool rtu_PreProcessIn_k, Bool rtu_PreProcessIn_p, WPCStatus rtu_PreProcessIn_mb, Bool rtu_PreProcessIn_cp, C_WPCWarning
  rtu_PreProcessIn_h, Bool rtu_PreProcessIn_ai, Bool rtu_PreProcessIn_hl)
{
  sint32 l_previousEvent;
  boolean guard1;
  boolean guard2;
  boolean guard3;
  boolean guard4;
  guard1 = false;
  guard2 = false;
  guard3 = false;
  guard4 = false;
  switch (App_Model_DW.is_WPC_NFC_Mode_Control_Functio) {
   case App_Mod_IN_OperationMode_LPCD_m:
    {
      C_WPCOnOffNvalueSet tmp;
      App_Model_B.Output_OPT_WPCStatus = LPCDMode;

      /* 1 */
      tmp = App_Model_DW.Input_OPT_WPCSWOption_start;
      if (((rtu_PreProcessIn_m == WPC_On) && (rtu_PreProcessIn_c == On) && (rtu_PreProcessIn_e != WPCNFCPolling_Search) && ((rtu_PreProcessIn_j == OwnerPhnReg__Enable) || (rtu_PreProcessIn_l !=
             OwnerPairingAdvertisingReq__StartEnable))) || ((App_Model_DW.Input_OPT_WPCSWOption_prev != tmp) && (tmp == WPC_On))) {
        /* 230406 */
        l_previousEvent = App_Model_DW.sfEvent_n;
        App_Model_DW.sfEvent_n = event_CancelTimer_LPCDOffDela_i;
        if (App_Model_DW.is_active_LPCDOffDelay != 0U) {
          App_Model_LPCDOffDelay_j();
        }

        /* send(CancelTimer_OffLPCDDelay, OffLPCDDelay); */
        App_Model_DW.sfEvent_n = event_CancelTimer_PICCLPCDOff_k;
        if (App_Model_DW.is_active_PICCLPCDOffDelay != 0U) {
          App_Model_PICCLPCDOffDelay_j();
        }

        App_Model_DW.sfEvent_n = l_previousEvent;
        App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_WPC_h;
        App_Model_B.Output_OPT_WPCStatus = WPCMode;

        /* Output_WPC_NFCDetection = NFCDetection_Off; */
      } else {
        LC_IAUWPCNFCcmd tmp_0;

        /* 2 ]%Nidec%SWOff_Devided_Priority_240701 */
        tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_1_start;
        if ((rtu_PreProcessIn_mb == NFCMode) || ((App_Model_DW.INT_LPCDWakeUpOrder_prev != App_Model_DW.INT_LPCDWakeUpOrder_start) && (App_Model_DW.INT_LPCDWakeUpOrder_start == 1)) ||
            ((App_Model_DW.Input_IAUWPCNFCcmd_1_prev != tmp_0) && (tmp_0 == WPCNFCPolling_Search)) || ((rtu_PreProcessIn_c == On) && (rtu_PreProcessIn_l != OwnerPairingAdvertisingReq__StartEnable) &&
             (rtu_PreProcessIn_m == WPC_Off) && (rtu_PreProcessIn_mb != PICCMode))) {
          /* 240704 */
          /* &&...%240112_Prevention of oscillation_Nidec%
             SWOffDevided_ChangePriority_5to3_240701 */
          guard1 = true;
        } else {
          /* 5 */
          /* 3%Nidec */
          tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_2_start;
          if (((App_Model_DW.INT_LPCDWakeUpOrder_prev != App_Model_DW.INT_LPCDWakeUpOrder_start) && (App_Model_DW.INT_LPCDWakeUpOrder_start == 2)) || ((App_Model_DW.Input_IAUWPCNFCcmd_2_prev != tmp_0)
               && (tmp_0 == WPCNFCPolling_Search)) || ((App_Model_DW.Input_b_IGN1_IN_prev != App_Model_DW.Input_b_IGN1_IN_start) && (App_Model_DW.Input_b_IGN1_IN_start == On))) {
            /* SWOffDevided_ChangePriority_3to4_240701 */
            /* 230406 */
            l_previousEvent = App_Model_DW.sfEvent_n;
            App_Model_DW.sfEvent_n = event_CancelTimer_LPCDOffDela_i;
            if (App_Model_DW.is_active_LPCDOffDelay != 0U) {
              App_Model_LPCDOffDelay_j();
            }

            /* send(CancelTimer_OffLPCDDelay, OffLPCDDelay); */
            App_Model_DW.sfEvent_n = event_CancelTimer_PICCLPCDOff_k;
            if (App_Model_DW.is_active_PICCLPCDOffDelay != 0U) {
              App_Model_PICCLPCDOffDelay_j();
            }

            App_Model_DW.sfEvent_n = l_previousEvent;
            App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_NFC_f;
            enter_atomic_OperationMode_NF_k();
          } else {
            WPCStatus tmp_1;

            /* 4 */
            tmp_1 = App_Model_DW.INT_OPT_WPCStatus_1_start;
            if ((rtu_PreProcessIn_c == Off) && ((App_Model_DW.Timer_LPCDOffDelay >= 6000U) || (App_Model_DW.Timer_PICCLPCDOffDelay >= 6000U) || ((App_Model_DW.INT_OPT_WPCStatus_1_prev != tmp_1) &&
                  (tmp_1 == ModeOff)))) {
              /* Nidec_Simultaneously */
              guard1 = true;
            } else {
              /* Outputs for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' incorporates:
               *  ActionPort: '<S368>/Action Port'
               */
              /* SwitchCase: '<S361>/Switch Case' incorporates:
               *  Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6'
               */
              /* 230406 */
              App_Model_LPCDOff_Check_h(rtu_PreProcessIn_c);

              /* End of Outputs for SubSystem: '<S361>/WPC_NFCModeControl_compact' */
            }
          }
        }
      }
    }
    break;

   case App_Mode_IN_OperationMode_NFC_f:
    {
      LC_IAUWPCNFCcmd tmp_0;
      App_Model_B.Output_OPT_WPCStatus = NFCMode;
      tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_2_start;
      if ((App_Model_DW.Input_IAUWPCNFCcmd_2_prev != tmp_0) && (tmp_0 == WPCNFCPolling_Search)) {
        exit_atomic_OperationMode_NFC_c();
        App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_NFC_f;
        enter_atomic_OperationMode_NF_k();
      } else {
        /* %WPC1Lead, WPC2Follow or WPC1NFCOnly */
        tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_1_start;

        /* Outputs for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' incorporates:
         *  ActionPort: '<S368>/Action Port'
         */
        /* SwitchCase: '<S361>/Switch Case' incorporates:
         *  Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6'
         */
        if (((rtu_PreProcessIn_mb == NFCMode) && ((App_Model_DW.INT_NFCDetectOrder_prev != App_Model_DW.INT_NFCDetectOrder_start) && (App_Model_DW.INT_NFCDetectOrder_start == 1))) ||
            ((App_Model_DW.Input_IAUWPCNFCcmd_1_prev != tmp_0) && (tmp_0 == WPCNFCPolling_Search))) {
          /* 240626InNFC */
          exit_atomic_OperationMode_NFC_c();
          App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_Off_j;
          enter_atomic_OperationMode_Of_n(rtu_PreProcessIn_c, rtu_PreProcessIn_cp, rtu_PreProcessIn_h, rtu_PreProcessIn_ai);

          /* 20.5s60s */
        } else if ((rtu_PreProcessIn_c == On) && (rtu_PreProcessIn_m == WPC_On) && ((App_Model_DW.Timer_NFCSearchingOffDelay >= 50U) || (App_Model_DW.Timer_NFCTimeOutConfirm >= 6000U) ||
                    (App_Model_DW.Timer_NFCSearchingTimeout >= 150U))) {
          /* 1.5 */
          exit_atomic_OperationMode_NFC_c();
          App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_WPC_h;
          App_Model_B.Output_OPT_WPCStatus = WPCMode;

          /* Output_WPC_NFCDetection = NFCDetection_Off; */

          /* 3. */
        } else if (((rtu_PreProcessIn_c == Off) && (App_Model_DW.Timer_NFCSearchingOffDelay >= 50U)) || ((rtu_PreProcessIn_c == On) && (rtu_PreProcessIn_m == WPC_Off) &&
                    (App_Model_DW.Timer_NFCSearchingOffDelay >= 50U))) {
          /* 0.5s */
          exit_atomic_OperationMode_NFC_c();
          App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mod_IN_OperationMode_Picc_o;
          enter_atomic_OperationMode_Pi_m();

          /* 4. */
          /* 50.5s60s */
        } else if ((App_Model_DW.Timer_NFCSearchingOffDelay >= 50U) || (App_Model_DW.Timer_NFCTimeOutConfirm >= 6000U) || (App_Model_DW.Timer_NFCSearchingTimeout >= 150U)) {
          /* 1.5 */
          exit_atomic_OperationMode_NFC_c();
          App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mod_IN_OperationMode_LPCD_m;
          enter_atomic_OperationMode_LP_c(rtu_PreProcessIn_c);
        } else {
          App__NFCSearchingOffDetection_b();
          App_Model_NFCDetectionCheck_h();
        }

        /* End of Outputs for SubSystem: '<S361>/WPC_NFCModeControl_compact' */
      }
    }
    break;

   case App_Mode_IN_OperationMode_Off_j:
    App_Model_B.Output_OPT_WPCStatus = ModeOff;

    /* 1 */
    if ((rtu_PreProcessIn_mb == LPCDMode) && (rtu_PreProcessIn_e != WPCNFCPolling_Search) && (App_Model_DW.Timer_OffLPCDDelay >= 10U)) {
      /* 0.1sec Hold in Off for tes */
      guard2 = true;
    } else if ((App_Model_DW.INT_OPT_WPCStatus_1_prev != App_Model_DW.INT_OPT_WPCStatus_1_start) && (App_Model_DW.INT_OPT_WPCStatus_1_start == PICCMode)) {
      /* Nidec
         PriorityChange5>2_240701 */
      l_previousEvent = App_Model_DW.sfEvent_n;
      App_Model_DW.sfEvent_n = event_CancelTimer_OffLPCDDela_o;
      if (App_Model_DW.is_active_OffLPCDDelay != 0U) {
        App_Model_OffLPCDDelay_k();
      }

      App_Model_DW.sfEvent_n = l_previousEvent;
      App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mod_IN_OperationMode_Picc_o;
      enter_atomic_OperationMode_Pi_m();

      /* 2 */
    } else if (((App_Model_DW.Var_DrDoorPhnLftHoldComplete_pr != App_Model_DW.Var_DrDoorPhnLftHoldComplete_st) && (App_Model_DW.Var_DrDoorPhnLftHoldComplete_st == On)) || ((rtu_PreProcessIn_c == On) &&
                (rtu_PreProcessIn_l == OwnerPairingAdvertisingReq__StartEnable) && (rtu_PreProcessIn_m == WPC_Off) && (rtu_PreProcessIn_mb != WPCMode))) {
      /* Scene#2-0+SWOff_240701 */
      guard2 = true;

      /* Outputs for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' incorporates:
       *  ActionPort: '<S368>/Action Port'
       */
      /* SwitchCase: '<S361>/Switch Case' incorporates:
       *  Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6'
       */
      /* 3
         INT_OPT_WPCStatus_1 != NFCMode &&...240626_PreventSimultaneouslyPolling */
    } else if (rtu_PreProcessIn_e == WPCNFCPolling_Search) {
      l_previousEvent = App_Model_DW.sfEvent_n;
      App_Model_DW.sfEvent_n = event_CancelTimer_OffLPCDDela_o;
      if (App_Model_DW.is_active_OffLPCDDelay != 0U) {
        App_Model_OffLPCDDelay_k();
      }

      App_Model_DW.sfEvent_n = l_previousEvent;
      App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_NFC_f;
      enter_atomic_OperationMode_NF_k();

      /* 5 */
    } else if ((rtu_PreProcessIn_c == On) && (rtu_PreProcessIn_m == WPC_On) && (rtu_PreProcessIn_mb != NFCMode)) {
      /*  &&...]%for Dual 240111%PriorityChange4->5_240701
         INT_OPT_WPCStatus_1 != LPCDMode]%SWOffDividedCase_240701 */
      l_previousEvent = App_Model_DW.sfEvent_n;
      App_Model_DW.sfEvent_n = event_CancelTimer_OffLPCDDela_o;
      if (App_Model_DW.is_active_OffLPCDDelay != 0U) {
        App_Model_OffLPCDDelay_k();
      }

      App_Model_DW.sfEvent_n = l_previousEvent;
      App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_WPC_h;
      App_Model_B.Output_OPT_WPCStatus = WPCMode;

      /* Output_WPC_NFCDetection = NFCDetection_Off; */
    } else {
      App_Model_OffLPCD_Check_p();

      /* OffToLPCDforFollow */
      App_Mo_DrDoorPhnLeftHoldCheck_h(rtu_PreProcessIn_c, rtu_PreProcessIn_cp, rtu_PreProcessIn_h, rtu_PreProcessIn_ai);

      /* 240109 */

      /* End of Outputs for SubSystem: '<S361>/WPC_NFCModeControl_compact' */
    }
    break;

   case App_Mod_IN_OperationMode_Picc_o:
    {
      App_Model_B.Output_OPT_WPCStatus = PICCMode;

      /* 1 */
      if (rtu_PreProcessIn_k == On) {
        /* NFC1 or 2 OnThePad_Off */
        /* PhnRemoveMode */
        l_previousEvent = App_Model_DW.sfEvent_n;
        App_Model_DW.sfEvent_n = event_CancelTimer_PICCOffDela_h;
        if (App_Model_DW.is_active_PICCOffDelay != 0U) {
          App_Model_PICCOffDelay_k();
        }

        App_Model_DW.sfEvent_n = l_previousEvent;
        App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mod_IN_OperationMode_LPCD_m;

        /* Outputs for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' incorporates:
         *  ActionPort: '<S368>/Action Port'
         */
        /* SwitchCase: '<S361>/Switch Case' incorporates:
         *  Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6'
         */
        enter_atomic_OperationMode_LP_c(rtu_PreProcessIn_c);

        /* End of Outputs for SubSystem: '<S361>/WPC_NFCModeControl_compact' */

        /* 2 */
      } else if ((rtu_PreProcessIn_c == Off) && (App_Model_DW.Timer_PICCOffDelay >= 6000U)) {
        guard3 = true;
      } else {
        LC_IAUWPCNFCcmd tmp_0;

        /* 3 */
        tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_2_start;
        if ((App_Model_DW.Input_IAUWPCNFCcmd_2_prev != tmp_0) && (tmp_0 == WPCNFCPolling_Search)) {
          /* PhnRemoveMode */
          l_previousEvent = App_Model_DW.sfEvent_n;
          App_Model_DW.sfEvent_n = event_CancelTimer_PICCOffDela_h;
          if (App_Model_DW.is_active_PICCOffDelay != 0U) {
            App_Model_PICCOffDelay_k();
          }

          App_Model_DW.sfEvent_n = l_previousEvent;
          App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_NFC_f;
          enter_atomic_OperationMode_NF_k();

          /* 45sec */
        } else if ((rtu_PreProcessIn_c == On) && (rtu_PreProcessIn_m == WPC_On) && ((rtu_PreProcessIn_b == OnThePad_On) || ((rtu_PreProcessIn_b == OnThePad_Default) && (App_Model_DW.Timer_PICCOffDelay
          >= 500U)) || (rtu_PreProcessIn_mb == WPCMode))) {
          /* TransitionMerge_240912 */
          /* PhnRemoveMode */
          l_previousEvent = App_Model_DW.sfEvent_n;
          App_Model_DW.sfEvent_n = event_CancelTimer_PICCOffDela_h;
          if (App_Model_DW.is_active_PICCOffDelay != 0U) {
            App_Model_PICCOffDelay_k();
          }

          App_Model_DW.sfEvent_n = l_previousEvent;
          App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_WPC_h;
          App_Model_B.Output_OPT_WPCStatus = WPCMode;

          /* Output_WPC_NFCDetection = NFCDetection_Off; */

          /* 240112_Simultenously ModeOff_Nidec */
        } else if (((rtu_PreProcessIn_c == Off) && ((App_Model_DW.INT_OPT_WPCStatus_1_prev != App_Model_DW.INT_OPT_WPCStatus_1_start) && (App_Model_DW.INT_OPT_WPCStatus_1_start == ModeOff))) ||
                   ((App_Model_DW.INT_OPT_WPCStatus_1_prev != App_Model_DW.INT_OPT_WPCStatus_1_start) && (App_Model_DW.INT_OPT_WPCStatus_1_start == NFCMode)) || ((rtu_PreProcessIn_m == WPC_Off) &&
                    ((rtu_PreProcessIn_mb == WPCMode) || (App_Model_DW.Timer_PICCOffDelay >= 6000U)))) {
          /* 240626 */
          /* WPCSWOffALL_Case_240911 */
          guard3 = true;
        } else {
          /* %WPCSWOption_Off Case */
        }
      }
    }
    break;

   case App_Mode_IN_OperationMode_WPC_h:
    {
      App_Model_B.Output_OPT_WPCStatus = WPCMode;
      if (rtu_PreProcessIn_mb == LPCDMode) {
        /* WhileWPC1isSWOff, WPC1MoveFromOFFtoLPCD */
        guard4 = true;
      } else {
        LC_IAUWPCNFCcmd tmp_0;

        /* 1 */
        tmp_0 = App_Model_DW.Input_IAUWPCNFCcmd_2_start;
        if ((App_Model_DW.Input_IAUWPCNFCcmd_2_prev != tmp_0) && (tmp_0 == WPCNFCPolling_Search) && (rtu_PreProcessIn_mb != NFCMode)) {
          /* WaitingforNFCCom */
          App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_NFC_f;
          enter_atomic_OperationMode_NF_k();

          /* 2%When WPC1&2 are Both ChargingOnThePad_Off || ObjectOnthePad_Off */
        } else if (((rtu_PreProcessIn_p == On) || (rtu_PreProcessIn_hl == On)) && ((rtu_PreProcessIn_j == OwnerPhnReg__Disable) || (rtu_PreProcessIn_j == OwnerPhnReg__Default) || (rtu_PreProcessIn_j ==
          OwnerPhnReg__Invalid)) && (rtu_PreProcessIn_l == OwnerPairingAdvertisingReq__StartEnable)) {
          App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mod_IN_OperationMode_Picc_o;
          enter_atomic_OperationMode_Pi_m();

          /* 3 */
        } else if ((rtu_PreProcessIn_c == Off) || (rtu_PreProcessIn_m == WPC_Off) || (rtu_PreProcessIn_mb == NFCMode)) {
          /* PollingSearchDivided_240626 */
          guard4 = true;
        }
      }
    }
    break;
  }

  if (guard4) {
    App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_Off_j;

    /* Outputs for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' incorporates:
     *  ActionPort: '<S368>/Action Port'
     */
    /* SwitchCase: '<S361>/Switch Case' incorporates:
     *  Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6'
     */
    enter_atomic_OperationMode_Of_n(rtu_PreProcessIn_c, rtu_PreProcessIn_cp, rtu_PreProcessIn_h, rtu_PreProcessIn_ai);

    /* End of Outputs for SubSystem: '<S361>/WPC_NFCModeControl_compact' */
  }

  if (guard3) {
    /* PhnRemoveMode */
    l_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_CancelTimer_PICCOffDela_h;
    if (App_Model_DW.is_active_PICCOffDelay != 0U) {
      App_Model_PICCOffDelay_k();
    }

    App_Model_DW.sfEvent_n = l_previousEvent;
    App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_Off_j;

    /* Outputs for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' incorporates:
     *  ActionPort: '<S368>/Action Port'
     */
    /* SwitchCase: '<S361>/Switch Case' incorporates:
     *  Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6'
     */
    enter_atomic_OperationMode_Of_n(rtu_PreProcessIn_c, rtu_PreProcessIn_cp, rtu_PreProcessIn_h, rtu_PreProcessIn_ai);

    /* End of Outputs for SubSystem: '<S361>/WPC_NFCModeControl_compact' */
  }

  if (guard2) {
    l_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_CancelTimer_OffLPCDDela_o;
    if (App_Model_DW.is_active_OffLPCDDelay != 0U) {
      App_Model_OffLPCDDelay_k();
    }

    App_Model_DW.sfEvent_n = l_previousEvent;
    App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mod_IN_OperationMode_LPCD_m;

    /* Outputs for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' incorporates:
     *  ActionPort: '<S368>/Action Port'
     */
    /* SwitchCase: '<S361>/Switch Case' incorporates:
     *  Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6'
     */
    enter_atomic_OperationMode_LP_c(rtu_PreProcessIn_c);

    /* End of Outputs for SubSystem: '<S361>/WPC_NFCModeControl_compact' */
  }

  if (guard1) {
    /* 230406 */
    l_previousEvent = App_Model_DW.sfEvent_n;
    App_Model_DW.sfEvent_n = event_CancelTimer_LPCDOffDela_i;
    if (App_Model_DW.is_active_LPCDOffDelay != 0U) {
      App_Model_LPCDOffDelay_j();
    }

    /* send(CancelTimer_OffLPCDDelay, OffLPCDDelay); */
    App_Model_DW.sfEvent_n = event_CancelTimer_PICCLPCDOff_k;
    if (App_Model_DW.is_active_PICCLPCDOffDelay != 0U) {
      App_Model_PICCLPCDOffDelay_j();
    }

    App_Model_DW.sfEvent_n = l_previousEvent;
    App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_Off_j;

    /* Outputs for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' incorporates:
     *  ActionPort: '<S368>/Action Port'
     */
    /* SwitchCase: '<S361>/Switch Case' incorporates:
     *  Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6'
     */
    enter_atomic_OperationMode_Of_n(rtu_PreProcessIn_c, rtu_PreProcessIn_cp, rtu_PreProcessIn_h, rtu_PreProcessIn_ai);

    /* End of Outputs for SubSystem: '<S361>/WPC_NFCModeControl_compact' */
  }
}

/* System initialize for atomic system: '<S203>/NFC_WPC_Mode_Control_Function' */
void NFC_WPC_Mode_Control_Fun_f_Init(WPCStatus *rty_WPC2Status)
{
  /* SystemInitialize for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' */
  /* SystemInitialize for Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
  App_Model_DW.sfEvent_n = App_Model_CALL_EVENT_p;
  App_Model_B.Output_OPT_WPCStatus = WPCMode;
  App_Model_DW.INT_OPT_WPCStatus_1_prev = WPCMode;
  App_Model_DW.INT_OPT_WPCStatus_1_start = WPCMode;
  App_Model_DW.Input_OPT_WPCSWOption_prev = WPC_On;
  App_Model_DW.Input_OPT_WPCSWOption_start = WPC_On;

  /* End of SystemInitialize for SubSystem: '<S361>/WPC_NFCModeControl_compact' */

  /* SystemInitialize for Merge: '<S361>/Merge' */
  *rty_WPC2Status = WPCMode;
}

/* Output and update for atomic system: '<S203>/NFC_WPC_Mode_Control_Function' */
void NFC_WPC_Mode_Control_Function_m(Bool rtu_PreProcessIn, Bool rtu_PreProcessIn_c, LC_IAUWPCNFCcmd rtu_PreProcessIn_e, C_WPCOnOffNvalueSet rtu_PreProcessIn_m, IAU_OwnerPhnRegRVal rtu_PreProcessIn_j,
  OwnerPairingAdvertisingReq rtu_PreProcessIn_l, OnThePad rtu_PreProcessIn_b, Bool rtu_PreProcessIn_k, Bool rtu_PreProcessIn_p, WPCStatus rtu_PreProcessIn_mb, uint8 rtu_PreProcessIn_a, uint8
  rtu_PreProcessIn_p5, Bool rtu_PreProcessIn_cp, C_WPCWarning rtu_PreProcessIn_h, Bool rtu_PreProcessIn_ai, LC_IAUWPCNFCcmd rtu_PreProcessIn_d, Bool rtu_PreProcessIn_hl, Bool rtu_PreProcessIn_jq,
  WPCStatus *rty_WPC2Status)
{
  /* SwitchCase: '<S361>/Switch Case' */
  switch (rtu_PreProcessIn) {
   case Off:
    /* Outputs for IfAction SubSystem: '<S361>/WPC_Mode_Control' incorporates:
     *  ActionPort: '<S367>/Action Port'
     */
    App_Model_WPC_Mode_Control(rtu_PreProcessIn_c, rtu_PreProcessIn_m, rtu_PreProcessIn_jq, rty_WPC2Status, &App_Model_DW.WPC_Mode_Control_l);

    /* End of Outputs for SubSystem: '<S361>/WPC_Mode_Control' */
    break;

   case On:
    {
      /* Outputs for IfAction SubSystem: '<S361>/WPC_NFCModeControl_compact' incorporates:
       *  ActionPort: '<S368>/Action Port'
       */
      /* Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */
      App_Model_DW.sfEvent_n = App_Model_CALL_EVENT_p;
      App_Model_DW.INT_NFCDetectOrder_prev = App_Model_DW.INT_NFCDetectOrder_start;
      App_Model_DW.INT_NFCDetectOrder_start = rtu_PreProcessIn_p5;
      App_Model_DW.Input_IAUWPCNFCcmd_2_prev = App_Model_DW.Input_IAUWPCNFCcmd_2_start;
      App_Model_DW.Input_IAUWPCNFCcmd_2_start = rtu_PreProcessIn_e;
      App_Model_DW.INT_OPT_WPCStatus_1_prev = App_Model_DW.INT_OPT_WPCStatus_1_start;
      App_Model_DW.INT_OPT_WPCStatus_1_start = rtu_PreProcessIn_mb;
      App_Model_DW.Input_b_DrvDrSw_prev = App_Model_DW.Input_b_DrvDrSw_start;
      App_Model_DW.Input_b_DrvDrSw_start = rtu_PreProcessIn_cp;
      App_Model_DW.Input_PhnLeftChk_Enable_prev = App_Model_DW.Input_PhnLeftChk_Enable_start;
      App_Model_DW.Input_PhnLeftChk_Enable_start = rtu_PreProcessIn_ai;
      App_Model_DW.Var_DrDoorPhnLftHoldComplete_pr = App_Model_DW.Var_DrDoorPhnLftHoldComplete_st;
      App_Model_DW.Var_DrDoorPhnLftHoldComplete_st = App_Model_DW.Var_DrDoorPhnLftHoldComplete;
      App_Model_DW.INT_LPCDWakeUpOrder_prev = App_Model_DW.INT_LPCDWakeUpOrder_start;
      App_Model_DW.INT_LPCDWakeUpOrder_start = rtu_PreProcessIn_a;
      App_Model_DW.Input_IAUWPCNFCcmd_1_prev = App_Model_DW.Input_IAUWPCNFCcmd_1_start;
      App_Model_DW.Input_IAUWPCNFCcmd_1_start = rtu_PreProcessIn_d;
      App_Model_DW.Input_b_IGN1_IN_prev = App_Model_DW.Input_b_IGN1_IN_start;
      App_Model_DW.Input_b_IGN1_IN_start = rtu_PreProcessIn_c;
      App_Model_DW.Input_OPT_WPCSWOption_prev = App_Model_DW.Input_OPT_WPCSWOption_start;
      App_Model_DW.Input_OPT_WPCSWOption_start = rtu_PreProcessIn_m;
      if (App_Model_DW.is_active_c37_NFC_WPC_Mode_Cont == 0U) {
        App_Model_DW.INT_NFCDetectOrder_prev = rtu_PreProcessIn_p5;
        App_Model_DW.Input_IAUWPCNFCcmd_2_prev = rtu_PreProcessIn_e;
        App_Model_DW.INT_OPT_WPCStatus_1_prev = rtu_PreProcessIn_mb;
        App_Model_DW.Input_b_DrvDrSw_prev = rtu_PreProcessIn_cp;
        App_Model_DW.Input_PhnLeftChk_Enable_prev = rtu_PreProcessIn_ai;
        App_Model_DW.INT_LPCDWakeUpOrder_prev = rtu_PreProcessIn_a;
        App_Model_DW.Input_IAUWPCNFCcmd_1_prev = rtu_PreProcessIn_d;
        App_Model_DW.Input_b_IGN1_IN_prev = rtu_PreProcessIn_c;
        App_Model_DW.Input_OPT_WPCSWOption_prev = rtu_PreProcessIn_m;
        App_Model_DW.is_active_c37_NFC_WPC_Mode_Cont = 1U;
        App_Model_DW.is_active_NFCTimeOutConfirm = 1U;
        App_Model_DW.is_NFCTimeOutConfirm = App__IN_NFCTimeOutConfirm_Off_f;
        App_Model_DW.Timer_NFCTimeOutConfirm = 0U;
        App_Model_DW.is_active_NFCSearchingOffDelay = 1U;
        App_Model_DW.is_NFCSearchingOffDelay = A_IN_NFCSearchingOffDelay_Off_n;
        App_Model_DW.Timer_NFCSearchingOffDelay = 0U;
        App_Model_DW.is_active_DeviceStateWait = 1U;
        App_Model_DW.is_DeviceStateWait = App_Mo_IN_DeviceStateWait_Off_h;
        App_Model_DW.Timer_DeviceStateWait = 0U;
        App_Model_DW.is_active_LPCDOffDelay = 1U;
        App_Model_DW.is_LPCDOffDelay = App_Model_IN_LPCDOffDelay_Off_c;
        App_Model_DW.b_Timer_LPCDOffDelay_is_Running = false;
        App_Model_DW.Timer_LPCDOffDelay = 0U;
        App_Model_DW.is_active_NFCSearchingTimeout = 1U;
        App_Model_DW.is_NFCSearchingTimeout = Ap_IN_NFCSearchingTimeout_Off_j;
        App_Model_DW.Timer_NFCSearchingTimeout = 0U;
        App_Model_DW.is_active_PhnLeftHolding = 1U;
        App_Model_DW.is_PhnLeftHolding = App_Mod_IN_PhnLeftHolding_Off_f;
        App_Model_DW.Timer_PhnLeftHolding = 0U;
        App_Model_DW.is_active_PICCOffDelay = 1U;
        App_Model_DW.is_PICCOffDelay = App_Model_IN_PICCOffDelay_Off_k;
        App_Model_DW.Timer_PICCOffDelay = 0U;
        App_Model_DW.is_active_WPC_NFC_Mode_Control_ = 1U;

        /* Default */
        App_Model_DW.is_WPC_NFC_Mode_Control_Functio = App_Mode_IN_OperationMode_Off_j;
        enter_atomic_OperationMode_Of_n(rtu_PreProcessIn_c, rtu_PreProcessIn_cp, rtu_PreProcessIn_h, rtu_PreProcessIn_ai);
        App_Model_DW.is_active_OffLPCDDelay = 1U;
        App_Model_DW.is_OffLPCDDelay = App_Model_IN_LPCDOffDelay_Off_c;
        App_Model_DW.Timer_OffLPCDDelay = 0U;
        App_Model_DW.is_active_PICCLPCDOffDelay = 1U;
        App_Model_DW.is_PICCLPCDOffDelay = App_M_IN_PICCLPCDOffDelay_Off_l;
        App_Model_DW.Timer_PICCLPCDOffDelay = 0U;
        App_Model_DW.is_active_PhnLeftChattering = 1U;
        App_Model_DW.is_PhnLeftChattering = App__IN_PhnLeftChattering_Off_c;
        App_Model_DW.b_Timer_PhnLeftChattering_is_Ru = false;
        App_Model_DW.Timer_PhnLeftChattering = 0U;
      } else {
        uint32 qY;
        if (App_Model_DW.is_active_NFCTimeOutConfirm != 0U) {
          App_Model_NFCTimeOutConfirm_e();
        }

        if (App_Model_DW.is_active_NFCSearchingOffDelay != 0U) {
          App_Mode_NFCSearchingOffDelay_p();
        }

        if (App_Model_DW.is_active_DeviceStateWait != 0U) {
          switch (App_Model_DW.is_DeviceStateWait) {
           case App_Mo_IN_DeviceStateWait_Off_h:
            break;

           case App_Mod_IN_DeviceStateWait_On_d:
            qY = App_Model_DW.Timer_DeviceStateWait + /*MW:OvSatOk*/ 1U;
            if (App_Model_DW.Timer_DeviceStateWait + 1U < App_Model_DW.Timer_DeviceStateWait) {
              qY = MAX_uint32_T;
            }

            App_Model_DW.Timer_DeviceStateWait = qY;
            break;
          }
        }

        if (App_Model_DW.is_active_LPCDOffDelay != 0U) {
          App_Model_LPCDOffDelay_j();
        }

        if (App_Model_DW.is_active_NFCSearchingTimeout != 0U) {
          App_Model_NFCSearchingTimeout_k();
        }

        if (App_Model_DW.is_active_PhnLeftHolding != 0U) {
          switch (App_Model_DW.is_PhnLeftHolding) {
           case App_Mod_IN_PhnLeftHolding_Off_f:
            break;

           case App_Mode_IN_PhnLeftHolding_On_m:
            qY = App_Model_DW.Timer_PhnLeftHolding + /*MW:OvSatOk*/ 1U;
            if (App_Model_DW.Timer_PhnLeftHolding + 1U < App_Model_DW.Timer_PhnLeftHolding) {
              qY = MAX_uint32_T;
            }

            App_Model_DW.Timer_PhnLeftHolding = qY;
            break;
          }
        }

        if (App_Model_DW.is_active_PICCOffDelay != 0U) {
          App_Model_PICCOffDelay_k();
        }

        if (App_Model_DW.is_active_WPC_NFC_Mode_Control_ != 0U) {
          WPC_NFC_Mode_Control_Function_c(rtu_PreProcessIn_c, rtu_PreProcessIn_e, rtu_PreProcessIn_m, rtu_PreProcessIn_j, rtu_PreProcessIn_l, rtu_PreProcessIn_b, rtu_PreProcessIn_k, rtu_PreProcessIn_p,
            rtu_PreProcessIn_mb, rtu_PreProcessIn_cp, rtu_PreProcessIn_h, rtu_PreProcessIn_ai, rtu_PreProcessIn_hl);
        }

        if (App_Model_DW.is_active_OffLPCDDelay != 0U) {
          App_Model_OffLPCDDelay_k();
        }

        if (App_Model_DW.is_active_PICCLPCDOffDelay != 0U) {
          App_Model_PICCLPCDOffDelay_j();
        }

        if (App_Model_DW.is_active_PhnLeftChattering != 0U) {
          App_Model_PhnLeftChattering_h();
        }
      }

      /* End of Chart: '<S368>/NFC_WPC_Mode_Control_MPPEPP_2_r6' */

      /* SignalConversion: '<S368>/Signal Conversion1' */
      *rty_WPC2Status = App_Model_B.Output_OPT_WPCStatus;

      /* End of Outputs for SubSystem: '<S361>/WPC_NFCModeControl_compact' */
    }
    break;
  }

  /* End of SwitchCase: '<S361>/Switch Case' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
