/*
 * File: WPC_MainControl_Function.c
 *
 * Code generated for Simulink model 'App_Model'.
 *
 * Model version                  : 1.622
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Fri Oct  4 15:38:22 2024
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "App_Model_types.h"
#include "rtwtypes.h"
#include "WPC_MainControl_Function.h"
#include "App_Model.h"

/* Named constants for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
#define A_event_Start_Timer_AmberINDBlk (7)
#define A_event_Start_Timer_GreenINDBlk (9)
#define Ap_event_Cancel_Timer_PhoneLeft (3)
#define App_M_IN_LeavingPhone_NoWarning ((uint8)1U)
#define App_Mod_IN_LeavingPhone_Warning ((uint8)2U)
#define App_Model_CALL_EVENT_d         (-1)
#define App_Model_IN_CardDetectError   ((uint8)1U)
#define App_Model_IN_NO_ACTIVE_CHILD_dl ((uint8)0U)
#define App_Model_IN_Off_c             ((uint8)1U)
#define App_Model_IN_On_hk             ((uint8)2U)
#define App_Model_IN_WPCMode_Disable   ((uint8)1U)
#define App_Model_IN_WPCMode_Enable    ((uint8)2U)
#define App_Model_IN_WPCMode_Init      ((uint8)3U)
#define App_Model_IN_WPCMode_NFC       ((uint8)1U)
#define App_Model_IN_WPCMode_Off       ((uint8)2U)
#define App_Model_IN_WPCMode_Run       ((uint8)1U)
#define App_Model_IN_WPCMode_Stop      ((uint8)2U)
#define App_Model_IN_WPCRun_Charging   ((uint8)1U)
#define App_Model_IN_WPCRun_FODError   ((uint8)3U)
#define App_Model_IN_WPCRun_Standby    ((uint8)4U)
#define App_Model_IN_WPCStop_NotTempErr ((uint8)2U)
#define App_Model_IN_WPCStop_TempErr   ((uint8)3U)
#define App__IN_WPCRun_ChargingComplete ((uint8)2U)
#define App_event_Start_Timer_PhoneLeft (10)
#define event_Cancel_Timer_AmberINDBlk (0)
#define event_Cancel_Timer_AmberINDBlk2 (1)
#define event_Cancel_Timer_GreenINDBlk (2)
#define event_Cancel_Timer_PhoneReminde (4)
#define event_Cancel_Timer_PhoneWarning (5)
#define event_Cancel_Timer_WarningCompl (6)
#define event_Start_Timer_AmberINDBlk2 (8)
#define event_Start_Timer_PhoneReminder (11)
#define event_Start_Timer_PhoneWarningC (12)
#define event_Start_Timer_WarningComple (13)

/* Named constants for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
#define A_event_Start_Timer_PhoneLeft_b (10)
#define Ap_IN_WPCRun_ChargingComplete_a ((uint8)2U)
#define App_IN_LeavingPhone_NoWarning_i ((uint8)1U)
#define App_M_IN_LeavingPhone_Warning_a ((uint8)2U)
#define App_Mod_IN_WPCStop_NotTempErr_f ((uint8)2U)
#define App_Model_CALL_EVENT_ac        (-1)
#define App_Model_IN_CardDetectError_f ((uint8)1U)
#define App_Model_IN_NO_ACTIVE_CHILD_kn ((uint8)0U)
#define App_Model_IN_Off_h             ((uint8)1U)
#define App_Model_IN_On_b              ((uint8)2U)
#define App_Model_IN_WPCMode_Disable_p ((uint8)1U)
#define App_Model_IN_WPCMode_Enable_b  ((uint8)2U)
#define App_Model_IN_WPCMode_Init_o    ((uint8)3U)
#define App_Model_IN_WPCMode_NFC_i     ((uint8)1U)
#define App_Model_IN_WPCMode_Off_o     ((uint8)2U)
#define App_Model_IN_WPCMode_Run_h     ((uint8)1U)
#define App_Model_IN_WPCMode_Stop_m    ((uint8)2U)
#define App_Model_IN_WPCRun_Charging_f ((uint8)1U)
#define App_Model_IN_WPCRun_FODError_d ((uint8)3U)
#define App_Model_IN_WPCRun_Standby_a  ((uint8)4U)
#define App_Model_IN_WPCStop_TempErr_c ((uint8)3U)
#define event_Cancel_Timer_AmberINDBl_e (1)
#define event_Cancel_Timer_AmberINDBl_g (0)
#define event_Cancel_Timer_GreenINDBl_l (2)
#define event_Cancel_Timer_PhoneLeft_c (3)
#define event_Cancel_Timer_PhoneRemin_k (4)
#define event_Cancel_Timer_PhoneWarni_c (5)
#define event_Cancel_Timer_WarningCom_m (6)
#define event_Start_Timer_AmberINDBlk_l (8)
#define event_Start_Timer_AmberINDBlk_m (7)
#define event_Start_Timer_GreenINDBlk_n (9)
#define event_Start_Timer_PhoneRemind_o (11)
#define event_Start_Timer_PhoneWarnin_a (12)
#define event_Start_Timer_WarningComp_j (13)

/* Forward declaration for local functions */
static void App_M_Function_ChargingINDColor(WPCIndUSMState rtu_Main_InSig_lz, Bool rtu_Main_InSig_f, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g);
static void App_Mod_Tick_Timer_AmberINDBlk2(void);
static void App_Mode_Tick_Timer_AmberINDBlk(void);
static void App_Mode_Function_LEDErrorBlink(WPCIndUSMState rtu_Main_InSig_lz, Bool rtu_Main_InSig_h0, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, BlinkState *rty_MainOut_Sig_h);
static void App_M_exit_internal_WPCMode_Run(Bool *rty_MainOut_Sig_gy, BlinkState *rty_MainOut_Sig_h);
static void App_Mode_Tick_Timer_GreenINDBlk(void);
static void App__Function_CardLEDErrorBlink(Bool rtu_Main_InSig_h0, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_gy, BlinkState *rty_MainOut_Sig_h);
static void App_enter_internal_WPCMode_Stop(Bool rtu_Main_InSig_gy, WPCIndUSMState rtu_Main_InSig_lz, Bool rtu_Main_InSig_h0, Bool rtu_Main_InSig_f, C_WPCWarning *rty_MainOut_Sig, Bool
  *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, Bool *rty_MainOut_Sig_a, BlinkState *rty_MainOut_Sig_h);
static void App_Model_WPCMode_Run(Bool rtu_Main_InSig, Bool rtu_Main_InSig_m, Bool rtu_Main_InSig_l, Bool rtu_Main_InSig_gy, DeviceState rtu_Main_InSig_a, WPCIndUSMState rtu_Main_InSig_lz, Bool
  rtu_Main_InSig_h0, Bool rtu_Main_InSig_f, C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_m, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, Bool *rty_MainOut_Sig_a,
  BlinkState *rty_MainOut_Sig_h);
static void App__exit_internal_WPCMode_Stop(Bool *rty_MainOut_Sig_gy, BlinkState *rty_MainOut_Sig_h);
static void Ap_enter_atomic_WPCMode_Disable(C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_m, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, BlinkState *rty_MainOut_Sig_h, Bool
  *rty_MainOut_Sig_k);
static void App_Model_Tick_Timer_PhoneLeft(void);
static void Ap_Tick_Timer_PhoneWarningCheck(uint16 *rty_MainOut_Sig_j);
static void A_Tick_Timer_PhoneReminderCheck(uint16 *rty_MainOut_Sig_b);
static void App__Tick_Timer_WarningComplete(uint16 *rty_MainOut_Sig_jy);
static void App_Model_Function_WPCWarning(C_WPCOnOffNvalueSet rtu_Main_InSig_g, Bool rtu_Main_InSig_b, Bool rtu_Main_InSig_j, Bool rtu_Main_InSig_jy, C_WPCWarning *rty_MainOut_Sig, uint16
  *rty_MainOut_Sig_b, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_jy, Bool *rty_MainOut_Sig_k);
static void App_Mo_enter_atomic_WPCMode_NFC(uint16 *rty_MainOut_Sig_b, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_jy);
static void enter_internal_WPCMode_Disable(C_WPCOnOffNvalueSet rtu_Main_InSig_g, Bool rtu_Main_InSig_b, Bool rtu_Main_InSig_j, Bool rtu_Main_InSig_jy, WPCStatus rtu_Main_InSig_h, C_WPCWarning
  *rty_MainOut_Sig, uint16 *rty_MainOut_Sig_b, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_jy, Bool *rty_MainOut_Sig_k);
static void App_Model_MainControl(Bool rtu_Main_InSig, Bool rtu_Main_InSig_m, Bool rtu_Main_InSig_l, C_WPCOnOffNvalueSet rtu_Main_InSig_g, Bool rtu_Main_InSig_gy, Bool rtu_Main_InSig_b, Bool
  rtu_Main_InSig_j, Bool rtu_Main_InSig_jy, DeviceState rtu_Main_InSig_a, WPCStatus rtu_Main_InSig_h, WPCIndUSMState rtu_Main_InSig_lz, Bool rtu_Main_InSig_h0, Bool rtu_Main_InSig_f, C_WPCWarning
  *rty_MainOut_Sig, Bool *rty_MainOut_Sig_m, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, uint16 *rty_MainOut_Sig_b, uint16 *rty_MainOut_Sig_j, uint16
  *rty_MainOut_Sig_jy, Bool *rty_MainOut_Sig_a, BlinkState *rty_MainOut_Sig_h, Bool *rty_MainOut_Sig_k);
static void enter_internal_Tick_Timer_Phone(void);
static void enter_internal_Tick_Timer_Pho_e(uint16 *rty_MainOut_Sig_j);
static void enter_internal_Tick_Timer_Pho_d(uint16 *rty_MainOut_Sig_b);
static void enter_internal_Tick_Timer_Warni(uint16 *rty_MainOut_Sig_jy);
static void enter_internal_Tick_Timer_Amber(void);
static void enter_internal_Tick_Timer_Amb_m(void);
static void enter_internal_Tick_Timer_Green(void);

/* Forward declaration for local functions */
static void App_Function_ChargingINDColor_e(WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_n4, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e);
static void App_M_Tick_Timer_AmberINDBlk2_n(void);
static void App_Mo_Tick_Timer_AmberINDBlk_j(void);
static void App_Mo_Function_LEDErrorBlink_k(WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_nw, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, BlinkState *rty_MainOut_Sig_po);
static void App_exit_internal_WPCMode_Run_c(Bool *rty_MainOut_Sig_gc, BlinkState *rty_MainOut_Sig_po);
static void App_Mo_Tick_Timer_GreenINDBlk_f(void);
static void Ap_Function_CardLEDErrorBlink_e(Bool rtu_Main_InSig_nw, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_gc, BlinkState *rty_MainOut_Sig_po);
static void A_enter_internal_WPCMode_Stop_d(Bool rtu_Main_InSig_b, WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_nw, Bool rtu_Main_InSig_n4, C_WPCWarning *rty_MainOut_Sig, Bool
  *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, Bool *rty_MainOut_Sig_p, BlinkState *rty_MainOut_Sig_po);
static void App_Model_WPCMode_Run_h(Bool rtu_Main_InSig, Bool rtu_Main_InSig_g, Bool rtu_Main_InSig_b, DeviceState rtu_Main_InSig_nt, WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_nw, Bool
  rtu_Main_InSig_n4, C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, Bool *rty_MainOut_Sig_p, BlinkState
  *rty_MainOut_Sig_po);
static void Ap_exit_internal_WPCMode_Stop_e(Bool *rty_MainOut_Sig_gc, BlinkState *rty_MainOut_Sig_po);
static void enter_atomic_WPCMode_Disable_p(C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, BlinkState *rty_MainOut_Sig_po, Bool
  *rty_MainOut_Sig_k);
static void App_Mode_Tick_Timer_PhoneLeft_o(void);
static void Tick_Timer_PhoneWarningCheck_e(uint16 *rty_MainOut_Sig_n);
static void Tick_Timer_PhoneReminderCheck_h(uint16 *rty_MainOut_Sig_j);
static void Ap_Tick_Timer_WarningComplete_i(uint16 *rty_MainOut_Sig_nt);
static void App_Model_Function_WPCWarning_e(C_WPCOnOffNvalueSet rtu_Main_InSig_e, Bool rtu_Main_InSig_gc, Bool rtu_Main_InSig_j, Bool rtu_Main_InSig_n, C_WPCWarning *rty_MainOut_Sig, uint16
  *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt, Bool *rty_MainOut_Sig_k);
static void App__enter_atomic_WPCMode_NFC_g(uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt);
static void enter_internal_WPCMode_Disabl_k(C_WPCOnOffNvalueSet rtu_Main_InSig_e, Bool rtu_Main_InSig_gc, Bool rtu_Main_InSig_j, Bool rtu_Main_InSig_n, WPCStatus rtu_Main_InSig_p, C_WPCWarning
  *rty_MainOut_Sig, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt, Bool *rty_MainOut_Sig_k);
static void App_Model_MainControl_g(Bool rtu_Main_InSig, Bool rtu_Main_InSig_g, Bool rtu_Main_InSig_b, C_WPCOnOffNvalueSet rtu_Main_InSig_e, Bool rtu_Main_InSig_gc, Bool rtu_Main_InSig_j, Bool
  rtu_Main_InSig_n, DeviceState rtu_Main_InSig_nt, WPCStatus rtu_Main_InSig_p, WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_nw, Bool rtu_Main_InSig_n4, C_WPCWarning *rty_MainOut_Sig, Bool
  *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt, Bool
  *rty_MainOut_Sig_p, BlinkState *rty_MainOut_Sig_po, Bool *rty_MainOut_Sig_k);
static void enter_internal_Tick_Timer_Pho_b(void);
static void enter_internal_Tick_Timer_Ph_bo(uint16 *rty_MainOut_Sig_n);
static void enter_internal_Tick_Timer_Pho_n(uint16 *rty_MainOut_Sig_j);
static void enter_internal_Tick_Timer_War_f(uint16 *rty_MainOut_Sig_nt);
static void enter_internal_Tick_Timer_Amb_n(void);
static void enter_internal_Tick_Timer_Amb_h(void);
static void enter_internal_Tick_Timer_Gre_o(void);

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_M_Function_ChargingINDColor(WPCIndUSMState rtu_Main_InSig_lz, Bool rtu_Main_InSig_f, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g)
{
  /* 1. */
  if ((rtu_Main_InSig_lz == WPCIndUSMState__Type2) || (rtu_Main_InSig_f == On)) {
    /* CardDetect_240207] */
    *rty_MainOut_Sig_l = On;
    *rty_MainOut_Sig_g = Off;
  } else {
    *rty_MainOut_Sig_l = Off;
    *rty_MainOut_Sig_g = On;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_Mod_Tick_Timer_AmberINDBlk2(void)
{
  switch (App_Model_DW.is_Tick_Timer_AmberINDBlk2_e) {
   case App_Model_IN_Off_c:
    if (App_Model_DW.sfEvent_a == event_Start_Timer_AmberINDBlk2) {
      App_Model_DW.is_Tick_Timer_AmberINDBlk2_e = App_Model_IN_On_hk;
    }
    break;

   case App_Model_IN_On_hk:
    {
      if (App_Model_DW.sfEvent_a == event_Cancel_Timer_AmberINDBlk2) {
        App_Model_DW.is_Tick_Timer_AmberINDBlk2_e = App_Model_IN_Off_c;
        App_Model_DW.Timer_AmberINDBlk2_p = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_AmberINDBlk2_p + 1;
        if (App_Model_DW.Timer_AmberINDBlk2_p + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_AmberINDBlk2_p = (uint16)tmp;
        if (App_Model_DW.sfEvent_a == event_Start_Timer_AmberINDBlk2) {
          App_Model_DW.Timer_AmberINDBlk2_p = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_Mode_Tick_Timer_AmberINDBlk(void)
{
  switch (App_Model_DW.is_Tick_Timer_AmberINDBlk_f) {
   case App_Model_IN_Off_c:
    if (App_Model_DW.sfEvent_a == A_event_Start_Timer_AmberINDBlk) {
      App_Model_DW.is_Tick_Timer_AmberINDBlk_f = App_Model_IN_On_hk;
    }
    break;

   case App_Model_IN_On_hk:
    {
      if (App_Model_DW.sfEvent_a == event_Cancel_Timer_AmberINDBlk) {
        App_Model_DW.is_Tick_Timer_AmberINDBlk_f = App_Model_IN_Off_c;
        App_Model_DW.Timer_AmberINDBlk_l = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_AmberINDBlk_l + 1;
        if (App_Model_DW.Timer_AmberINDBlk_l + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_AmberINDBlk_l = (uint16)tmp;
        if (App_Model_DW.sfEvent_a == A_event_Start_Timer_AmberINDBlk) {
          App_Model_DW.Timer_AmberINDBlk_l = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_Mode_Function_LEDErrorBlink(WPCIndUSMState rtu_Main_InSig_lz, Bool rtu_Main_InSig_h0, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, BlinkState *rty_MainOut_Sig_h)
{
  switch (rtu_Main_InSig_h0) {
   case Off:
    {
      /* For_OnlyAmber%WPC�� �ϳ��̰ų� �켱������ ���� ������� */
      /* 1. */
      if ((*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.Counter_BlinkCnt_a >= 10)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkComplete;
        *rty_MainOut_Sig_g = Off;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;
        *rty_MainOut_Sig_gy = Off;

        /*  Non GFS  */
      } else if (App_Model_DW.Counter_BlinkCnt_a >= 10) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkComplete;
        *rty_MainOut_Sig_g = Off;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;
        *rty_MainOut_Sig_gy = Off;

        /*  Non GFS  */
      } else if ((rtu_Main_InSig_lz == WPCIndUSMState__Type2) && (*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.is_Tick_Timer_AmberINDBlk2_e == App_Model_IN_Off_c)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkOn;
        *rty_MainOut_Sig_g = On;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Start_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;
      } else if ((rtu_Main_InSig_lz != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.is_Tick_Timer_AmberINDBlk_f == App_Model_IN_Off_c)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkOn;

        /* Counter_BlinkCnt ++ */
        *rty_MainOut_Sig_g = Off;

        /* OffStart */
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = A_event_Start_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_lz != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_h == BlinkOff) && ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) &&
                  (App_Model_DW.WPCIndCmdState_prev == WPCIndCmdState__ErrorFadeIn))) {
        sint32 t_previousEvent;

        /* Timer_AmberINDBlk2 >= Par_LEDBlinkTime] */
        *rty_MainOut_Sig_h = BlinkOn;
        App_Model_DW.Counter_BlinkCnt_a++;
        *rty_MainOut_Sig_g = Off;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = A_event_Start_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_lz != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_h == BlinkOn) && (((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) &&
                   (App_Model_DW.WPCIndCmdState_prev == WPCIndCmdState__ErrorFadeOut)) || ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_start
        == WPCIndCmdState__ErrorOn)))) {
        sint32 t_previousEvent;

        /* Timer_AmberINDBlk >= Par_LEDBlinkTime] */
        *rty_MainOut_Sig_h = BlinkOff;
        *rty_MainOut_Sig_g = On;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = A_event_Start_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_lz == WPCIndUSMState__Type2) && ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_prev ==
                   WPCIndCmdState__ErrorFadeIn))) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkOn;
        *rty_MainOut_Sig_g = On;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Start_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_lz == WPCIndUSMState__Type2) && ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_prev ==
                   WPCIndCmdState__ErrorFadeOut))) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkOff;
        App_Model_DW.Counter_BlinkCnt_a++;

        /* Adapt after FadeOut and LEDOff // 230110 */
        *rty_MainOut_Sig_g = Off;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Start_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;
      }
    }
    break;

   case On:
    {
      /* For_OnlyAmber%WPC�� ŸWPC�� ���� �켱������ ������� */
      /* 1. */
      if ((*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.Counter_BlinkCnt_a >= 10)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkComplete;
        *rty_MainOut_Sig_g = Off;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;
        *rty_MainOut_Sig_gy = Off;

        /*  Non GFS  */
      } else if (App_Model_DW.Counter_BlinkCnt_a >= 10) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkComplete;
        *rty_MainOut_Sig_g = Off;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;
        *rty_MainOut_Sig_gy = Off;

        /*  Non GFS  */
      } else if ((rtu_Main_InSig_lz == WPCIndUSMState__Type2) && (*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.is_Tick_Timer_AmberINDBlk2_e == App_Model_IN_Off_c)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkOn;
        *rty_MainOut_Sig_g = On;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Start_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;
      } else if ((rtu_Main_InSig_lz != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.is_Tick_Timer_AmberINDBlk_f == App_Model_IN_Off_c)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkOn;

        /* Counter_BlinkCnt ++ */
        *rty_MainOut_Sig_g = Off;

        /* OffStart */
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = A_event_Start_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_lz != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_h == BlinkOff) && ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) &&
                  (App_Model_DW.WPCIndCmdState_prev == WPCIndCmdState__ErrorFadeIn))) {
        sint32 t_previousEvent;

        /* Timer_AmberINDBlk >= Par_LEDBlinkTime] */
        *rty_MainOut_Sig_h = BlinkOn;
        App_Model_DW.Counter_BlinkCnt_a++;
        *rty_MainOut_Sig_g = Off;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = A_event_Start_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_lz != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_h == BlinkOn) && (((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) &&
                   (App_Model_DW.WPCIndCmdState_prev == WPCIndCmdState__ErrorFadeOut)) || ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_start
        == WPCIndCmdState__ErrorOn)))) {
        sint32 t_previousEvent;

        /* Timer_AmberINDBlk >= Par_LEDBlinkTime] */
        *rty_MainOut_Sig_h = BlinkOff;
        *rty_MainOut_Sig_g = On;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = A_event_Start_Timer_AmberINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
          App_Mode_Tick_Timer_AmberINDBlk();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_lz == WPCIndUSMState__Type2) && ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_prev ==
                   WPCIndCmdState__ErrorFadeIn))) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkOn;
        *rty_MainOut_Sig_g = On;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Start_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_lz == WPCIndUSMState__Type2) && ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_prev ==
                   WPCIndCmdState__ErrorFadeOut))) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_h = BlinkOff;
        App_Model_DW.Counter_BlinkCnt_a++;

        /* Adapt after FadeOut and LEDOff // 230110 */
        *rty_MainOut_Sig_g = Off;
        t_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Start_Timer_AmberINDBlk2;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
          App_Mod_Tick_Timer_AmberINDBlk2();
        }

        App_Model_DW.sfEvent_a = t_previousEvent;
      }
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_M_exit_internal_WPCMode_Run(Bool *rty_MainOut_Sig_gy, BlinkState *rty_MainOut_Sig_h)
{
  if (App_Model_DW.is_WPCMode_Run_b == App_Model_IN_WPCRun_FODError) {
    sint32 b_previousEvent;
    *rty_MainOut_Sig_h = BlinkOff;
    App_Model_DW.Counter_BlinkCnt_a = 0U;
    b_previousEvent = App_Model_DW.sfEvent_a;
    App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
    if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
      App_Mode_Tick_Timer_AmberINDBlk();
    }

    App_Model_DW.sfEvent_a = b_previousEvent;

    /*  Non GFS  */
    *rty_MainOut_Sig_gy = Off;
    App_Model_DW.is_WPCMode_Run_b = App_Model_IN_NO_ACTIVE_CHILD_dl;
  } else {
    App_Model_DW.is_WPCMode_Run_b = App_Model_IN_NO_ACTIVE_CHILD_dl;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_Mode_Tick_Timer_GreenINDBlk(void)
{
  switch (App_Model_DW.is_Tick_Timer_GreenINDBlk_i) {
   case App_Model_IN_Off_c:
    if (App_Model_DW.sfEvent_a == A_event_Start_Timer_GreenINDBlk) {
      App_Model_DW.is_Tick_Timer_GreenINDBlk_i = App_Model_IN_On_hk;
    }
    break;

   case App_Model_IN_On_hk:
    {
      if (App_Model_DW.sfEvent_a == event_Cancel_Timer_GreenINDBlk) {
        App_Model_DW.is_Tick_Timer_GreenINDBlk_i = App_Model_IN_Off_c;
        App_Model_DW.Timer_GreenINDBlk_d = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_GreenINDBlk_d + 1;
        if (App_Model_DW.Timer_GreenINDBlk_d + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_GreenINDBlk_d = (uint16)tmp;
        if (App_Model_DW.sfEvent_a == A_event_Start_Timer_GreenINDBlk) {
          App_Model_DW.Timer_GreenINDBlk_d = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App__Function_CardLEDErrorBlink(Bool rtu_Main_InSig_h0, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_gy, BlinkState *rty_MainOut_Sig_h)
{
  switch (rtu_Main_InSig_h0) {
   case Off:
    {
      /* For_OnlyAmber%WPC�� �ϳ��̰ų� �켱������ ���� ������� */
      if ((*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.Counter_BlinkCnt_a >= 2)) {
        *rty_MainOut_Sig_h = BlinkComplete;
        *rty_MainOut_Sig_l = Off;
        *rty_MainOut_Sig_gy = Off;
      } else if (App_Model_DW.Counter_BlinkCnt_a > 2) {
        sint32 d_previousEvent;
        *rty_MainOut_Sig_h = BlinkComplete;
        *rty_MainOut_Sig_l = Off;
        d_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Cancel_Timer_GreenINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_GreenIND_e != 0U) {
          App_Mode_Tick_Timer_GreenINDBlk();
        }

        App_Model_DW.sfEvent_a = d_previousEvent;
        *rty_MainOut_Sig_gy = Off;
      } else if ((*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.is_Tick_Timer_GreenINDBlk_i == App_Model_IN_Off_c)) {
        sint32 d_previousEvent;
        *rty_MainOut_Sig_h = BlinkOff;
        *rty_MainOut_Sig_l = Off;
        d_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = A_event_Start_Timer_GreenINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_GreenIND_e != 0U) {
          App_Mode_Tick_Timer_GreenINDBlk();
        }

        App_Model_DW.sfEvent_a = d_previousEvent;
      } else if ((*rty_MainOut_Sig_h == BlinkOn) && ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_prev == WPCIndCmdState__ErrorFadeIn))) {
        *rty_MainOut_Sig_h = BlinkOff;
        App_Model_DW.Counter_BlinkCnt_a++;
        *rty_MainOut_Sig_l = Off;
      } else if ((*rty_MainOut_Sig_h == BlinkOff) && (((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_prev == WPCIndCmdState__ErrorFadeOut)) ||
                  ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_start == WPCIndCmdState__ErrorOn)))) {
        *rty_MainOut_Sig_h = BlinkOn;

        /* Counter_BlinkCnt ++; */
        *rty_MainOut_Sig_l = On;
      }
    }
    break;

   case On:
    {
      /* For_OnlyAmber%WPC�� ŸWPC�� ���� �켱������ ������� */
      if ((*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.Counter_BlinkCnt_a >= 2)) {
        *rty_MainOut_Sig_h = BlinkComplete;
        *rty_MainOut_Sig_l = Off;
        *rty_MainOut_Sig_gy = Off;
      } else if (App_Model_DW.Counter_BlinkCnt_a >= 2) {
        sint32 d_previousEvent;
        *rty_MainOut_Sig_h = BlinkComplete;
        *rty_MainOut_Sig_l = Off;
        d_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Cancel_Timer_GreenINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_GreenIND_e != 0U) {
          App_Mode_Tick_Timer_GreenINDBlk();
        }

        App_Model_DW.sfEvent_a = d_previousEvent;
        *rty_MainOut_Sig_gy = Off;
      } else if ((*rty_MainOut_Sig_h != BlinkComplete) && (App_Model_DW.is_Tick_Timer_GreenINDBlk_i == App_Model_IN_Off_c)) {
        sint32 d_previousEvent;
        *rty_MainOut_Sig_h = BlinkOff;
        *rty_MainOut_Sig_l = Off;
        d_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = A_event_Start_Timer_GreenINDBlk;
        if (App_Model_DW.is_active_Tick_Timer_GreenIND_e != 0U) {
          App_Mode_Tick_Timer_GreenINDBlk();
        }

        App_Model_DW.sfEvent_a = d_previousEvent;
      } else if ((*rty_MainOut_Sig_h == BlinkOn) && ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_prev == WPCIndCmdState__ErrorFadeIn))) {
        *rty_MainOut_Sig_h = BlinkOff;
        App_Model_DW.Counter_BlinkCnt_a++;
        *rty_MainOut_Sig_l = Off;
      } else if ((*rty_MainOut_Sig_h == BlinkOff) && (((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_prev == WPCIndCmdState__ErrorFadeOut)) ||
                  ((App_Model_DW.WPCIndCmdState_prev != App_Model_DW.WPCIndCmdState_start) && (App_Model_DW.WPCIndCmdState_start == WPCIndCmdState__ErrorOn)))) {
        *rty_MainOut_Sig_h = BlinkOn;

        /* Counter_BlinkCnt ++; */
        *rty_MainOut_Sig_l = On;
      }
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_enter_internal_WPCMode_Stop(Bool rtu_Main_InSig_gy, WPCIndUSMState rtu_Main_InSig_lz, Bool rtu_Main_InSig_h0, Bool rtu_Main_InSig_f, C_WPCWarning *rty_MainOut_Sig, Bool
  *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, Bool *rty_MainOut_Sig_a, BlinkState *rty_MainOut_Sig_h)
{
  /* 1. */
  if (rtu_Main_InSig_gy == On) {
    App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_WPCStop_TempErr;

    /* 240926 */
    *rty_MainOut_Sig_a = Off;
    *rty_MainOut_Sig = Charging_error;
    *rty_MainOut_Sig_h = BlinkOff;
    App_Model_DW.Counter_BlinkCnt_a = 0U;
    App_Mode_Function_LEDErrorBlink(rtu_Main_InSig_lz, rtu_Main_InSig_h0, rty_MainOut_Sig_g, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
    *rty_MainOut_Sig_gy = On;
  } else if (rtu_Main_InSig_f == On) {
    /* CardDetect_Nidec] */
    App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_CardDetectError;
    *rty_MainOut_Sig = NFCCardDetected;
    *rty_MainOut_Sig_h = BlinkOff;
    App_Model_DW.Counter_BlinkCnt_a = 0U;
    *rty_MainOut_Sig_g = Off;
    App__Function_CardLEDErrorBlink(rtu_Main_InSig_h0, rty_MainOut_Sig_l, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
    *rty_MainOut_Sig_gy = On;
  } else {
    App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_WPCStop_NotTempErr;

    /* 240926 */
    *rty_MainOut_Sig_a = Off;
    *rty_MainOut_Sig = WPCWarningOff;
    *rty_MainOut_Sig_g = Off;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_Model_WPCMode_Run(Bool rtu_Main_InSig, Bool rtu_Main_InSig_m, Bool rtu_Main_InSig_l, Bool rtu_Main_InSig_gy, DeviceState rtu_Main_InSig_a, WPCIndUSMState rtu_Main_InSig_lz, Bool
  rtu_Main_InSig_h0, Bool rtu_Main_InSig_f, C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_m, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, Bool *rty_MainOut_Sig_a,
  BlinkState *rty_MainOut_Sig_h)
{
  /* 1. */
  if ((rtu_Main_InSig == On) || (rtu_Main_InSig_m == On) || (rtu_Main_InSig_l == On) || (rtu_Main_InSig_gy == On) || (rtu_Main_InSig_f == On)) {
    /* CardDetect_Nidec] */
    App_M_exit_internal_WPCMode_Run(rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
    App_Model_DW.is_WPCMode_Enable_b = App_Model_IN_WPCMode_Stop;
    *rty_MainOut_Sig_m = Off;
    *rty_MainOut_Sig_l = Off;

    /* b_ChargingEnable = Off */
    App_enter_internal_WPCMode_Stop(rtu_Main_InSig_gy, rtu_Main_InSig_lz, rtu_Main_InSig_h0, rtu_Main_InSig_f, rty_MainOut_Sig, rty_MainOut_Sig_l, rty_MainOut_Sig_g, rty_MainOut_Sig_gy,
      rty_MainOut_Sig_a, rty_MainOut_Sig_h);
  } else {
    switch (App_Model_DW.is_WPCMode_Run_b) {
     case App_Model_IN_WPCRun_Charging:
      *rty_MainOut_Sig_m = On;

      /* 1. */
      if ((rtu_Main_InSig_a == Standby) || (rtu_Main_InSig_a == Init)) {
        App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_Standby;
        *rty_MainOut_Sig = WPCWarningOff;

        /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
        *rty_MainOut_Sig_m = Off;
        *rty_MainOut_Sig_l = Off;
        *rty_MainOut_Sig_g = Off;
      } else {
        /* 2. */
        switch (rtu_Main_InSig_a) {
         case FODError:
          /*  b_FODFault == On] */
          App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_FODError;
          *rty_MainOut_Sig = Charging_error;

          /* b_WPCWarn = Charging_error 8�� LFRollBack */
          *rty_MainOut_Sig_h = BlinkOff;
          App_Model_DW.Counter_BlinkCnt_a = 0U;
          *rty_MainOut_Sig_m = Off;
          *rty_MainOut_Sig_l = Off;
          App_Mode_Function_LEDErrorBlink(rtu_Main_InSig_lz, rtu_Main_InSig_h0, rty_MainOut_Sig_g, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);

          /*  Non GFS  */
          *rty_MainOut_Sig_gy = On;
          break;

         case Full_Charge:
          /* 3. */
          App_Model_DW.is_WPCMode_Run_b = App__IN_WPCRun_ChargingComplete;
          *rty_MainOut_Sig = Charging_Complete;

          /* b_WPCWarn = Charging_Complete 8�� LFRollBack */
          *rty_MainOut_Sig_m = On;
          *rty_MainOut_Sig_l = On;
          *rty_MainOut_Sig_g = Off;
          break;

         default:
          App_M_Function_ChargingINDColor(rtu_Main_InSig_lz, rtu_Main_InSig_f, rty_MainOut_Sig_l, rty_MainOut_Sig_g);
          break;
        }
      }
      break;

     case App__IN_WPCRun_ChargingComplete:
      *rty_MainOut_Sig_m = On;

      /* 1. */
      if ((rtu_Main_InSig_a == Standby) || (rtu_Main_InSig_a == Init)) {
        App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_Standby;
        *rty_MainOut_Sig = WPCWarningOff;

        /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
        *rty_MainOut_Sig_m = Off;
        *rty_MainOut_Sig_l = Off;
        *rty_MainOut_Sig_g = Off;
      } else {
        /* 2. */
        switch (rtu_Main_InSig_a) {
         case FODError:
          /*  b_FODFault == On] */
          App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_FODError;
          *rty_MainOut_Sig = Charging_error;

          /* b_WPCWarn = Charging_error 8�� LFRollBack */
          *rty_MainOut_Sig_h = BlinkOff;
          App_Model_DW.Counter_BlinkCnt_a = 0U;
          *rty_MainOut_Sig_m = Off;
          *rty_MainOut_Sig_l = Off;
          App_Mode_Function_LEDErrorBlink(rtu_Main_InSig_lz, rtu_Main_InSig_h0, rty_MainOut_Sig_g, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);

          /*  Non GFS  */
          *rty_MainOut_Sig_gy = On;
          break;

         case Charging:
          /* 3. */
          App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_Charging;
          *rty_MainOut_Sig = PhoneCharging;

          /* b_WPCWarn = PhoneCharging 8�� LFRollBack */
          *rty_MainOut_Sig_m = On;
          App_M_Function_ChargingINDColor(rtu_Main_InSig_lz, rtu_Main_InSig_f, rty_MainOut_Sig_l, rty_MainOut_Sig_g);
          break;
        }
      }
      break;

     case App_Model_IN_WPCRun_FODError:
      {
        *rty_MainOut_Sig_m = Off;

        /* 1. */
        if ((rtu_Main_InSig_a == Standby) || (rtu_Main_InSig_a == Init)) {
          sint32 c_previousEvent;

          /*  BlinkState == BlinkComplete 8�� ���� */
          *rty_MainOut_Sig_h = BlinkOff;
          App_Model_DW.Counter_BlinkCnt_a = 0U;
          c_previousEvent = App_Model_DW.sfEvent_a;
          App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
          if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
            App_Mode_Tick_Timer_AmberINDBlk();
          }

          App_Model_DW.sfEvent_a = c_previousEvent;

          /*  Non GFS  */
          *rty_MainOut_Sig_gy = Off;
          App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_Standby;
          *rty_MainOut_Sig = WPCWarningOff;

          /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
          *rty_MainOut_Sig_m = Off;
          *rty_MainOut_Sig_l = Off;
          *rty_MainOut_Sig_g = Off;
        } else {
          /* 2. */
          switch (rtu_Main_InSig_a) {
           case Charging:
            {
              sint32 c_previousEvent;

              /*  BlinkState == BlinkComplete 8�� ���� */
              *rty_MainOut_Sig_h = BlinkOff;
              App_Model_DW.Counter_BlinkCnt_a = 0U;
              c_previousEvent = App_Model_DW.sfEvent_a;
              App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
              if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
                App_Mode_Tick_Timer_AmberINDBlk();
              }

              App_Model_DW.sfEvent_a = c_previousEvent;

              /*  Non GFS  */
              *rty_MainOut_Sig_gy = Off;
              App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_Charging;
              *rty_MainOut_Sig = PhoneCharging;

              /* b_WPCWarn = PhoneCharging 8�� LFRollBack */
              *rty_MainOut_Sig_m = On;
              App_M_Function_ChargingINDColor(rtu_Main_InSig_lz, rtu_Main_InSig_f, rty_MainOut_Sig_l, rty_MainOut_Sig_g);
            }
            break;

           case Full_Charge:
            {
              sint32 c_previousEvent;

              /* 3. */
              /*  BlinkState == BlinkComplete 8�� ���� */
              *rty_MainOut_Sig_h = BlinkOff;
              App_Model_DW.Counter_BlinkCnt_a = 0U;
              c_previousEvent = App_Model_DW.sfEvent_a;
              App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
              if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
                App_Mode_Tick_Timer_AmberINDBlk();
              }

              App_Model_DW.sfEvent_a = c_previousEvent;

              /*  Non GFS  */
              *rty_MainOut_Sig_gy = Off;
              App_Model_DW.is_WPCMode_Run_b = App__IN_WPCRun_ChargingComplete;
              *rty_MainOut_Sig = Charging_Complete;

              /* b_WPCWarn = Charging_Complete 8�� LFRollBack */
              *rty_MainOut_Sig_m = On;
              *rty_MainOut_Sig_l = On;
              *rty_MainOut_Sig_g = Off;
            }
            break;

           default:
            App_Mode_Function_LEDErrorBlink(rtu_Main_InSig_lz, rtu_Main_InSig_h0, rty_MainOut_Sig_g, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
            break;
          }
        }
      }
      break;

     case App_Model_IN_WPCRun_Standby:
      *rty_MainOut_Sig_m = Off;

      /* 1. */
      switch (rtu_Main_InSig_a) {
       case FODError:
        /*  b_FODFault == On] */
        App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_FODError;
        *rty_MainOut_Sig = Charging_error;

        /* b_WPCWarn = Charging_error 8�� LFRollBack */
        *rty_MainOut_Sig_h = BlinkOff;
        App_Model_DW.Counter_BlinkCnt_a = 0U;
        *rty_MainOut_Sig_m = Off;
        *rty_MainOut_Sig_l = Off;
        App_Mode_Function_LEDErrorBlink(rtu_Main_InSig_lz, rtu_Main_InSig_h0, rty_MainOut_Sig_g, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);

        /*  Non GFS  */
        *rty_MainOut_Sig_gy = On;
        break;

       case Charging:
        /* 2. */
        App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_Charging;
        *rty_MainOut_Sig = PhoneCharging;

        /* b_WPCWarn = PhoneCharging 8�� LFRollBack */
        *rty_MainOut_Sig_m = On;
        App_M_Function_ChargingINDColor(rtu_Main_InSig_lz, rtu_Main_InSig_f, rty_MainOut_Sig_l, rty_MainOut_Sig_g);
        break;

       case Full_Charge:
        /* 3. */
        App_Model_DW.is_WPCMode_Run_b = App__IN_WPCRun_ChargingComplete;
        *rty_MainOut_Sig = Charging_Complete;

        /* b_WPCWarn = Charging_Complete 8�� LFRollBack */
        *rty_MainOut_Sig_m = On;
        *rty_MainOut_Sig_l = On;
        *rty_MainOut_Sig_g = Off;
        break;
      }
      break;
    }
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App__exit_internal_WPCMode_Stop(Bool *rty_MainOut_Sig_gy, BlinkState *rty_MainOut_Sig_h)
{
  switch (App_Model_DW.is_WPCMode_Stop_i) {
   case App_Model_IN_CardDetectError:
    {
      sint32 b_previousEvent;
      *rty_MainOut_Sig_h = BlinkOff;
      App_Model_DW.Counter_BlinkCnt_a = 0U;
      b_previousEvent = App_Model_DW.sfEvent_a;
      App_Model_DW.sfEvent_a = event_Cancel_Timer_GreenINDBlk;
      if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
        App_Mode_Tick_Timer_AmberINDBlk();
      }

      App_Model_DW.sfEvent_a = b_previousEvent;
      *rty_MainOut_Sig_gy = Off;
      App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_NO_ACTIVE_CHILD_dl;
    }
    break;

   case App_Model_IN_WPCStop_TempErr:
    {
      sint32 b_previousEvent;
      *rty_MainOut_Sig_h = BlinkOff;
      App_Model_DW.Counter_BlinkCnt_a = 0U;
      b_previousEvent = App_Model_DW.sfEvent_a;
      App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
      if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
        App_Mode_Tick_Timer_AmberINDBlk();
      }

      App_Model_DW.sfEvent_a = b_previousEvent;

      /*  Non GFS  */
      *rty_MainOut_Sig_gy = Off;
      App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_NO_ACTIVE_CHILD_dl;
    }
    break;

   default:
    App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_NO_ACTIVE_CHILD_dl;
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void Ap_enter_atomic_WPCMode_Disable(C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_m, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, BlinkState *rty_MainOut_Sig_h, Bool
  *rty_MainOut_Sig_k)
{
  sint32 b_previousEvent;
  *rty_MainOut_Sig = WPCWarningOff;
  *rty_MainOut_Sig_h = BlinkOff;
  App_Model_DW.Counter_BlinkCnt_a = 0U;
  *rty_MainOut_Sig_m = Off;
  *rty_MainOut_Sig_l = Off;
  *rty_MainOut_Sig_g = Off;
  *rty_MainOut_Sig_k = Off;
  b_previousEvent = App_Model_DW.sfEvent_a;
  App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
  if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
    App_Mode_Tick_Timer_AmberINDBlk();
  }

  App_Model_DW.sfEvent_a = b_previousEvent;
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_Model_Tick_Timer_PhoneLeft(void)
{
  switch (App_Model_DW.is_Tick_Timer_PhoneLeft_b) {
   case App_Model_IN_Off_c:
    if (App_Model_DW.sfEvent_a == App_event_Start_Timer_PhoneLeft) {
      App_Model_DW.is_Tick_Timer_PhoneLeft_b = App_Model_IN_On_hk;
    }
    break;

   case App_Model_IN_On_hk:
    {
      if (App_Model_DW.sfEvent_a == Ap_event_Cancel_Timer_PhoneLeft) {
        App_Model_DW.is_Tick_Timer_PhoneLeft_b = App_Model_IN_Off_c;
        App_Model_DW.Timer_PhoneLeft_n = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_PhoneLeft_n + 1;
        if (App_Model_DW.Timer_PhoneLeft_n + 1 > 255) {
          tmp = 255;
        }

        App_Model_DW.Timer_PhoneLeft_n = (uint8)tmp;
        if (App_Model_DW.sfEvent_a == App_event_Start_Timer_PhoneLeft) {
          App_Model_DW.Timer_PhoneLeft_n = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void Ap_Tick_Timer_PhoneWarningCheck(uint16 *rty_MainOut_Sig_j)
{
  switch (App_Model_DW.is_Tick_Timer_PhoneWarningChe_i) {
   case App_Model_IN_Off_c:
    if (App_Model_DW.sfEvent_a == event_Start_Timer_PhoneWarningC) {
      App_Model_DW.is_Tick_Timer_PhoneWarningChe_i = App_Model_IN_On_hk;
    }
    break;

   case App_Model_IN_On_hk:
    {
      if (App_Model_DW.sfEvent_a == event_Cancel_Timer_PhoneWarning) {
        App_Model_DW.is_Tick_Timer_PhoneWarningChe_i = App_Model_IN_Off_c;
        App_Model_DW.Timer_PhoneWarningCheck_m = 0U;
        *rty_MainOut_Sig_j = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_PhoneWarningCheck_m + 1;
        if (App_Model_DW.Timer_PhoneWarningCheck_m + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_PhoneWarningCheck_m = (uint16)tmp;
        *rty_MainOut_Sig_j = App_Model_DW.Timer_PhoneWarningCheck_m;
        if (App_Model_DW.sfEvent_a == event_Start_Timer_PhoneWarningC) {
          App_Model_DW.Timer_PhoneWarningCheck_m = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void A_Tick_Timer_PhoneReminderCheck(uint16 *rty_MainOut_Sig_b)
{
  switch (App_Model_DW.is_Tick_Timer_PhoneReminderCh_o) {
   case App_Model_IN_Off_c:
    if (App_Model_DW.sfEvent_a == event_Start_Timer_PhoneReminder) {
      App_Model_DW.is_Tick_Timer_PhoneReminderCh_o = App_Model_IN_On_hk;
    }
    break;

   case App_Model_IN_On_hk:
    {
      if (App_Model_DW.sfEvent_a == event_Cancel_Timer_PhoneReminde) {
        App_Model_DW.is_Tick_Timer_PhoneReminderCh_o = App_Model_IN_Off_c;
        App_Model_DW.Timer_PhoneReminderCheck_e = 0U;
        *rty_MainOut_Sig_b = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_PhoneReminderCheck_e + 1;
        if (App_Model_DW.Timer_PhoneReminderCheck_e + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_PhoneReminderCheck_e = (uint16)tmp;
        *rty_MainOut_Sig_b = App_Model_DW.Timer_PhoneReminderCheck_e;
        if (App_Model_DW.sfEvent_a == event_Start_Timer_PhoneReminder) {
          App_Model_DW.Timer_PhoneReminderCheck_e = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App__Tick_Timer_WarningComplete(uint16 *rty_MainOut_Sig_jy)
{
  switch (App_Model_DW.is_Tick_Timer_WarningComplete_j) {
   case App_Model_IN_Off_c:
    if (App_Model_DW.sfEvent_a == event_Start_Timer_WarningComple) {
      App_Model_DW.is_Tick_Timer_WarningComplete_j = App_Model_IN_On_hk;
    }
    break;

   case App_Model_IN_On_hk:
    {
      if (App_Model_DW.sfEvent_a == event_Cancel_Timer_WarningCompl) {
        App_Model_DW.is_Tick_Timer_WarningComplete_j = App_Model_IN_Off_c;
        App_Model_DW.Timer_WarningComplete_d = 0U;
        *rty_MainOut_Sig_jy = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_WarningComplete_d + 1;
        if (App_Model_DW.Timer_WarningComplete_d + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_WarningComplete_d = (uint16)tmp;
        *rty_MainOut_Sig_jy = App_Model_DW.Timer_WarningComplete_d;
        if (App_Model_DW.sfEvent_a == event_Start_Timer_WarningComple) {
          App_Model_DW.Timer_WarningComplete_d = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_Model_Function_WPCWarning(C_WPCOnOffNvalueSet rtu_Main_InSig_g, Bool rtu_Main_InSig_b, Bool rtu_Main_InSig_j, Bool rtu_Main_InSig_jy, C_WPCWarning *rty_MainOut_Sig, uint16
  *rty_MainOut_Sig_b, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_jy, Bool *rty_MainOut_Sig_k)
{
  /* 1 */
  if ((rtu_Main_InSig_g == WPC_Off) || ((App_Model_DW.Timer_PhoneWarningCheck_m >= Par_PhoneCheckTime) && (rtu_Main_InSig_jy == Off)) || (App_Model_DW.Timer_PhoneLeft_n >= 50)) {
    sint32 c_previousEvent;
    *rty_MainOut_Sig = WPCWarningOff;

    /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
    App_Model_DW.b_WarnClearEnable_m = Off;
    *rty_MainOut_Sig_k = Off;
    c_previousEvent = App_Model_DW.sfEvent_a;
    App_Model_DW.sfEvent_a = Ap_event_Cancel_Timer_PhoneLeft;
    if (App_Model_DW.is_active_Tick_Timer_PhoneLef_n != 0U) {
      App_Model_Tick_Timer_PhoneLeft();
    }

    App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneWarning;
    if (App_Model_DW.is_active_Tick_Timer_PhoneWar_n != 0U) {
      Ap_Tick_Timer_PhoneWarningCheck(rty_MainOut_Sig_j);
    }

    App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneReminde;
    if (App_Model_DW.is_active_Tick_Timer_PhoneRem_a != 0U) {
      A_Tick_Timer_PhoneReminderCheck(rty_MainOut_Sig_b);
    }

    App_Model_DW.sfEvent_a = event_Cancel_Timer_WarningCompl;
    if (App_Model_DW.is_active_Tick_Timer_WarningC_o != 0U) {
      App__Tick_Timer_WarningComplete(rty_MainOut_Sig_jy);
    }

    App_Model_DW.sfEvent_a = c_previousEvent;
  } else {
    sint32 c_previousEvent;

    /* 1. */
    if ((App_Model_DW.b_WarnClearEnable_m == On) && ((App_Model_DW.b_WPCPhoneExist_prev_e != App_Model_DW.b_WPCPhoneExist_start_f) && (App_Model_DW.b_WPCPhoneExist_start_f == Off))) {
      c_previousEvent = App_Model_DW.sfEvent_a;
      App_Model_DW.sfEvent_a = App_event_Start_Timer_PhoneLeft;
      if (App_Model_DW.is_active_Tick_Timer_PhoneLef_n != 0U) {
        App_Model_Tick_Timer_PhoneLeft();
      }

      App_Model_DW.sfEvent_a = c_previousEvent;

      /* 1. */
    } else if ((App_Model_DW.is_Tick_Timer_PhoneLeft_b == App_Model_IN_On_hk) && (rtu_Main_InSig_jy == On)) {
      c_previousEvent = App_Model_DW.sfEvent_a;
      App_Model_DW.sfEvent_a = Ap_event_Cancel_Timer_PhoneLeft;
      if (App_Model_DW.is_active_Tick_Timer_PhoneLef_n != 0U) {
        App_Model_Tick_Timer_PhoneLeft();
      }

      App_Model_DW.sfEvent_a = c_previousEvent;
    }

    /* 1. */
    if ((App_Model_DW.Timer_PhoneWarningCheck_m >= 10) && (App_Model_DW.Timer_PhoneWarningCheck_m <= Par_PhoneCheckTime) && (rtu_Main_InSig_jy == On)) {
      *rty_MainOut_Sig = Cellphoneonthepad;

      /* b_WPCWarn = Cellphoneonthepad 8�� LFRollBack */
      App_Model_DW.b_WarnClearEnable_m = On;
      c_previousEvent = App_Model_DW.sfEvent_a;
      App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneWarning;
      if (App_Model_DW.is_active_Tick_Timer_PhoneWar_n != 0U) {
        Ap_Tick_Timer_PhoneWarningCheck(rty_MainOut_Sig_j);
      }

      App_Model_DW.sfEvent_a = event_Start_Timer_PhoneReminder;
      if (App_Model_DW.is_active_Tick_Timer_PhoneRem_a != 0U) {
        A_Tick_Timer_PhoneReminderCheck(rty_MainOut_Sig_b);
      }

      App_Model_DW.sfEvent_a = c_previousEvent;

      /* 5�� ���� */

      /* 1. */
    } else if ((App_Model_DW.Timer_PhoneReminderCheck_e >= 6000) && (App_Model_DW.b_WarnClearEnable_m == On) && (rtu_Main_InSig_jy == On)) {
      /* 1. */
      if ((rtu_Main_InSig_j == On) || (rtu_Main_InSig_b == On)) {
        App_Model_DW.b_WarnClearEnable_m = Off;
        *rty_MainOut_Sig = WPCWarningOff;
        *rty_MainOut_Sig_k = Off;

        /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
        c_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneReminde;
        if (App_Model_DW.is_active_Tick_Timer_PhoneRem_a != 0U) {
          A_Tick_Timer_PhoneReminderCheck(rty_MainOut_Sig_b);
        }

        App_Model_DW.sfEvent_a = c_previousEvent;
      } else {
        /* 2. */
        *rty_MainOut_Sig = Cellphonereminder;

        /* b_WPCWarn = Cellphonereminder 8�� LFRollBack */
        c_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneReminde;
        if (App_Model_DW.is_active_Tick_Timer_PhoneRem_a != 0U) {
          A_Tick_Timer_PhoneReminderCheck(rty_MainOut_Sig_b);
        }

        App_Model_DW.sfEvent_a = event_Start_Timer_WarningComple;
        if (App_Model_DW.is_active_Tick_Timer_WarningC_o != 0U) {
          App__Tick_Timer_WarningComplete(rty_MainOut_Sig_jy);
        }

        App_Model_DW.sfEvent_a = c_previousEvent;
      }

      /* 1. */
    } else if ((App_Model_DW.Timer_WarningComplete_d >= 50) && (App_Model_DW.b_WarnClearEnable_m == On) && (rtu_Main_InSig_jy == On)) {
      *rty_MainOut_Sig = WPCWarningOff;

      /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
      App_Model_DW.b_WarnClearEnable_m = Off;
      *rty_MainOut_Sig_k = Off;
      c_previousEvent = App_Model_DW.sfEvent_a;
      App_Model_DW.sfEvent_a = event_Cancel_Timer_WarningCompl;
      if (App_Model_DW.is_active_Tick_Timer_WarningC_o != 0U) {
        App__Tick_Timer_WarningComplete(rty_MainOut_Sig_jy);
      }

      App_Model_DW.sfEvent_a = c_previousEvent;
    }
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_Mo_enter_atomic_WPCMode_NFC(uint16 *rty_MainOut_Sig_b, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_jy)
{
  sint32 b_previousEvent;
  App_Model_DW.b_WarnClearEnable_m = Off;
  b_previousEvent = App_Model_DW.sfEvent_a;
  App_Model_DW.sfEvent_a = Ap_event_Cancel_Timer_PhoneLeft;
  if (App_Model_DW.is_active_Tick_Timer_PhoneLef_n != 0U) {
    App_Model_Tick_Timer_PhoneLeft();
  }

  App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneWarning;
  if (App_Model_DW.is_active_Tick_Timer_PhoneWar_n != 0U) {
    Ap_Tick_Timer_PhoneWarningCheck(rty_MainOut_Sig_j);
  }

  App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneReminde;
  if (App_Model_DW.is_active_Tick_Timer_PhoneRem_a != 0U) {
    A_Tick_Timer_PhoneReminderCheck(rty_MainOut_Sig_b);
  }

  App_Model_DW.sfEvent_a = event_Cancel_Timer_WarningCompl;
  if (App_Model_DW.is_active_Tick_Timer_WarningC_o != 0U) {
    App__Tick_Timer_WarningComplete(rty_MainOut_Sig_jy);
  }

  App_Model_DW.sfEvent_a = b_previousEvent;
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void enter_internal_WPCMode_Disable(C_WPCOnOffNvalueSet rtu_Main_InSig_g, Bool rtu_Main_InSig_b, Bool rtu_Main_InSig_j, Bool rtu_Main_InSig_jy, WPCStatus rtu_Main_InSig_h, C_WPCWarning
  *rty_MainOut_Sig, uint16 *rty_MainOut_Sig_b, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_jy, Bool *rty_MainOut_Sig_k)
{
  /* 1. */
  if ((rtu_Main_InSig_h == NFCMode) || (rtu_Main_InSig_h == LPCDMode) || (rtu_Main_InSig_h == PICCMode)) {
    App_Model_DW.is_WPCMode_Disable_c = App_Model_IN_WPCMode_NFC;
    App_Mo_enter_atomic_WPCMode_NFC(rty_MainOut_Sig_b, rty_MainOut_Sig_j, rty_MainOut_Sig_jy);
  } else {
    App_Model_DW.is_WPCMode_Disable_c = App_Model_IN_WPCMode_Off;
    if ((App_Model_DW.L_IGN1_IN_prev_c != App_Model_DW.L_IGN1_IN_start_b) && (App_Model_DW.L_IGN1_IN_start_b == Off)) {
      sint32 b_previousEvent;
      App_Model_DW.is_WPCMode_Off_i = App_Mod_IN_LeavingPhone_Warning;
      App_Model_DW.b_WarnClearEnable_m = Off;
      b_previousEvent = App_Model_DW.sfEvent_a;
      App_Model_DW.sfEvent_a = event_Start_Timer_PhoneWarningC;
      if (App_Model_DW.is_active_Tick_Timer_PhoneWar_n != 0U) {
        Ap_Tick_Timer_PhoneWarningCheck(rty_MainOut_Sig_j);
      }

      App_Model_DW.sfEvent_a = b_previousEvent;
      App_Model_Function_WPCWarning(rtu_Main_InSig_g, rtu_Main_InSig_b, rtu_Main_InSig_j, rtu_Main_InSig_jy, rty_MainOut_Sig, rty_MainOut_Sig_b, rty_MainOut_Sig_j, rty_MainOut_Sig_jy,
        rty_MainOut_Sig_k);
      *rty_MainOut_Sig_k = On;
    } else {
      App_Model_DW.is_WPCMode_Off_i = App_M_IN_LeavingPhone_NoWarning;
    }
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void App_Model_MainControl(Bool rtu_Main_InSig, Bool rtu_Main_InSig_m, Bool rtu_Main_InSig_l, C_WPCOnOffNvalueSet rtu_Main_InSig_g, Bool rtu_Main_InSig_gy, Bool rtu_Main_InSig_b, Bool
  rtu_Main_InSig_j, Bool rtu_Main_InSig_jy, DeviceState rtu_Main_InSig_a, WPCStatus rtu_Main_InSig_h, WPCIndUSMState rtu_Main_InSig_lz, Bool rtu_Main_InSig_h0, Bool rtu_Main_InSig_f, C_WPCWarning
  *rty_MainOut_Sig, Bool *rty_MainOut_Sig_m, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, uint16 *rty_MainOut_Sig_b, uint16 *rty_MainOut_Sig_j, uint16
  *rty_MainOut_Sig_jy, Bool *rty_MainOut_Sig_a, BlinkState *rty_MainOut_Sig_h, Bool *rty_MainOut_Sig_k)
{
  switch (App_Model_DW.is_MainControl_o) {
   case App_Model_IN_WPCMode_Disable:
    {
      /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
      *rty_MainOut_Sig_m = Off;

      /* 1. */
      if (rtu_Main_InSig_h == WPCMode) {
        sint32 b_previousEvent;
        if (App_Model_DW.is_WPCMode_Disable_c == App_Model_IN_WPCMode_Off) {
          if (App_Model_DW.is_WPCMode_Off_i == App_Mod_IN_LeavingPhone_Warning) {
            /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
            *rty_MainOut_Sig = WPCWarningOff;
            *rty_MainOut_Sig_k = Off;
            App_Model_DW.is_WPCMode_Off_i = App_Model_IN_NO_ACTIVE_CHILD_dl;
          } else {
            App_Model_DW.is_WPCMode_Off_i = App_Model_IN_NO_ACTIVE_CHILD_dl;
          }

          App_Model_DW.is_WPCMode_Disable_c = App_Model_IN_NO_ACTIVE_CHILD_dl;
        } else {
          App_Model_DW.is_WPCMode_Disable_c = App_Model_IN_NO_ACTIVE_CHILD_dl;
        }

        App_Model_DW.b_WarnClearEnable_m = Off;
        b_previousEvent = App_Model_DW.sfEvent_a;
        App_Model_DW.sfEvent_a = Ap_event_Cancel_Timer_PhoneLeft;
        if (App_Model_DW.is_active_Tick_Timer_PhoneLef_n != 0U) {
          App_Model_Tick_Timer_PhoneLeft();
        }

        App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneWarning;
        if (App_Model_DW.is_active_Tick_Timer_PhoneWar_n != 0U) {
          /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
          Ap_Tick_Timer_PhoneWarningCheck(rty_MainOut_Sig_j);
        }

        App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneReminde;
        if (App_Model_DW.is_active_Tick_Timer_PhoneRem_a != 0U) {
          /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
          A_Tick_Timer_PhoneReminderCheck(rty_MainOut_Sig_b);
        }

        App_Model_DW.sfEvent_a = event_Cancel_Timer_WarningCompl;
        if (App_Model_DW.is_active_Tick_Timer_WarningC_o != 0U) {
          /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
          App__Tick_Timer_WarningComplete(rty_MainOut_Sig_jy);
        }

        App_Model_DW.sfEvent_a = b_previousEvent;
        App_Model_DW.is_MainControl_o = App_Model_IN_WPCMode_Enable;
        App_Model_DW.is_WPCMode_Enable_b = App_Model_IN_WPCMode_Stop;

        /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
        *rty_MainOut_Sig_m = Off;
        *rty_MainOut_Sig_l = Off;

        /* b_ChargingEnable = Off */
        App_enter_internal_WPCMode_Stop(rtu_Main_InSig_gy, rtu_Main_InSig_lz, rtu_Main_InSig_h0, rtu_Main_InSig_f, rty_MainOut_Sig, rty_MainOut_Sig_l, rty_MainOut_Sig_g, rty_MainOut_Sig_gy,
          rty_MainOut_Sig_a, rty_MainOut_Sig_h);
      } else {
        switch (App_Model_DW.is_WPCMode_Disable_c) {
         case App_Model_IN_WPCMode_NFC:
          /* 1. */
          if (rtu_Main_InSig_h == ModeOff) {
            App_Model_DW.is_WPCMode_Disable_c = App_Model_IN_WPCMode_Off;
            App_Model_DW.is_WPCMode_Off_i = App_M_IN_LeavingPhone_NoWarning;
          }
          break;

         case App_Model_IN_WPCMode_Off:
          /* 1. */
          if ((rtu_Main_InSig_h == NFCMode) || (rtu_Main_InSig_h == LPCDMode) || (rtu_Main_InSig_h == PICCMode)) {
            if (App_Model_DW.is_WPCMode_Off_i == App_Mod_IN_LeavingPhone_Warning) {
              /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
              *rty_MainOut_Sig = WPCWarningOff;
              *rty_MainOut_Sig_k = Off;
              App_Model_DW.is_WPCMode_Off_i = App_Model_IN_NO_ACTIVE_CHILD_dl;
            } else {
              App_Model_DW.is_WPCMode_Off_i = App_Model_IN_NO_ACTIVE_CHILD_dl;
            }

            App_Model_DW.is_WPCMode_Disable_c = App_Model_IN_WPCMode_NFC;

            /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
            App_Mo_enter_atomic_WPCMode_NFC(rty_MainOut_Sig_b, rty_MainOut_Sig_j, rty_MainOut_Sig_jy);
          } else if (App_Model_DW.is_WPCMode_Off_i == App_Mod_IN_LeavingPhone_Warning) {
            /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
            App_Model_Function_WPCWarning(rtu_Main_InSig_g, rtu_Main_InSig_b, rtu_Main_InSig_j, rtu_Main_InSig_jy, rty_MainOut_Sig, rty_MainOut_Sig_b, rty_MainOut_Sig_j, rty_MainOut_Sig_jy,
              rty_MainOut_Sig_k);
          }
          break;
        }
      }
    }
    break;

   case App_Model_IN_WPCMode_Enable:
    {
      /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
      /* 1. */
      if (rtu_Main_InSig_h != WPCMode) {
        switch (App_Model_DW.is_WPCMode_Enable_b) {
         case App_Model_IN_WPCMode_Run:
          App_M_exit_internal_WPCMode_Run(rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
          App_Model_DW.is_WPCMode_Enable_b = App_Model_IN_NO_ACTIVE_CHILD_dl;
          break;

         case App_Model_IN_WPCMode_Stop:
          App__exit_internal_WPCMode_Stop(rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
          App_Model_DW.is_WPCMode_Enable_b = App_Model_IN_NO_ACTIVE_CHILD_dl;
          break;
        }

        *rty_MainOut_Sig_a = Off;
        App_Model_DW.is_MainControl_o = App_Model_IN_WPCMode_Disable;
        Ap_enter_atomic_WPCMode_Disable(rty_MainOut_Sig, rty_MainOut_Sig_m, rty_MainOut_Sig_l, rty_MainOut_Sig_g, rty_MainOut_Sig_h, rty_MainOut_Sig_k);
        enter_internal_WPCMode_Disable(rtu_Main_InSig_g, rtu_Main_InSig_b, rtu_Main_InSig_j, rtu_Main_InSig_jy, rtu_Main_InSig_h, rty_MainOut_Sig, rty_MainOut_Sig_b, rty_MainOut_Sig_j,
          rty_MainOut_Sig_jy, rty_MainOut_Sig_k);
      } else {
        switch (App_Model_DW.is_WPCMode_Enable_b) {
         case App_Model_IN_WPCMode_Run:
          App_Model_WPCMode_Run(rtu_Main_InSig, rtu_Main_InSig_m, rtu_Main_InSig_l, rtu_Main_InSig_gy, rtu_Main_InSig_a, rtu_Main_InSig_lz, rtu_Main_InSig_h0, rtu_Main_InSig_f, rty_MainOut_Sig,
                                rty_MainOut_Sig_m, rty_MainOut_Sig_l, rty_MainOut_Sig_g, rty_MainOut_Sig_gy, rty_MainOut_Sig_a, rty_MainOut_Sig_h);
          break;

         case App_Model_IN_WPCMode_Stop:
          {
            *rty_MainOut_Sig_m = Off;
            if ((rtu_Main_InSig_a == Full_Charge) && (rtu_Main_InSig == Off) && (rtu_Main_InSig_m == Off) && (rtu_Main_InSig_gy == Off) && (rtu_Main_InSig_l == Off) && (rtu_Main_InSig_f == Off)) {
              /* CardDetect_Nidec] */
              App__exit_internal_WPCMode_Stop(rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
              App_Model_DW.is_WPCMode_Enable_b = App_Model_IN_WPCMode_Run;
              *rty_MainOut_Sig_a = On;

              /* b_ROHMOperCmd = On /_ Non GFS _/ */
              App_Model_DW.is_WPCMode_Run_b = App__IN_WPCRun_ChargingComplete;
              *rty_MainOut_Sig = Charging_Complete;

              /* b_WPCWarn = Charging_Complete 8�� LFRollBack */
              *rty_MainOut_Sig_m = On;
              *rty_MainOut_Sig_l = On;
              *rty_MainOut_Sig_g = Off;
            } else if ((rtu_Main_InSig_a == Charging) && (rtu_Main_InSig == Off) && (rtu_Main_InSig_m == Off) && (rtu_Main_InSig_gy == Off) && (rtu_Main_InSig_l == Off) && (rtu_Main_InSig_f == Off)) {
              /* CardDetect_Nidec] */
              App__exit_internal_WPCMode_Stop(rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
              App_Model_DW.is_WPCMode_Enable_b = App_Model_IN_WPCMode_Run;
              *rty_MainOut_Sig_a = On;

              /* b_ROHMOperCmd = On /_ Non GFS _/ */
              App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_Charging;
              *rty_MainOut_Sig = PhoneCharging;

              /* b_WPCWarn = PhoneCharging 8�� LFRollBack */
              *rty_MainOut_Sig_m = On;
              App_M_Function_ChargingINDColor(rtu_Main_InSig_lz, rtu_Main_InSig_f, rty_MainOut_Sig_l, rty_MainOut_Sig_g);
            } else {
              switch (App_Model_DW.is_WPCMode_Stop_i) {
               case App_Model_IN_CardDetectError:
                {
                  if (rtu_Main_InSig_f == Off) {
                    sint32 b_previousEvent;

                    /* CardDetect_Nidec] */
                    *rty_MainOut_Sig_h = BlinkOff;
                    App_Model_DW.Counter_BlinkCnt_a = 0U;
                    b_previousEvent = App_Model_DW.sfEvent_a;
                    App_Model_DW.sfEvent_a = event_Cancel_Timer_GreenINDBlk;
                    if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
                      App_Mode_Tick_Timer_AmberINDBlk();
                    }

                    App_Model_DW.sfEvent_a = b_previousEvent;
                    *rty_MainOut_Sig_gy = Off;
                    App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_NO_ACTIVE_CHILD_dl;
                    App_Model_DW.is_WPCMode_Enable_b = App_Model_IN_WPCMode_Run;
                    *rty_MainOut_Sig_a = On;

                    /* b_ROHMOperCmd = On /_ Non GFS _/ */
                    App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_Standby;
                    *rty_MainOut_Sig = WPCWarningOff;

                    /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
                    *rty_MainOut_Sig_m = Off;
                    *rty_MainOut_Sig_l = Off;
                    *rty_MainOut_Sig_g = Off;
                  } else {
                    App__Function_CardLEDErrorBlink(rtu_Main_InSig_h0, rty_MainOut_Sig_l, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
                  }
                }
                break;

               case App_Model_IN_WPCStop_NotTempErr:
                /* 1. */
                if (rtu_Main_InSig_gy == On) {
                  App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_WPCStop_TempErr;

                  /* 240926 */
                  *rty_MainOut_Sig_a = Off;
                  *rty_MainOut_Sig = Charging_error;
                  *rty_MainOut_Sig_h = BlinkOff;
                  App_Model_DW.Counter_BlinkCnt_a = 0U;
                  App_Mode_Function_LEDErrorBlink(rtu_Main_InSig_lz, rtu_Main_InSig_h0, rty_MainOut_Sig_g, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
                  *rty_MainOut_Sig_gy = On;

                  /* 2. */
                } else if ((rtu_Main_InSig == Off) && (rtu_Main_InSig_m == Off) && (rtu_Main_InSig_l == Off)) {
                  App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_NO_ACTIVE_CHILD_dl;
                  App_Model_DW.is_WPCMode_Enable_b = App_Model_IN_WPCMode_Run;
                  *rty_MainOut_Sig_a = On;

                  /* b_ROHMOperCmd = On /_ Non GFS _/ */
                  App_Model_DW.is_WPCMode_Run_b = App_Model_IN_WPCRun_Standby;
                  *rty_MainOut_Sig = WPCWarningOff;

                  /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
                  *rty_MainOut_Sig_m = Off;
                  *rty_MainOut_Sig_l = Off;
                  *rty_MainOut_Sig_g = Off;
                } else if (rtu_Main_InSig_f == On) {
                  /* CardDetect_Nidec] */
                  App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_CardDetectError;
                  *rty_MainOut_Sig = NFCCardDetected;
                  *rty_MainOut_Sig_h = BlinkOff;
                  App_Model_DW.Counter_BlinkCnt_a = 0U;
                  *rty_MainOut_Sig_g = Off;
                  App__Function_CardLEDErrorBlink(rtu_Main_InSig_h0, rty_MainOut_Sig_l, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
                  *rty_MainOut_Sig_gy = On;
                }
                break;

               case App_Model_IN_WPCStop_TempErr:
                {
                  /* 1. */
                  if (rtu_Main_InSig_gy == Off) {
                    sint32 b_previousEvent;
                    *rty_MainOut_Sig_h = BlinkOff;
                    App_Model_DW.Counter_BlinkCnt_a = 0U;
                    b_previousEvent = App_Model_DW.sfEvent_a;
                    App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
                    if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
                      App_Mode_Tick_Timer_AmberINDBlk();
                    }

                    App_Model_DW.sfEvent_a = b_previousEvent;

                    /*  Non GFS  */
                    *rty_MainOut_Sig_gy = Off;
                    App_Model_DW.is_WPCMode_Stop_i = App_Model_IN_WPCStop_NotTempErr;

                    /* 240926 */
                    *rty_MainOut_Sig_a = Off;
                    *rty_MainOut_Sig = WPCWarningOff;
                    *rty_MainOut_Sig_g = Off;
                  } else {
                    App_Mode_Function_LEDErrorBlink(rtu_Main_InSig_lz, rtu_Main_InSig_h0, rty_MainOut_Sig_g, rty_MainOut_Sig_gy, rty_MainOut_Sig_h);
                  }
                }
                break;
              }
            }
          }
          break;
        }
      }
    }
    break;

   case App_Model_IN_WPCMode_Init:
    /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
    *rty_MainOut_Sig_m = Off;

    /* 1. */
    if (rtu_Main_InSig_h != WPCMode) {
      App_Model_DW.is_MainControl_o = App_Model_IN_WPCMode_Disable;

      /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
      Ap_enter_atomic_WPCMode_Disable(rty_MainOut_Sig, rty_MainOut_Sig_m, rty_MainOut_Sig_l, rty_MainOut_Sig_g, rty_MainOut_Sig_h, rty_MainOut_Sig_k);
      enter_internal_WPCMode_Disable(rtu_Main_InSig_g, rtu_Main_InSig_b, rtu_Main_InSig_j, rtu_Main_InSig_jy, rtu_Main_InSig_h, rty_MainOut_Sig, rty_MainOut_Sig_b, rty_MainOut_Sig_j,
        rty_MainOut_Sig_jy, rty_MainOut_Sig_k);

      /* 2 */
    } else if (rtu_Main_InSig_h == WPCMode) {
      App_Model_DW.is_MainControl_o = App_Model_IN_WPCMode_Enable;
      App_Model_DW.is_WPCMode_Enable_b = App_Model_IN_WPCMode_Stop;

      /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
      *rty_MainOut_Sig_m = Off;
      *rty_MainOut_Sig_l = Off;

      /* b_ChargingEnable = Off */
      App_enter_internal_WPCMode_Stop(rtu_Main_InSig_gy, rtu_Main_InSig_lz, rtu_Main_InSig_h0, rtu_Main_InSig_f, rty_MainOut_Sig, rty_MainOut_Sig_l, rty_MainOut_Sig_g, rty_MainOut_Sig_gy,
        rty_MainOut_Sig_a, rty_MainOut_Sig_h);
    }
    break;
  }
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Phone(void)
{
  App_Model_DW.is_Tick_Timer_PhoneLeft_b = App_Model_IN_Off_c;
  App_Model_DW.Timer_PhoneLeft_n = 0U;
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Pho_e(uint16 *rty_MainOut_Sig_j)
{
  App_Model_DW.is_Tick_Timer_PhoneWarningChe_i = App_Model_IN_Off_c;
  App_Model_DW.Timer_PhoneWarningCheck_m = 0U;

  /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
  *rty_MainOut_Sig_j = 0U;
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Pho_d(uint16 *rty_MainOut_Sig_b)
{
  App_Model_DW.is_Tick_Timer_PhoneReminderCh_o = App_Model_IN_Off_c;
  App_Model_DW.Timer_PhoneReminderCheck_e = 0U;

  /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
  *rty_MainOut_Sig_b = 0U;
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Warni(uint16 *rty_MainOut_Sig_jy)
{
  App_Model_DW.is_Tick_Timer_WarningComplete_j = App_Model_IN_Off_c;
  App_Model_DW.Timer_WarningComplete_d = 0U;

  /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
  *rty_MainOut_Sig_jy = 0U;
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Amber(void)
{
  App_Model_DW.is_Tick_Timer_AmberINDBlk_f = App_Model_IN_Off_c;
  App_Model_DW.Timer_AmberINDBlk_l = 0U;
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Amb_m(void)
{
  App_Model_DW.is_Tick_Timer_AmberINDBlk2_e = App_Model_IN_Off_c;
  App_Model_DW.Timer_AmberINDBlk2_p = 0U;
}

/* Function for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Green(void)
{
  App_Model_DW.is_Tick_Timer_GreenINDBlk_i = App_Model_IN_Off_c;
  App_Model_DW.Timer_GreenINDBlk_d = 0U;
}

/* System initialize for atomic system: '<S13>/WPC_MainControl_Function' */
void A_WPC_MainControl_Function_Init(C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_m, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, uint16 *rty_MainOut_Sig_b,
  uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_jy, Bool *rty_MainOut_Sig_a, BlinkState *rty_MainOut_Sig_h, Bool *rty_MainOut_Sig_k)
{
  /* SystemInitialize for Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
  App_Model_DW.sfEvent_a = App_Model_CALL_EVENT_d;
  *rty_MainOut_Sig = WPCWarningOff;
  *rty_MainOut_Sig_m = Off;
  *rty_MainOut_Sig_l = Off;
  *rty_MainOut_Sig_g = Off;
  *rty_MainOut_Sig_gy = Off;
  *rty_MainOut_Sig_b = 0U;
  *rty_MainOut_Sig_j = 0U;
  *rty_MainOut_Sig_jy = 0U;
  *rty_MainOut_Sig_a = Off;
  *rty_MainOut_Sig_h = BlinkOff;
  *rty_MainOut_Sig_k = Off;
}

/* Output and update for atomic system: '<S13>/WPC_MainControl_Function' */
void App_Mo_WPC_MainControl_Function(Bool rtu_Main_InSig, Bool rtu_Main_InSig_m, Bool rtu_Main_InSig_l, C_WPCOnOffNvalueSet rtu_Main_InSig_g, Bool rtu_Main_InSig_gy, Bool rtu_Main_InSig_b, Bool
  rtu_Main_InSig_j, Bool rtu_Main_InSig_jy, DeviceState rtu_Main_InSig_a, WPCStatus rtu_Main_InSig_h, Bool rtu_Main_InSig_k, WPCIndUSMState rtu_Main_InSig_lz, Bool rtu_Main_InSig_h0, WPCIndCmdState
  rtu_Main_InSig_k1, Bool rtu_Main_InSig_f, C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_m, Bool *rty_MainOut_Sig_l, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_gy, uint16
  *rty_MainOut_Sig_b, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_jy, Bool *rty_MainOut_Sig_a, BlinkState *rty_MainOut_Sig_h, Bool *rty_MainOut_Sig_k)
{
  /* Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
  App_Model_DW.sfEvent_a = App_Model_CALL_EVENT_d;
  App_Model_DW.b_WPCPhoneExist_prev_e = App_Model_DW.b_WPCPhoneExist_start_f;
  App_Model_DW.b_WPCPhoneExist_start_f = rtu_Main_InSig_jy;
  App_Model_DW.WPCIndCmdState_prev = App_Model_DW.WPCIndCmdState_start;
  App_Model_DW.WPCIndCmdState_start = rtu_Main_InSig_k1;
  App_Model_DW.L_IGN1_IN_prev_c = App_Model_DW.L_IGN1_IN_start_b;
  App_Model_DW.L_IGN1_IN_start_b = rtu_Main_InSig_k;
  if (App_Model_DW.is_active_c51_MainControl_Lib == 0U) {
    App_Model_DW.b_WPCPhoneExist_prev_e = rtu_Main_InSig_jy;
    App_Model_DW.WPCIndCmdState_prev = rtu_Main_InSig_k1;
    App_Model_DW.L_IGN1_IN_prev_c = rtu_Main_InSig_k;
    App_Model_DW.is_active_c51_MainControl_Lib = 1U;
    App_Model_DW.is_active_MainControl_g = 1U;
    App_Model_DW.is_MainControl_o = App_Model_IN_WPCMode_Init;
    *rty_MainOut_Sig = WPCWarningOff;
    *rty_MainOut_Sig_h = BlinkOff;
    App_Model_DW.Counter_BlinkCnt_a = 0U;
    App_Model_DW.b_WarnClearEnable_m = Off;
    *rty_MainOut_Sig_m = Off;
    *rty_MainOut_Sig_l = Off;
    *rty_MainOut_Sig_g = Off;
    *rty_MainOut_Sig_a = Off;
    *rty_MainOut_Sig_k = Off;
    App_Model_DW.sfEvent_a = Ap_event_Cancel_Timer_PhoneLeft;
    if (App_Model_DW.is_active_Tick_Timer_PhoneLef_n != 0U) {
      App_Model_Tick_Timer_PhoneLeft();
    }

    App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneWarning;
    if (App_Model_DW.is_active_Tick_Timer_PhoneWar_n != 0U) {
      Ap_Tick_Timer_PhoneWarningCheck(rty_MainOut_Sig_j);
    }

    App_Model_DW.sfEvent_a = event_Cancel_Timer_PhoneReminde;
    if (App_Model_DW.is_active_Tick_Timer_PhoneRem_a != 0U) {
      A_Tick_Timer_PhoneReminderCheck(rty_MainOut_Sig_b);
    }

    App_Model_DW.sfEvent_a = event_Cancel_Timer_WarningCompl;
    if (App_Model_DW.is_active_Tick_Timer_WarningC_o != 0U) {
      App__Tick_Timer_WarningComplete(rty_MainOut_Sig_jy);
    }

    App_Model_DW.sfEvent_a = event_Cancel_Timer_AmberINDBlk;
    if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
      App_Mode_Tick_Timer_AmberINDBlk();
    }

    App_Model_DW.sfEvent_a = -1;
    App_Model_DW.is_active_Tick_Timer_PhoneLef_n = 1U;
    enter_internal_Tick_Timer_Phone();
    App_Model_DW.is_active_Tick_Timer_PhoneWar_n = 1U;
    enter_internal_Tick_Timer_Pho_e(rty_MainOut_Sig_j);
    App_Model_DW.is_active_Tick_Timer_PhoneRem_a = 1U;
    enter_internal_Tick_Timer_Pho_d(rty_MainOut_Sig_b);
    App_Model_DW.is_active_Tick_Timer_WarningC_o = 1U;
    enter_internal_Tick_Timer_Warni(rty_MainOut_Sig_jy);
    App_Model_DW.is_active_Tick_Timer_AmberIND_c = 1U;
    enter_internal_Tick_Timer_Amber();
    App_Model_DW.is_active_Tick_Timer_AmberIND_g = 1U;
    enter_internal_Tick_Timer_Amb_m();
    App_Model_DW.is_active_Tick_Timer_GreenIND_e = 1U;
    enter_internal_Tick_Timer_Green();
  } else {
    if (App_Model_DW.is_active_MainControl_g != 0U) {
      App_Model_MainControl(rtu_Main_InSig, rtu_Main_InSig_m, rtu_Main_InSig_l, rtu_Main_InSig_g, rtu_Main_InSig_gy, rtu_Main_InSig_b, rtu_Main_InSig_j, rtu_Main_InSig_jy, rtu_Main_InSig_a,
                            rtu_Main_InSig_h, rtu_Main_InSig_lz, rtu_Main_InSig_h0, rtu_Main_InSig_f, rty_MainOut_Sig, rty_MainOut_Sig_m, rty_MainOut_Sig_l, rty_MainOut_Sig_g, rty_MainOut_Sig_gy,
                            rty_MainOut_Sig_b, rty_MainOut_Sig_j, rty_MainOut_Sig_jy, rty_MainOut_Sig_a, rty_MainOut_Sig_h, rty_MainOut_Sig_k);
    }

    if (App_Model_DW.is_active_Tick_Timer_PhoneLef_n != 0U) {
      App_Model_Tick_Timer_PhoneLeft();
    }

    if (App_Model_DW.is_active_Tick_Timer_PhoneWar_n != 0U) {
      Ap_Tick_Timer_PhoneWarningCheck(rty_MainOut_Sig_j);
    }

    if (App_Model_DW.is_active_Tick_Timer_PhoneRem_a != 0U) {
      A_Tick_Timer_PhoneReminderCheck(rty_MainOut_Sig_b);
    }

    if (App_Model_DW.is_active_Tick_Timer_WarningC_o != 0U) {
      App__Tick_Timer_WarningComplete(rty_MainOut_Sig_jy);
    }

    if (App_Model_DW.is_active_Tick_Timer_AmberIND_c != 0U) {
      App_Mode_Tick_Timer_AmberINDBlk();
    }

    if (App_Model_DW.is_active_Tick_Timer_AmberIND_g != 0U) {
      App_Mod_Tick_Timer_AmberINDBlk2();
    }

    if (App_Model_DW.is_active_Tick_Timer_GreenIND_e != 0U) {
      App_Mode_Tick_Timer_GreenINDBlk();
    }
  }

  /* End of Chart: '<S200>/WPC_MainControl4_GreenSync_240926' */
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_Function_ChargingINDColor_e(WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_n4, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e)
{
  /* 1. */
  if ((rtu_Main_InSig_k == WPCIndUSMState__Type2) || (rtu_Main_InSig_n4 == On)) {
    /* CardDetect_240207] */
    *rty_MainOut_Sig_b = On;
    *rty_MainOut_Sig_e = Off;
  } else {
    *rty_MainOut_Sig_b = Off;
    *rty_MainOut_Sig_e = On;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_M_Tick_Timer_AmberINDBlk2_n(void)
{
  switch (App_Model_DW.is_Tick_Timer_AmberINDBlk2) {
   case App_Model_IN_Off_h:
    if (App_Model_DW.sfEvent_h == event_Start_Timer_AmberINDBlk_l) {
      App_Model_DW.is_Tick_Timer_AmberINDBlk2 = App_Model_IN_On_b;
    }
    break;

   case App_Model_IN_On_b:
    {
      if (App_Model_DW.sfEvent_h == event_Cancel_Timer_AmberINDBl_e) {
        App_Model_DW.is_Tick_Timer_AmberINDBlk2 = App_Model_IN_Off_h;
        App_Model_DW.Timer_AmberINDBlk2 = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_AmberINDBlk2 + 1;
        if (App_Model_DW.Timer_AmberINDBlk2 + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_AmberINDBlk2 = (uint16)tmp;
        if (App_Model_DW.sfEvent_h == event_Start_Timer_AmberINDBlk_l) {
          App_Model_DW.Timer_AmberINDBlk2 = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_Mo_Tick_Timer_AmberINDBlk_j(void)
{
  switch (App_Model_DW.is_Tick_Timer_AmberINDBlk) {
   case App_Model_IN_Off_h:
    if (App_Model_DW.sfEvent_h == event_Start_Timer_AmberINDBlk_m) {
      App_Model_DW.is_Tick_Timer_AmberINDBlk = App_Model_IN_On_b;
    }
    break;

   case App_Model_IN_On_b:
    {
      if (App_Model_DW.sfEvent_h == event_Cancel_Timer_AmberINDBl_g) {
        App_Model_DW.is_Tick_Timer_AmberINDBlk = App_Model_IN_Off_h;
        App_Model_DW.Timer_AmberINDBlk = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_AmberINDBlk + 1;
        if (App_Model_DW.Timer_AmberINDBlk + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_AmberINDBlk = (uint16)tmp;
        if (App_Model_DW.sfEvent_h == event_Start_Timer_AmberINDBlk_m) {
          App_Model_DW.Timer_AmberINDBlk = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_Mo_Function_LEDErrorBlink_k(WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_nw, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, BlinkState *rty_MainOut_Sig_po)
{
  switch (rtu_Main_InSig_nw) {
   case Off:
    {
      /* For_OnlyAmber%WPC�� �ϳ��̰ų� �켱������ ���� ������� */
      /* 1. */
      if ((*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.Counter_BlinkCnt >= 10)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkComplete;
        *rty_MainOut_Sig_e = Off;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_e;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;
        *rty_MainOut_Sig_gc = Off;

        /*  Non GFS  */
      } else if (App_Model_DW.Counter_BlinkCnt >= 10) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkComplete;
        *rty_MainOut_Sig_e = Off;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_e;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;
        *rty_MainOut_Sig_gc = Off;

        /*  Non GFS  */
      } else if ((rtu_Main_InSig_k == WPCIndUSMState__Type2) && (*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.is_Tick_Timer_AmberINDBlk2 == App_Model_IN_Off_h)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkOn;
        *rty_MainOut_Sig_e = On;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_l;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;
      } else if ((rtu_Main_InSig_k != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.is_Tick_Timer_AmberINDBlk == App_Model_IN_Off_h)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkOn;

        /* Counter_BlinkCnt ++ */
        *rty_MainOut_Sig_e = Off;

        /* OffStart */
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_m;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_k != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_po == BlinkOff) && ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) &&
                  (App_Model_DW.WPC2IndCmdState_prev == WPC2IndCmdState__ErrorFadeIn))) {
        sint32 t_previousEvent;

        /* Timer_AmberINDBlk >= Par_LEDBlinkTime] */
        *rty_MainOut_Sig_po = BlinkOn;
        App_Model_DW.Counter_BlinkCnt++;
        *rty_MainOut_Sig_e = Off;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_m;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_k != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_po == BlinkOn) && (((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) &&
                   (App_Model_DW.WPC2IndCmdState_prev == WPC2IndCmdState__ErrorFadeOut)) || ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) &&
                   (App_Model_DW.WPC2IndCmdState_start == WPC2IndCmdState__ErrorOn)))) {
        sint32 t_previousEvent;

        /* Timer_AmberINDBlk >= Par_LEDBlinkTime] */
        *rty_MainOut_Sig_po = BlinkOff;
        *rty_MainOut_Sig_e = On;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_m;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_k == WPCIndUSMState__Type2) && ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_prev ==
                   WPC2IndCmdState__ErrorFadeIn))) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkOn;
        *rty_MainOut_Sig_e = On;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_l;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_k == WPCIndUSMState__Type2) && ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_prev ==
                   WPC2IndCmdState__ErrorFadeOut))) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkOff;
        App_Model_DW.Counter_BlinkCnt++;

        /* Adapt after FadeOut and LEDOff // 230110 */
        *rty_MainOut_Sig_e = Off;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_l;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;
      }
    }
    break;

   case On:
    {
      /* For_OnlyAmber%WPC�� ŸWPC�� ���� �켱������ ������� */
      /* 1. */
      if ((*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.Counter_BlinkCnt >= 10)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkComplete;
        *rty_MainOut_Sig_e = Off;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_e;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;
        *rty_MainOut_Sig_gc = Off;

        /*  Non GFS  */
      } else if (App_Model_DW.Counter_BlinkCnt >= 10) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkComplete;
        *rty_MainOut_Sig_e = Off;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_e;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;
        *rty_MainOut_Sig_gc = Off;

        /*  Non GFS  */
      } else if ((rtu_Main_InSig_k == WPCIndUSMState__Type2) && (*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.is_Tick_Timer_AmberINDBlk2 == App_Model_IN_Off_h)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkOn;
        *rty_MainOut_Sig_e = On;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_l;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;
      } else if ((rtu_Main_InSig_k != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.is_Tick_Timer_AmberINDBlk == App_Model_IN_Off_h)) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkOn;

        /* Counter_BlinkCnt ++ */
        *rty_MainOut_Sig_e = Off;

        /* OffStart */
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_m;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_k != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_po == BlinkOff) && ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) &&
                  (App_Model_DW.WPC2IndCmdState_prev == WPC2IndCmdState__ErrorFadeIn))) {
        sint32 t_previousEvent;

        /* Timer_AmberINDBlk >= Par_LEDBlinkTime] */
        *rty_MainOut_Sig_po = BlinkOn;
        App_Model_DW.Counter_BlinkCnt++;
        *rty_MainOut_Sig_e = Off;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_m;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_k != WPCIndUSMState__Type2) && (*rty_MainOut_Sig_po == BlinkOn) && (((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) &&
                   (App_Model_DW.WPC2IndCmdState_prev == WPC2IndCmdState__ErrorFadeOut)) || ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) &&
                   (App_Model_DW.WPC2IndCmdState_start == WPC2IndCmdState__ErrorOn)))) {
        sint32 t_previousEvent;

        /* Timer_AmberINDBlk >= Par_LEDBlinkTime] */
        *rty_MainOut_Sig_po = BlinkOff;
        *rty_MainOut_Sig_e = On;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_m;
        if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
          App_Mo_Tick_Timer_AmberINDBlk_j();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_k == WPCIndUSMState__Type2) && ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_prev ==
                   WPC2IndCmdState__ErrorFadeIn))) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkOn;
        *rty_MainOut_Sig_e = On;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_l;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;

        /* 1. */
      } else if ((rtu_Main_InSig_k == WPCIndUSMState__Type2) && ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_prev ==
                   WPC2IndCmdState__ErrorFadeOut))) {
        sint32 t_previousEvent;
        *rty_MainOut_Sig_po = BlinkOff;
        App_Model_DW.Counter_BlinkCnt++;

        /* Adapt after FadeOut and LEDOff // 230110 */
        *rty_MainOut_Sig_e = Off;
        t_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_AmberINDBlk_l;
        if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
          App_M_Tick_Timer_AmberINDBlk2_n();
        }

        App_Model_DW.sfEvent_h = t_previousEvent;
      }
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_exit_internal_WPCMode_Run_c(Bool *rty_MainOut_Sig_gc, BlinkState *rty_MainOut_Sig_po)
{
  if (App_Model_DW.is_WPCMode_Run == App_Model_IN_WPCRun_FODError_d) {
    sint32 b_previousEvent;
    *rty_MainOut_Sig_po = BlinkOff;
    App_Model_DW.Counter_BlinkCnt = 0U;
    b_previousEvent = App_Model_DW.sfEvent_h;
    App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
    if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
      App_Mo_Tick_Timer_AmberINDBlk_j();
    }

    App_Model_DW.sfEvent_h = b_previousEvent;

    /*  Non GFS  */
    *rty_MainOut_Sig_gc = Off;
    App_Model_DW.is_WPCMode_Run = App_Model_IN_NO_ACTIVE_CHILD_kn;
  } else {
    App_Model_DW.is_WPCMode_Run = App_Model_IN_NO_ACTIVE_CHILD_kn;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_Mo_Tick_Timer_GreenINDBlk_f(void)
{
  switch (App_Model_DW.is_Tick_Timer_GreenINDBlk) {
   case App_Model_IN_Off_h:
    if (App_Model_DW.sfEvent_h == event_Start_Timer_GreenINDBlk_n) {
      App_Model_DW.is_Tick_Timer_GreenINDBlk = App_Model_IN_On_b;
    }
    break;

   case App_Model_IN_On_b:
    {
      if (App_Model_DW.sfEvent_h == event_Cancel_Timer_GreenINDBl_l) {
        App_Model_DW.is_Tick_Timer_GreenINDBlk = App_Model_IN_Off_h;
        App_Model_DW.Timer_GreenINDBlk = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_GreenINDBlk + 1;
        if (App_Model_DW.Timer_GreenINDBlk + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_GreenINDBlk = (uint16)tmp;
        if (App_Model_DW.sfEvent_h == event_Start_Timer_GreenINDBlk_n) {
          App_Model_DW.Timer_GreenINDBlk = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void Ap_Function_CardLEDErrorBlink_e(Bool rtu_Main_InSig_nw, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_gc, BlinkState *rty_MainOut_Sig_po)
{
  switch (rtu_Main_InSig_nw) {
   case Off:
    {
      /* For_OnlyAmber%WPC�� �ϳ��̰ų� �켱������ ���� ������� */
      if ((*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.Counter_BlinkCnt >= 2)) {
        *rty_MainOut_Sig_po = BlinkComplete;
        *rty_MainOut_Sig_b = Off;
        *rty_MainOut_Sig_gc = Off;
      } else if (App_Model_DW.Counter_BlinkCnt >= 2) {
        sint32 d_previousEvent;
        *rty_MainOut_Sig_po = BlinkComplete;
        *rty_MainOut_Sig_b = Off;
        d_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Cancel_Timer_GreenINDBl_l;
        if (App_Model_DW.is_active_Tick_Timer_GreenINDBl != 0U) {
          App_Mo_Tick_Timer_GreenINDBlk_f();
        }

        App_Model_DW.sfEvent_h = d_previousEvent;
        *rty_MainOut_Sig_gc = Off;
      } else if ((*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.is_Tick_Timer_GreenINDBlk == App_Model_IN_Off_h)) {
        sint32 d_previousEvent;
        *rty_MainOut_Sig_po = BlinkOff;
        *rty_MainOut_Sig_b = Off;
        d_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_GreenINDBlk_n;
        if (App_Model_DW.is_active_Tick_Timer_GreenINDBl != 0U) {
          App_Mo_Tick_Timer_GreenINDBlk_f();
        }

        App_Model_DW.sfEvent_h = d_previousEvent;
      } else if ((*rty_MainOut_Sig_po == BlinkOn) && ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_prev == WPC2IndCmdState__ErrorFadeIn)))
      {
        *rty_MainOut_Sig_po = BlinkOff;
        App_Model_DW.Counter_BlinkCnt++;
        *rty_MainOut_Sig_b = Off;
      } else if ((*rty_MainOut_Sig_po == BlinkOff) && (((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_prev == WPC2IndCmdState__ErrorFadeOut))
                  || ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_start == WPC2IndCmdState__ErrorOn)))) {
        *rty_MainOut_Sig_po = BlinkOn;

        /* Counter_BlinkCnt ++; */
        *rty_MainOut_Sig_b = On;
      }
    }
    break;

   case On:
    {
      /* For_OnlyAmber%WPC�� ŸWPC�� ���� �켱������ ������� */
      if ((*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.Counter_BlinkCnt >= 2)) {
        *rty_MainOut_Sig_po = BlinkComplete;
        *rty_MainOut_Sig_b = Off;
        *rty_MainOut_Sig_gc = Off;
      } else if (App_Model_DW.Counter_BlinkCnt >= 2) {
        sint32 d_previousEvent;
        *rty_MainOut_Sig_po = BlinkComplete;
        *rty_MainOut_Sig_b = Off;
        d_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Cancel_Timer_GreenINDBl_l;
        if (App_Model_DW.is_active_Tick_Timer_GreenINDBl != 0U) {
          App_Mo_Tick_Timer_GreenINDBlk_f();
        }

        App_Model_DW.sfEvent_h = d_previousEvent;
        *rty_MainOut_Sig_gc = Off;
      } else if ((*rty_MainOut_Sig_po != BlinkComplete) && (App_Model_DW.is_Tick_Timer_GreenINDBlk == App_Model_IN_Off_h)) {
        sint32 d_previousEvent;
        *rty_MainOut_Sig_po = BlinkOff;
        *rty_MainOut_Sig_b = Off;
        d_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Start_Timer_GreenINDBlk_n;
        if (App_Model_DW.is_active_Tick_Timer_GreenINDBl != 0U) {
          App_Mo_Tick_Timer_GreenINDBlk_f();
        }

        App_Model_DW.sfEvent_h = d_previousEvent;
      } else if ((*rty_MainOut_Sig_po == BlinkOn) && ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_prev == WPC2IndCmdState__ErrorFadeIn)))
      {
        *rty_MainOut_Sig_po = BlinkOff;
        App_Model_DW.Counter_BlinkCnt++;
        *rty_MainOut_Sig_b = Off;
      } else if ((*rty_MainOut_Sig_po == BlinkOff) && (((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_prev == WPC2IndCmdState__ErrorFadeOut))
                  || ((App_Model_DW.WPC2IndCmdState_prev != App_Model_DW.WPC2IndCmdState_start) && (App_Model_DW.WPC2IndCmdState_start == WPC2IndCmdState__ErrorOn)))) {
        *rty_MainOut_Sig_po = BlinkOn;

        /* Counter_BlinkCnt ++; */
        *rty_MainOut_Sig_b = On;
      }
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void A_enter_internal_WPCMode_Stop_d(Bool rtu_Main_InSig_b, WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_nw, Bool rtu_Main_InSig_n4, C_WPCWarning *rty_MainOut_Sig, Bool
  *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, Bool *rty_MainOut_Sig_p, BlinkState *rty_MainOut_Sig_po)
{
  /* 1. */
  if (rtu_Main_InSig_b == On) {
    App_Model_DW.is_WPCMode_Stop = App_Model_IN_WPCStop_TempErr_c;

    /* 240926 */
    *rty_MainOut_Sig_p = Off;
    *rty_MainOut_Sig = Charging_error;
    *rty_MainOut_Sig_po = BlinkOff;
    App_Model_DW.Counter_BlinkCnt = 0U;
    App_Mo_Function_LEDErrorBlink_k(rtu_Main_InSig_k, rtu_Main_InSig_nw, rty_MainOut_Sig_e, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);

    /*  Non GFS  */
    *rty_MainOut_Sig_gc = On;
  } else if (rtu_Main_InSig_n4 == On) {
    /* CardDetect_240207] */
    App_Model_DW.is_WPCMode_Stop = App_Model_IN_CardDetectError_f;
    *rty_MainOut_Sig = NFCCardDetected;
    *rty_MainOut_Sig_po = BlinkOff;
    App_Model_DW.Counter_BlinkCnt = 0U;
    *rty_MainOut_Sig_e = Off;
    Ap_Function_CardLEDErrorBlink_e(rtu_Main_InSig_nw, rty_MainOut_Sig_b, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
    *rty_MainOut_Sig_gc = On;
  } else {
    App_Model_DW.is_WPCMode_Stop = App_Mod_IN_WPCStop_NotTempErr_f;

    /* 240926 */
    *rty_MainOut_Sig_p = Off;
    *rty_MainOut_Sig = WPCWarningOff;
    *rty_MainOut_Sig_e = Off;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_Model_WPCMode_Run_h(Bool rtu_Main_InSig, Bool rtu_Main_InSig_g, Bool rtu_Main_InSig_b, DeviceState rtu_Main_InSig_nt, WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_nw, Bool
  rtu_Main_InSig_n4, C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, Bool *rty_MainOut_Sig_p, BlinkState
  *rty_MainOut_Sig_po)
{
  /* 1. */
  if ((rtu_Main_InSig == On) || (rtu_Main_InSig_g == On) || (rtu_Main_InSig_b == On) || (rtu_Main_InSig_b == On) || (rtu_Main_InSig_n4 == On)) {
    /* CardDetect_240207] */
    App_exit_internal_WPCMode_Run_c(rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
    App_Model_DW.is_WPCMode_Enable = App_Model_IN_WPCMode_Stop_m;
    *rty_MainOut_Sig_g = Off;
    *rty_MainOut_Sig_b = Off;

    /* b_ChargingEnable = Off */
    A_enter_internal_WPCMode_Stop_d(rtu_Main_InSig_b, rtu_Main_InSig_k, rtu_Main_InSig_nw, rtu_Main_InSig_n4, rty_MainOut_Sig, rty_MainOut_Sig_b, rty_MainOut_Sig_e, rty_MainOut_Sig_gc,
      rty_MainOut_Sig_p, rty_MainOut_Sig_po);
  } else {
    switch (App_Model_DW.is_WPCMode_Run) {
     case App_Model_IN_WPCRun_Charging_f:
      *rty_MainOut_Sig_g = On;

      /* 1. */
      if ((rtu_Main_InSig_nt == Standby) || (rtu_Main_InSig_nt == Init)) {
        App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_Standby_a;
        *rty_MainOut_Sig = WPCWarningOff;

        /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
        *rty_MainOut_Sig_g = Off;
        *rty_MainOut_Sig_b = Off;
        *rty_MainOut_Sig_e = Off;
      } else {
        /* 2. */
        switch (rtu_Main_InSig_nt) {
         case FODError:
          /*  b_FODFault == On] */
          App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_FODError_d;
          *rty_MainOut_Sig = Charging_error;

          /* b_WPCWarn = Charging_error 8�� LFRollBack */
          *rty_MainOut_Sig_po = BlinkOff;
          App_Model_DW.Counter_BlinkCnt = 0U;
          *rty_MainOut_Sig_g = Off;
          *rty_MainOut_Sig_b = Off;
          App_Mo_Function_LEDErrorBlink_k(rtu_Main_InSig_k, rtu_Main_InSig_nw, rty_MainOut_Sig_e, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);

          /*  Non GFS  */
          *rty_MainOut_Sig_gc = On;
          break;

         case Full_Charge:
          /* 3. */
          App_Model_DW.is_WPCMode_Run = Ap_IN_WPCRun_ChargingComplete_a;
          *rty_MainOut_Sig = Charging_Complete;

          /* b_WPCWarn = Charging_Complete 8�� LFRollBack */
          *rty_MainOut_Sig_g = On;
          *rty_MainOut_Sig_b = On;
          *rty_MainOut_Sig_e = Off;
          break;

         default:
          App_Function_ChargingINDColor_e(rtu_Main_InSig_k, rtu_Main_InSig_n4, rty_MainOut_Sig_b, rty_MainOut_Sig_e);
          break;
        }
      }
      break;

     case Ap_IN_WPCRun_ChargingComplete_a:
      *rty_MainOut_Sig_g = On;

      /* 1. */
      if ((rtu_Main_InSig_nt == Standby) || (rtu_Main_InSig_nt == Init)) {
        App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_Standby_a;
        *rty_MainOut_Sig = WPCWarningOff;

        /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
        *rty_MainOut_Sig_g = Off;
        *rty_MainOut_Sig_b = Off;
        *rty_MainOut_Sig_e = Off;
      } else {
        /* 2. */
        switch (rtu_Main_InSig_nt) {
         case FODError:
          /*  b_FODFault == On] */
          App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_FODError_d;
          *rty_MainOut_Sig = Charging_error;

          /* b_WPCWarn = Charging_error 8�� LFRollBack */
          *rty_MainOut_Sig_po = BlinkOff;
          App_Model_DW.Counter_BlinkCnt = 0U;
          *rty_MainOut_Sig_g = Off;
          *rty_MainOut_Sig_b = Off;
          App_Mo_Function_LEDErrorBlink_k(rtu_Main_InSig_k, rtu_Main_InSig_nw, rty_MainOut_Sig_e, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);

          /*  Non GFS  */
          *rty_MainOut_Sig_gc = On;
          break;

         case Charging:
          /* 3. */
          App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_Charging_f;
          *rty_MainOut_Sig = PhoneCharging;

          /* b_WPCWarn = PhoneCharging 8�� LFRollBack */
          *rty_MainOut_Sig_g = On;
          App_Function_ChargingINDColor_e(rtu_Main_InSig_k, rtu_Main_InSig_n4, rty_MainOut_Sig_b, rty_MainOut_Sig_e);
          break;
        }
      }
      break;

     case App_Model_IN_WPCRun_FODError_d:
      {
        *rty_MainOut_Sig_g = Off;

        /* 1. */
        if ((rtu_Main_InSig_nt == Standby) || (rtu_Main_InSig_nt == Init)) {
          sint32 c_previousEvent;

          /*  BlinkState == BlinkComplete 8�� ���� */
          *rty_MainOut_Sig_po = BlinkOff;
          App_Model_DW.Counter_BlinkCnt = 0U;
          c_previousEvent = App_Model_DW.sfEvent_h;
          App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
          if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
            App_Mo_Tick_Timer_AmberINDBlk_j();
          }

          App_Model_DW.sfEvent_h = c_previousEvent;

          /*  Non GFS  */
          *rty_MainOut_Sig_gc = Off;
          App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_Standby_a;
          *rty_MainOut_Sig = WPCWarningOff;

          /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
          *rty_MainOut_Sig_g = Off;
          *rty_MainOut_Sig_b = Off;
          *rty_MainOut_Sig_e = Off;
        } else {
          /* 2. */
          switch (rtu_Main_InSig_nt) {
           case Charging:
            {
              sint32 c_previousEvent;

              /*  BlinkState == BlinkComplete 8�� ���� */
              *rty_MainOut_Sig_po = BlinkOff;
              App_Model_DW.Counter_BlinkCnt = 0U;
              c_previousEvent = App_Model_DW.sfEvent_h;
              App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
              if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
                App_Mo_Tick_Timer_AmberINDBlk_j();
              }

              App_Model_DW.sfEvent_h = c_previousEvent;

              /*  Non GFS  */
              *rty_MainOut_Sig_gc = Off;
              App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_Charging_f;
              *rty_MainOut_Sig = PhoneCharging;

              /* b_WPCWarn = PhoneCharging 8�� LFRollBack */
              *rty_MainOut_Sig_g = On;
              App_Function_ChargingINDColor_e(rtu_Main_InSig_k, rtu_Main_InSig_n4, rty_MainOut_Sig_b, rty_MainOut_Sig_e);
            }
            break;

           case Full_Charge:
            {
              sint32 c_previousEvent;

              /* 3. */
              /*  BlinkState == BlinkComplete 8�� ���� */
              *rty_MainOut_Sig_po = BlinkOff;
              App_Model_DW.Counter_BlinkCnt = 0U;
              c_previousEvent = App_Model_DW.sfEvent_h;
              App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
              if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
                App_Mo_Tick_Timer_AmberINDBlk_j();
              }

              App_Model_DW.sfEvent_h = c_previousEvent;

              /*  Non GFS  */
              *rty_MainOut_Sig_gc = Off;
              App_Model_DW.is_WPCMode_Run = Ap_IN_WPCRun_ChargingComplete_a;
              *rty_MainOut_Sig = Charging_Complete;

              /* b_WPCWarn = Charging_Complete 8�� LFRollBack */
              *rty_MainOut_Sig_g = On;
              *rty_MainOut_Sig_b = On;
              *rty_MainOut_Sig_e = Off;
            }
            break;

           default:
            App_Mo_Function_LEDErrorBlink_k(rtu_Main_InSig_k, rtu_Main_InSig_nw, rty_MainOut_Sig_e, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
            break;
          }
        }
      }
      break;

     case App_Model_IN_WPCRun_Standby_a:
      *rty_MainOut_Sig_g = Off;

      /* 1. */
      switch (rtu_Main_InSig_nt) {
       case FODError:
        /*  b_FODFault == On] */
        App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_FODError_d;
        *rty_MainOut_Sig = Charging_error;

        /* b_WPCWarn = Charging_error 8�� LFRollBack */
        *rty_MainOut_Sig_po = BlinkOff;
        App_Model_DW.Counter_BlinkCnt = 0U;
        *rty_MainOut_Sig_g = Off;
        *rty_MainOut_Sig_b = Off;
        App_Mo_Function_LEDErrorBlink_k(rtu_Main_InSig_k, rtu_Main_InSig_nw, rty_MainOut_Sig_e, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);

        /*  Non GFS  */
        *rty_MainOut_Sig_gc = On;
        break;

       case Charging:
        /* 2. */
        App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_Charging_f;
        *rty_MainOut_Sig = PhoneCharging;

        /* b_WPCWarn = PhoneCharging 8�� LFRollBack */
        *rty_MainOut_Sig_g = On;
        App_Function_ChargingINDColor_e(rtu_Main_InSig_k, rtu_Main_InSig_n4, rty_MainOut_Sig_b, rty_MainOut_Sig_e);
        break;

       case Full_Charge:
        /* 3. */
        App_Model_DW.is_WPCMode_Run = Ap_IN_WPCRun_ChargingComplete_a;
        *rty_MainOut_Sig = Charging_Complete;

        /* b_WPCWarn = Charging_Complete 8�� LFRollBack */
        *rty_MainOut_Sig_g = On;
        *rty_MainOut_Sig_b = On;
        *rty_MainOut_Sig_e = Off;
        break;
      }
      break;
    }
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void Ap_exit_internal_WPCMode_Stop_e(Bool *rty_MainOut_Sig_gc, BlinkState *rty_MainOut_Sig_po)
{
  switch (App_Model_DW.is_WPCMode_Stop) {
   case App_Model_IN_CardDetectError_f:
    {
      sint32 b_previousEvent;
      *rty_MainOut_Sig_po = BlinkOff;
      App_Model_DW.Counter_BlinkCnt = 0U;
      b_previousEvent = App_Model_DW.sfEvent_h;
      App_Model_DW.sfEvent_h = event_Cancel_Timer_GreenINDBl_l;
      if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
        App_Mo_Tick_Timer_AmberINDBlk_j();
      }

      App_Model_DW.sfEvent_h = b_previousEvent;
      *rty_MainOut_Sig_gc = Off;
      App_Model_DW.is_WPCMode_Stop = App_Model_IN_NO_ACTIVE_CHILD_kn;
    }
    break;

   case App_Model_IN_WPCStop_TempErr_c:
    {
      sint32 b_previousEvent;
      *rty_MainOut_Sig_po = BlinkOff;
      App_Model_DW.Counter_BlinkCnt = 0U;
      b_previousEvent = App_Model_DW.sfEvent_h;
      App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
      if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
        App_Mo_Tick_Timer_AmberINDBlk_j();
      }

      App_Model_DW.sfEvent_h = b_previousEvent;

      /*  Non GFS  */
      *rty_MainOut_Sig_gc = Off;
      App_Model_DW.is_WPCMode_Stop = App_Model_IN_NO_ACTIVE_CHILD_kn;
    }
    break;

   default:
    App_Model_DW.is_WPCMode_Stop = App_Model_IN_NO_ACTIVE_CHILD_kn;
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void enter_atomic_WPCMode_Disable_p(C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, BlinkState *rty_MainOut_Sig_po, Bool
  *rty_MainOut_Sig_k)
{
  sint32 b_previousEvent;
  *rty_MainOut_Sig = WPCWarningOff;
  *rty_MainOut_Sig_po = BlinkOff;
  App_Model_DW.Counter_BlinkCnt = 0U;
  *rty_MainOut_Sig_g = Off;
  *rty_MainOut_Sig_b = Off;
  *rty_MainOut_Sig_e = Off;
  *rty_MainOut_Sig_k = Off;
  b_previousEvent = App_Model_DW.sfEvent_h;
  App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
  if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
    App_Mo_Tick_Timer_AmberINDBlk_j();
  }

  App_Model_DW.sfEvent_h = b_previousEvent;
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_Mode_Tick_Timer_PhoneLeft_o(void)
{
  switch (App_Model_DW.is_Tick_Timer_PhoneLeft) {
   case App_Model_IN_Off_h:
    if (App_Model_DW.sfEvent_h == A_event_Start_Timer_PhoneLeft_b) {
      App_Model_DW.is_Tick_Timer_PhoneLeft = App_Model_IN_On_b;
    }
    break;

   case App_Model_IN_On_b:
    {
      if (App_Model_DW.sfEvent_h == event_Cancel_Timer_PhoneLeft_c) {
        App_Model_DW.is_Tick_Timer_PhoneLeft = App_Model_IN_Off_h;
        App_Model_DW.Timer_PhoneLeft = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_PhoneLeft + 1;
        if (App_Model_DW.Timer_PhoneLeft + 1 > 255) {
          tmp = 255;
        }

        App_Model_DW.Timer_PhoneLeft = (uint8)tmp;
        if (App_Model_DW.sfEvent_h == A_event_Start_Timer_PhoneLeft_b) {
          App_Model_DW.Timer_PhoneLeft = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void Tick_Timer_PhoneWarningCheck_e(uint16 *rty_MainOut_Sig_n)
{
  switch (App_Model_DW.is_Tick_Timer_PhoneWarningCheck) {
   case App_Model_IN_Off_h:
    if (App_Model_DW.sfEvent_h == event_Start_Timer_PhoneWarnin_a) {
      App_Model_DW.is_Tick_Timer_PhoneWarningCheck = App_Model_IN_On_b;
    }
    break;

   case App_Model_IN_On_b:
    {
      if (App_Model_DW.sfEvent_h == event_Cancel_Timer_PhoneWarni_c) {
        App_Model_DW.is_Tick_Timer_PhoneWarningCheck = App_Model_IN_Off_h;
        App_Model_DW.Timer_PhoneWarningCheck = 0U;
        *rty_MainOut_Sig_n = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_PhoneWarningCheck + 1;
        if (App_Model_DW.Timer_PhoneWarningCheck + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_PhoneWarningCheck = (uint16)tmp;
        *rty_MainOut_Sig_n = App_Model_DW.Timer_PhoneWarningCheck;
        if (App_Model_DW.sfEvent_h == event_Start_Timer_PhoneWarnin_a) {
          App_Model_DW.Timer_PhoneWarningCheck = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void Tick_Timer_PhoneReminderCheck_h(uint16 *rty_MainOut_Sig_j)
{
  switch (App_Model_DW.is_Tick_Timer_PhoneReminderChec) {
   case App_Model_IN_Off_h:
    if (App_Model_DW.sfEvent_h == event_Start_Timer_PhoneRemind_o) {
      App_Model_DW.is_Tick_Timer_PhoneReminderChec = App_Model_IN_On_b;
    }
    break;

   case App_Model_IN_On_b:
    {
      if (App_Model_DW.sfEvent_h == event_Cancel_Timer_PhoneRemin_k) {
        App_Model_DW.is_Tick_Timer_PhoneReminderChec = App_Model_IN_Off_h;
        App_Model_DW.Timer_PhoneReminderCheck = 0U;
        *rty_MainOut_Sig_j = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_PhoneReminderCheck + 1;
        if (App_Model_DW.Timer_PhoneReminderCheck + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_PhoneReminderCheck = (uint16)tmp;
        *rty_MainOut_Sig_j = App_Model_DW.Timer_PhoneReminderCheck;
        if (App_Model_DW.sfEvent_h == event_Start_Timer_PhoneRemind_o) {
          App_Model_DW.Timer_PhoneReminderCheck = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void Ap_Tick_Timer_WarningComplete_i(uint16 *rty_MainOut_Sig_nt)
{
  switch (App_Model_DW.is_Tick_Timer_WarningComplete) {
   case App_Model_IN_Off_h:
    if (App_Model_DW.sfEvent_h == event_Start_Timer_WarningComp_j) {
      App_Model_DW.is_Tick_Timer_WarningComplete = App_Model_IN_On_b;
    }
    break;

   case App_Model_IN_On_b:
    {
      if (App_Model_DW.sfEvent_h == event_Cancel_Timer_WarningCom_m) {
        App_Model_DW.is_Tick_Timer_WarningComplete = App_Model_IN_Off_h;
        App_Model_DW.Timer_WarningComplete = 0U;
        *rty_MainOut_Sig_nt = 0U;
      } else {
        sint32 tmp;
        tmp = App_Model_DW.Timer_WarningComplete + 1;
        if (App_Model_DW.Timer_WarningComplete + 1 > 65535) {
          tmp = 65535;
        }

        App_Model_DW.Timer_WarningComplete = (uint16)tmp;
        *rty_MainOut_Sig_nt = App_Model_DW.Timer_WarningComplete;
        if (App_Model_DW.sfEvent_h == event_Start_Timer_WarningComp_j) {
          App_Model_DW.Timer_WarningComplete = 0U;
        }
      }
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_Model_Function_WPCWarning_e(C_WPCOnOffNvalueSet rtu_Main_InSig_e, Bool rtu_Main_InSig_gc, Bool rtu_Main_InSig_j, Bool rtu_Main_InSig_n, C_WPCWarning *rty_MainOut_Sig, uint16
  *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt, Bool *rty_MainOut_Sig_k)
{
  /* 1 */
  if ((rtu_Main_InSig_e == WPC_Off) || ((App_Model_DW.Timer_PhoneWarningCheck >= Par_PhoneCheckTime) && (rtu_Main_InSig_n == Off)) || (App_Model_DW.Timer_PhoneLeft >= 50)) {
    sint32 c_previousEvent;
    *rty_MainOut_Sig = WPCWarningOff;

    /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
    App_Model_DW.b_WarnClearEnable = Off;
    *rty_MainOut_Sig_k = Off;
    c_previousEvent = App_Model_DW.sfEvent_h;
    App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneLeft_c;
    if (App_Model_DW.is_active_Tick_Timer_PhoneLeft != 0U) {
      App_Mode_Tick_Timer_PhoneLeft_o();
    }

    App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneWarni_c;
    if (App_Model_DW.is_active_Tick_Timer_PhoneWarni != 0U) {
      Tick_Timer_PhoneWarningCheck_e(rty_MainOut_Sig_n);
    }

    App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneRemin_k;
    if (App_Model_DW.is_active_Tick_Timer_PhoneRemin != 0U) {
      Tick_Timer_PhoneReminderCheck_h(rty_MainOut_Sig_j);
    }

    App_Model_DW.sfEvent_h = event_Cancel_Timer_WarningCom_m;
    if (App_Model_DW.is_active_Tick_Timer_WarningCom != 0U) {
      Ap_Tick_Timer_WarningComplete_i(rty_MainOut_Sig_nt);
    }

    App_Model_DW.sfEvent_h = c_previousEvent;
  } else {
    sint32 c_previousEvent;

    /* 1. */
    if ((App_Model_DW.b_WarnClearEnable == On) && ((App_Model_DW.b_WPCPhoneExist_prev != App_Model_DW.b_WPCPhoneExist_start) && (App_Model_DW.b_WPCPhoneExist_start == Off))) {
      c_previousEvent = App_Model_DW.sfEvent_h;
      App_Model_DW.sfEvent_h = A_event_Start_Timer_PhoneLeft_b;
      if (App_Model_DW.is_active_Tick_Timer_PhoneLeft != 0U) {
        App_Mode_Tick_Timer_PhoneLeft_o();
      }

      App_Model_DW.sfEvent_h = c_previousEvent;

      /* 1. */
    } else if ((App_Model_DW.is_Tick_Timer_PhoneLeft == App_Model_IN_On_b) && (rtu_Main_InSig_n == On)) {
      c_previousEvent = App_Model_DW.sfEvent_h;
      App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneLeft_c;
      if (App_Model_DW.is_active_Tick_Timer_PhoneLeft != 0U) {
        App_Mode_Tick_Timer_PhoneLeft_o();
      }

      App_Model_DW.sfEvent_h = c_previousEvent;
    }

    /* 1. */
    if ((App_Model_DW.Timer_PhoneWarningCheck >= 10) && (App_Model_DW.Timer_PhoneWarningCheck <= Par_PhoneCheckTime) && (rtu_Main_InSig_n == On)) {
      *rty_MainOut_Sig = Cellphoneonthepad;

      /* b_WPCWarn = Cellphoneonthepad 8�� LFRollBack */
      App_Model_DW.b_WarnClearEnable = On;
      c_previousEvent = App_Model_DW.sfEvent_h;
      App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneWarni_c;
      if (App_Model_DW.is_active_Tick_Timer_PhoneWarni != 0U) {
        Tick_Timer_PhoneWarningCheck_e(rty_MainOut_Sig_n);
      }

      App_Model_DW.sfEvent_h = event_Start_Timer_PhoneRemind_o;
      if (App_Model_DW.is_active_Tick_Timer_PhoneRemin != 0U) {
        Tick_Timer_PhoneReminderCheck_h(rty_MainOut_Sig_j);
      }

      App_Model_DW.sfEvent_h = c_previousEvent;

      /* 5�� ���� */

      /* 1. */
    } else if ((App_Model_DW.Timer_PhoneReminderCheck >= 6000) && (App_Model_DW.b_WarnClearEnable == On) && (rtu_Main_InSig_n == On)) {
      /* 1. */
      if ((rtu_Main_InSig_j == On) || (rtu_Main_InSig_gc == On)) {
        App_Model_DW.b_WarnClearEnable = Off;
        *rty_MainOut_Sig = WPCWarningOff;
        *rty_MainOut_Sig_k = Off;

        /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
        c_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneRemin_k;
        if (App_Model_DW.is_active_Tick_Timer_PhoneRemin != 0U) {
          Tick_Timer_PhoneReminderCheck_h(rty_MainOut_Sig_j);
        }

        App_Model_DW.sfEvent_h = c_previousEvent;
      } else {
        /* 2. */
        *rty_MainOut_Sig = Cellphonereminder;

        /* b_WPCWarn = Cellphonereminder 8�� LFRollBack */
        c_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneRemin_k;
        if (App_Model_DW.is_active_Tick_Timer_PhoneRemin != 0U) {
          Tick_Timer_PhoneReminderCheck_h(rty_MainOut_Sig_j);
        }

        App_Model_DW.sfEvent_h = event_Start_Timer_WarningComp_j;
        if (App_Model_DW.is_active_Tick_Timer_WarningCom != 0U) {
          Ap_Tick_Timer_WarningComplete_i(rty_MainOut_Sig_nt);
        }

        App_Model_DW.sfEvent_h = c_previousEvent;
      }

      /* 1. */
    } else if ((App_Model_DW.Timer_WarningComplete >= 50) && (App_Model_DW.b_WarnClearEnable == On) && (rtu_Main_InSig_n == On)) {
      *rty_MainOut_Sig = WPCWarningOff;

      /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
      App_Model_DW.b_WarnClearEnable = Off;
      *rty_MainOut_Sig_k = Off;
      c_previousEvent = App_Model_DW.sfEvent_h;
      App_Model_DW.sfEvent_h = event_Cancel_Timer_WarningCom_m;
      if (App_Model_DW.is_active_Tick_Timer_WarningCom != 0U) {
        Ap_Tick_Timer_WarningComplete_i(rty_MainOut_Sig_nt);
      }

      App_Model_DW.sfEvent_h = c_previousEvent;
    }
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App__enter_atomic_WPCMode_NFC_g(uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt)
{
  sint32 b_previousEvent;
  App_Model_DW.b_WarnClearEnable = Off;
  b_previousEvent = App_Model_DW.sfEvent_h;
  App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneLeft_c;
  if (App_Model_DW.is_active_Tick_Timer_PhoneLeft != 0U) {
    App_Mode_Tick_Timer_PhoneLeft_o();
  }

  App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneWarni_c;
  if (App_Model_DW.is_active_Tick_Timer_PhoneWarni != 0U) {
    Tick_Timer_PhoneWarningCheck_e(rty_MainOut_Sig_n);
  }

  App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneRemin_k;
  if (App_Model_DW.is_active_Tick_Timer_PhoneRemin != 0U) {
    Tick_Timer_PhoneReminderCheck_h(rty_MainOut_Sig_j);
  }

  App_Model_DW.sfEvent_h = event_Cancel_Timer_WarningCom_m;
  if (App_Model_DW.is_active_Tick_Timer_WarningCom != 0U) {
    Ap_Tick_Timer_WarningComplete_i(rty_MainOut_Sig_nt);
  }

  App_Model_DW.sfEvent_h = b_previousEvent;
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void enter_internal_WPCMode_Disabl_k(C_WPCOnOffNvalueSet rtu_Main_InSig_e, Bool rtu_Main_InSig_gc, Bool rtu_Main_InSig_j, Bool rtu_Main_InSig_n, WPCStatus rtu_Main_InSig_p, C_WPCWarning
  *rty_MainOut_Sig, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt, Bool *rty_MainOut_Sig_k)
{
  /* 1. */
  if ((rtu_Main_InSig_p == NFCMode) || (rtu_Main_InSig_p == LPCDMode) || (rtu_Main_InSig_p == PICCMode)) {
    App_Model_DW.is_WPCMode_Disable = App_Model_IN_WPCMode_NFC_i;
    App__enter_atomic_WPCMode_NFC_g(rty_MainOut_Sig_j, rty_MainOut_Sig_n, rty_MainOut_Sig_nt);
  } else {
    App_Model_DW.is_WPCMode_Disable = App_Model_IN_WPCMode_Off_o;
    if ((App_Model_DW.L_IGN1_IN_prev != App_Model_DW.L_IGN1_IN_start) && (App_Model_DW.L_IGN1_IN_start == Off)) {
      sint32 b_previousEvent;
      App_Model_DW.is_WPCMode_Off = App_M_IN_LeavingPhone_Warning_a;
      App_Model_DW.b_WarnClearEnable = Off;
      b_previousEvent = App_Model_DW.sfEvent_h;
      App_Model_DW.sfEvent_h = event_Start_Timer_PhoneWarnin_a;
      if (App_Model_DW.is_active_Tick_Timer_PhoneWarni != 0U) {
        Tick_Timer_PhoneWarningCheck_e(rty_MainOut_Sig_n);
      }

      App_Model_DW.sfEvent_h = b_previousEvent;
      App_Model_Function_WPCWarning_e(rtu_Main_InSig_e, rtu_Main_InSig_gc, rtu_Main_InSig_j, rtu_Main_InSig_n, rty_MainOut_Sig, rty_MainOut_Sig_j, rty_MainOut_Sig_n, rty_MainOut_Sig_nt,
        rty_MainOut_Sig_k);
      *rty_MainOut_Sig_k = On;
    } else {
      App_Model_DW.is_WPCMode_Off = App_IN_LeavingPhone_NoWarning_i;
    }
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void App_Model_MainControl_g(Bool rtu_Main_InSig, Bool rtu_Main_InSig_g, Bool rtu_Main_InSig_b, C_WPCOnOffNvalueSet rtu_Main_InSig_e, Bool rtu_Main_InSig_gc, Bool rtu_Main_InSig_j, Bool
  rtu_Main_InSig_n, DeviceState rtu_Main_InSig_nt, WPCStatus rtu_Main_InSig_p, WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_nw, Bool rtu_Main_InSig_n4, C_WPCWarning *rty_MainOut_Sig, Bool
  *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, uint16 *rty_MainOut_Sig_j, uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt, Bool
  *rty_MainOut_Sig_p, BlinkState *rty_MainOut_Sig_po, Bool *rty_MainOut_Sig_k)
{
  switch (App_Model_DW.is_MainControl) {
   case App_Model_IN_WPCMode_Disable_p:
    {
      /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
      *rty_MainOut_Sig_g = Off;

      /* 1. */
      if (rtu_Main_InSig_p == WPCMode) {
        sint32 b_previousEvent;
        if (App_Model_DW.is_WPCMode_Disable == App_Model_IN_WPCMode_Off_o) {
          if (App_Model_DW.is_WPCMode_Off == App_M_IN_LeavingPhone_Warning_a) {
            /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
            *rty_MainOut_Sig = WPCWarningOff;
            *rty_MainOut_Sig_k = Off;
            App_Model_DW.is_WPCMode_Off = App_Model_IN_NO_ACTIVE_CHILD_kn;
          } else {
            App_Model_DW.is_WPCMode_Off = App_Model_IN_NO_ACTIVE_CHILD_kn;
          }

          App_Model_DW.is_WPCMode_Disable = App_Model_IN_NO_ACTIVE_CHILD_kn;
        } else {
          App_Model_DW.is_WPCMode_Disable = App_Model_IN_NO_ACTIVE_CHILD_kn;
        }

        App_Model_DW.b_WarnClearEnable = Off;
        b_previousEvent = App_Model_DW.sfEvent_h;
        App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneLeft_c;
        if (App_Model_DW.is_active_Tick_Timer_PhoneLeft != 0U) {
          App_Mode_Tick_Timer_PhoneLeft_o();
        }

        App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneWarni_c;
        if (App_Model_DW.is_active_Tick_Timer_PhoneWarni != 0U) {
          /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
          Tick_Timer_PhoneWarningCheck_e(rty_MainOut_Sig_n);
        }

        App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneRemin_k;
        if (App_Model_DW.is_active_Tick_Timer_PhoneRemin != 0U) {
          /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
          Tick_Timer_PhoneReminderCheck_h(rty_MainOut_Sig_j);
        }

        App_Model_DW.sfEvent_h = event_Cancel_Timer_WarningCom_m;
        if (App_Model_DW.is_active_Tick_Timer_WarningCom != 0U) {
          /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
          Ap_Tick_Timer_WarningComplete_i(rty_MainOut_Sig_nt);
        }

        App_Model_DW.sfEvent_h = b_previousEvent;
        App_Model_DW.is_MainControl = App_Model_IN_WPCMode_Enable_b;
        App_Model_DW.is_WPCMode_Enable = App_Model_IN_WPCMode_Stop_m;

        /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
        *rty_MainOut_Sig_g = Off;
        *rty_MainOut_Sig_b = Off;

        /* b_ChargingEnable = Off */
        A_enter_internal_WPCMode_Stop_d(rtu_Main_InSig_b, rtu_Main_InSig_k, rtu_Main_InSig_nw, rtu_Main_InSig_n4, rty_MainOut_Sig, rty_MainOut_Sig_b, rty_MainOut_Sig_e, rty_MainOut_Sig_gc,
          rty_MainOut_Sig_p, rty_MainOut_Sig_po);
      } else {
        switch (App_Model_DW.is_WPCMode_Disable) {
         case App_Model_IN_WPCMode_NFC_i:
          /* 1. */
          if (rtu_Main_InSig_p == ModeOff) {
            App_Model_DW.is_WPCMode_Disable = App_Model_IN_WPCMode_Off_o;
            App_Model_DW.is_WPCMode_Off = App_IN_LeavingPhone_NoWarning_i;
          }
          break;

         case App_Model_IN_WPCMode_Off_o:
          /* 1. */
          if ((rtu_Main_InSig_p == NFCMode) || (rtu_Main_InSig_p == LPCDMode) || (rtu_Main_InSig_p == PICCMode)) {
            if (App_Model_DW.is_WPCMode_Off == App_M_IN_LeavingPhone_Warning_a) {
              /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
              *rty_MainOut_Sig = WPCWarningOff;
              *rty_MainOut_Sig_k = Off;
              App_Model_DW.is_WPCMode_Off = App_Model_IN_NO_ACTIVE_CHILD_kn;
            } else {
              App_Model_DW.is_WPCMode_Off = App_Model_IN_NO_ACTIVE_CHILD_kn;
            }

            App_Model_DW.is_WPCMode_Disable = App_Model_IN_WPCMode_NFC_i;

            /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
            App__enter_atomic_WPCMode_NFC_g(rty_MainOut_Sig_j, rty_MainOut_Sig_n, rty_MainOut_Sig_nt);
          } else if (App_Model_DW.is_WPCMode_Off == App_M_IN_LeavingPhone_Warning_a) {
            /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
            App_Model_Function_WPCWarning_e(rtu_Main_InSig_e, rtu_Main_InSig_gc, rtu_Main_InSig_j, rtu_Main_InSig_n, rty_MainOut_Sig, rty_MainOut_Sig_j, rty_MainOut_Sig_n, rty_MainOut_Sig_nt,
              rty_MainOut_Sig_k);
          }
          break;
        }
      }
    }
    break;

   case App_Model_IN_WPCMode_Enable_b:
    {
      /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
      /* 1. */
      if (rtu_Main_InSig_p != WPCMode) {
        switch (App_Model_DW.is_WPCMode_Enable) {
         case App_Model_IN_WPCMode_Run_h:
          App_exit_internal_WPCMode_Run_c(rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
          App_Model_DW.is_WPCMode_Enable = App_Model_IN_NO_ACTIVE_CHILD_kn;
          break;

         case App_Model_IN_WPCMode_Stop_m:
          Ap_exit_internal_WPCMode_Stop_e(rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
          App_Model_DW.is_WPCMode_Enable = App_Model_IN_NO_ACTIVE_CHILD_kn;
          break;
        }

        *rty_MainOut_Sig_p = Off;
        App_Model_DW.is_MainControl = App_Model_IN_WPCMode_Disable_p;
        enter_atomic_WPCMode_Disable_p(rty_MainOut_Sig, rty_MainOut_Sig_g, rty_MainOut_Sig_b, rty_MainOut_Sig_e, rty_MainOut_Sig_po, rty_MainOut_Sig_k);
        enter_internal_WPCMode_Disabl_k(rtu_Main_InSig_e, rtu_Main_InSig_gc, rtu_Main_InSig_j, rtu_Main_InSig_n, rtu_Main_InSig_p, rty_MainOut_Sig, rty_MainOut_Sig_j, rty_MainOut_Sig_n,
          rty_MainOut_Sig_nt, rty_MainOut_Sig_k);
      } else {
        switch (App_Model_DW.is_WPCMode_Enable) {
         case App_Model_IN_WPCMode_Run_h:
          App_Model_WPCMode_Run_h(rtu_Main_InSig, rtu_Main_InSig_g, rtu_Main_InSig_b, rtu_Main_InSig_nt, rtu_Main_InSig_k, rtu_Main_InSig_nw, rtu_Main_InSig_n4, rty_MainOut_Sig, rty_MainOut_Sig_g,
            rty_MainOut_Sig_b, rty_MainOut_Sig_e, rty_MainOut_Sig_gc, rty_MainOut_Sig_p, rty_MainOut_Sig_po);
          break;

         case App_Model_IN_WPCMode_Stop_m:
          {
            *rty_MainOut_Sig_g = Off;
            if ((rtu_Main_InSig_nt == Full_Charge) && (rtu_Main_InSig == Off) && (rtu_Main_InSig_g == Off) && (rtu_Main_InSig_b == Off) && (rtu_Main_InSig_b == Off) && (rtu_Main_InSig_n4 == Off)) {
              /* CardDetect_240207] */
              Ap_exit_internal_WPCMode_Stop_e(rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
              App_Model_DW.is_WPCMode_Enable = App_Model_IN_WPCMode_Run_h;
              *rty_MainOut_Sig_p = On;

              /* b_ROHMOperCmd = On /_ Non GFS _/ */
              App_Model_DW.is_WPCMode_Run = Ap_IN_WPCRun_ChargingComplete_a;
              *rty_MainOut_Sig = Charging_Complete;

              /* b_WPCWarn = Charging_Complete 8�� LFRollBack */
              *rty_MainOut_Sig_g = On;
              *rty_MainOut_Sig_b = On;
              *rty_MainOut_Sig_e = Off;
            } else if ((rtu_Main_InSig_nt == Charging) && (rtu_Main_InSig == Off) && (rtu_Main_InSig_g == Off) && (rtu_Main_InSig_b == Off) && (rtu_Main_InSig_b == Off) && (rtu_Main_InSig_n4 == Off))
            {
              /* CardDetect_240207] */
              Ap_exit_internal_WPCMode_Stop_e(rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
              App_Model_DW.is_WPCMode_Enable = App_Model_IN_WPCMode_Run_h;
              *rty_MainOut_Sig_p = On;

              /* b_ROHMOperCmd = On /_ Non GFS _/ */
              App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_Charging_f;
              *rty_MainOut_Sig = PhoneCharging;

              /* b_WPCWarn = PhoneCharging 8�� LFRollBack */
              *rty_MainOut_Sig_g = On;
              App_Function_ChargingINDColor_e(rtu_Main_InSig_k, rtu_Main_InSig_n4, rty_MainOut_Sig_b, rty_MainOut_Sig_e);
            } else {
              switch (App_Model_DW.is_WPCMode_Stop) {
               case App_Model_IN_CardDetectError_f:
                {
                  if (rtu_Main_InSig_n4 == Off) {
                    sint32 b_previousEvent;

                    /* CardDetect_240207] */
                    *rty_MainOut_Sig_po = BlinkOff;
                    App_Model_DW.Counter_BlinkCnt = 0U;
                    b_previousEvent = App_Model_DW.sfEvent_h;
                    App_Model_DW.sfEvent_h = event_Cancel_Timer_GreenINDBl_l;
                    if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
                      App_Mo_Tick_Timer_AmberINDBlk_j();
                    }

                    App_Model_DW.sfEvent_h = b_previousEvent;
                    *rty_MainOut_Sig_gc = Off;
                    App_Model_DW.is_WPCMode_Stop = App_Model_IN_NO_ACTIVE_CHILD_kn;
                    App_Model_DW.is_WPCMode_Enable = App_Model_IN_WPCMode_Run_h;
                    *rty_MainOut_Sig_p = On;

                    /* b_ROHMOperCmd = On /_ Non GFS _/ */
                    App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_Standby_a;
                    *rty_MainOut_Sig = WPCWarningOff;

                    /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
                    *rty_MainOut_Sig_g = Off;
                    *rty_MainOut_Sig_b = Off;
                    *rty_MainOut_Sig_e = Off;
                  } else {
                    Ap_Function_CardLEDErrorBlink_e(rtu_Main_InSig_nw, rty_MainOut_Sig_b, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
                  }
                }
                break;

               case App_Mod_IN_WPCStop_NotTempErr_f:
                /* 1. */
                if (rtu_Main_InSig_b == On) {
                  App_Model_DW.is_WPCMode_Stop = App_Model_IN_WPCStop_TempErr_c;

                  /* 240926 */
                  *rty_MainOut_Sig_p = Off;
                  *rty_MainOut_Sig = Charging_error;
                  *rty_MainOut_Sig_po = BlinkOff;
                  App_Model_DW.Counter_BlinkCnt = 0U;
                  App_Mo_Function_LEDErrorBlink_k(rtu_Main_InSig_k, rtu_Main_InSig_nw, rty_MainOut_Sig_e, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);

                  /*  Non GFS  */
                  *rty_MainOut_Sig_gc = On;

                  /* 2. */
                } else if ((rtu_Main_InSig == Off) && (rtu_Main_InSig_g == Off) && (rtu_Main_InSig_b == Off)) {
                  /* b_ChargingEnable == On 8�� ���� ���� */
                  App_Model_DW.is_WPCMode_Stop = App_Model_IN_NO_ACTIVE_CHILD_kn;
                  App_Model_DW.is_WPCMode_Enable = App_Model_IN_WPCMode_Run_h;
                  *rty_MainOut_Sig_p = On;

                  /* b_ROHMOperCmd = On /_ Non GFS _/ */
                  App_Model_DW.is_WPCMode_Run = App_Model_IN_WPCRun_Standby_a;
                  *rty_MainOut_Sig = WPCWarningOff;

                  /* b_WPCWarn = WPCWarningOff 8�� LFRollBack */
                  *rty_MainOut_Sig_g = Off;
                  *rty_MainOut_Sig_b = Off;
                  *rty_MainOut_Sig_e = Off;
                } else if (rtu_Main_InSig_n4 == On) {
                  /* CardDetect_240207] */
                  App_Model_DW.is_WPCMode_Stop = App_Model_IN_CardDetectError_f;
                  *rty_MainOut_Sig = NFCCardDetected;
                  *rty_MainOut_Sig_po = BlinkOff;
                  App_Model_DW.Counter_BlinkCnt = 0U;
                  *rty_MainOut_Sig_e = Off;
                  Ap_Function_CardLEDErrorBlink_e(rtu_Main_InSig_nw, rty_MainOut_Sig_b, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
                  *rty_MainOut_Sig_gc = On;
                }
                break;

               case App_Model_IN_WPCStop_TempErr_c:
                {
                  /* 1. */
                  if (rtu_Main_InSig_b == Off) {
                    sint32 b_previousEvent;
                    *rty_MainOut_Sig_po = BlinkOff;
                    App_Model_DW.Counter_BlinkCnt = 0U;
                    b_previousEvent = App_Model_DW.sfEvent_h;
                    App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
                    if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
                      App_Mo_Tick_Timer_AmberINDBlk_j();
                    }

                    App_Model_DW.sfEvent_h = b_previousEvent;

                    /*  Non GFS  */
                    *rty_MainOut_Sig_gc = Off;
                    App_Model_DW.is_WPCMode_Stop = App_Mod_IN_WPCStop_NotTempErr_f;

                    /* 240926 */
                    *rty_MainOut_Sig_p = Off;
                    *rty_MainOut_Sig = WPCWarningOff;
                    *rty_MainOut_Sig_e = Off;
                  } else {
                    App_Mo_Function_LEDErrorBlink_k(rtu_Main_InSig_k, rtu_Main_InSig_nw, rty_MainOut_Sig_e, rty_MainOut_Sig_gc, rty_MainOut_Sig_po);
                  }
                }
                break;
              }
            }
          }
          break;
        }
      }
    }
    break;

   case App_Model_IN_WPCMode_Init_o:
    /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
    *rty_MainOut_Sig_g = Off;

    /* 1. */
    if (rtu_Main_InSig_p != WPCMode) {
      App_Model_DW.is_MainControl = App_Model_IN_WPCMode_Disable_p;

      /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
      enter_atomic_WPCMode_Disable_p(rty_MainOut_Sig, rty_MainOut_Sig_g, rty_MainOut_Sig_b, rty_MainOut_Sig_e, rty_MainOut_Sig_po, rty_MainOut_Sig_k);
      enter_internal_WPCMode_Disabl_k(rtu_Main_InSig_e, rtu_Main_InSig_gc, rtu_Main_InSig_j, rtu_Main_InSig_n, rtu_Main_InSig_p, rty_MainOut_Sig, rty_MainOut_Sig_j, rty_MainOut_Sig_n,
        rty_MainOut_Sig_nt, rty_MainOut_Sig_k);

      /* 2 */
    } else if (rtu_Main_InSig_p == WPCMode) {
      App_Model_DW.is_MainControl = App_Model_IN_WPCMode_Enable_b;
      App_Model_DW.is_WPCMode_Enable = App_Model_IN_WPCMode_Stop_m;

      /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
      *rty_MainOut_Sig_g = Off;
      *rty_MainOut_Sig_b = Off;

      /* b_ChargingEnable = Off */
      A_enter_internal_WPCMode_Stop_d(rtu_Main_InSig_b, rtu_Main_InSig_k, rtu_Main_InSig_nw, rtu_Main_InSig_n4, rty_MainOut_Sig, rty_MainOut_Sig_b, rty_MainOut_Sig_e, rty_MainOut_Sig_gc,
        rty_MainOut_Sig_p, rty_MainOut_Sig_po);
    }
    break;
  }
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Pho_b(void)
{
  App_Model_DW.is_Tick_Timer_PhoneLeft = App_Model_IN_Off_h;
  App_Model_DW.Timer_PhoneLeft = 0U;
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Ph_bo(uint16 *rty_MainOut_Sig_n)
{
  App_Model_DW.is_Tick_Timer_PhoneWarningCheck = App_Model_IN_Off_h;
  App_Model_DW.Timer_PhoneWarningCheck = 0U;

  /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
  *rty_MainOut_Sig_n = 0U;
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Pho_n(uint16 *rty_MainOut_Sig_j)
{
  App_Model_DW.is_Tick_Timer_PhoneReminderChec = App_Model_IN_Off_h;
  App_Model_DW.Timer_PhoneReminderCheck = 0U;

  /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
  *rty_MainOut_Sig_j = 0U;
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_War_f(uint16 *rty_MainOut_Sig_nt)
{
  App_Model_DW.is_Tick_Timer_WarningComplete = App_Model_IN_Off_h;
  App_Model_DW.Timer_WarningComplete = 0U;

  /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
  *rty_MainOut_Sig_nt = 0U;
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Amb_n(void)
{
  App_Model_DW.is_Tick_Timer_AmberINDBlk = App_Model_IN_Off_h;
  App_Model_DW.Timer_AmberINDBlk = 0U;
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Amb_h(void)
{
  App_Model_DW.is_Tick_Timer_AmberINDBlk2 = App_Model_IN_Off_h;
  App_Model_DW.Timer_AmberINDBlk2 = 0U;
}

/* Function for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
static void enter_internal_Tick_Timer_Gre_o(void)
{
  App_Model_DW.is_Tick_Timer_GreenINDBlk = App_Model_IN_Off_h;
  App_Model_DW.Timer_GreenINDBlk = 0U;
}

/* System initialize for atomic system: '<S14>/WPC_MainControl_Function' */
void WPC_MainControl_Function_g_Init(C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, uint16 *rty_MainOut_Sig_j,
  uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt, Bool *rty_MainOut_Sig_p, BlinkState *rty_MainOut_Sig_po, Bool *rty_MainOut_Sig_k)
{
  /* SystemInitialize for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
  App_Model_DW.sfEvent_h = App_Model_CALL_EVENT_ac;
  *rty_MainOut_Sig = WPCWarningOff;
  *rty_MainOut_Sig_g = Off;
  *rty_MainOut_Sig_b = Off;
  *rty_MainOut_Sig_e = Off;
  *rty_MainOut_Sig_gc = Off;
  *rty_MainOut_Sig_j = 0U;
  *rty_MainOut_Sig_n = 0U;
  *rty_MainOut_Sig_nt = 0U;
  *rty_MainOut_Sig_p = Off;
  *rty_MainOut_Sig_po = BlinkOff;
  *rty_MainOut_Sig_k = Off;
}

/* System reset for atomic system: '<S14>/WPC_MainControl_Function' */
void WPC_MainControl_Functio_f_Reset(C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, uint16 *rty_MainOut_Sig_j,
  uint16 *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt, Bool *rty_MainOut_Sig_p, BlinkState *rty_MainOut_Sig_po, Bool *rty_MainOut_Sig_k)
{
  /* SystemReset for Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
  App_Model_DW.sfEvent_h = App_Model_CALL_EVENT_ac;
  App_Model_DW.is_active_MainControl = 0U;
  App_Model_DW.is_MainControl = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_WPCMode_Disable = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_WPCMode_Off = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_WPCMode_Enable = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_WPCMode_Run = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_WPCMode_Stop = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_active_Tick_Timer_AmberINDBl = 0U;
  App_Model_DW.is_Tick_Timer_AmberINDBlk = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_active_Tick_Timer_AmberIND_l = 0U;
  App_Model_DW.is_Tick_Timer_AmberINDBlk2 = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_active_Tick_Timer_GreenINDBl = 0U;
  App_Model_DW.is_Tick_Timer_GreenINDBlk = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_active_Tick_Timer_PhoneLeft = 0U;
  App_Model_DW.is_Tick_Timer_PhoneLeft = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_active_Tick_Timer_PhoneRemin = 0U;
  App_Model_DW.is_Tick_Timer_PhoneReminderChec = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_active_Tick_Timer_PhoneWarni = 0U;
  App_Model_DW.is_Tick_Timer_PhoneWarningCheck = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_active_Tick_Timer_WarningCom = 0U;
  App_Model_DW.is_Tick_Timer_WarningComplete = App_Model_IN_NO_ACTIVE_CHILD_kn;
  App_Model_DW.is_active_c50_MainControl_Lib = 0U;
  App_Model_DW.b_WarnClearEnable = Off;
  App_Model_DW.Timer_AmberINDBlk = 0U;
  App_Model_DW.Timer_PhoneLeft = 0U;
  App_Model_DW.Timer_PhoneReminderCheck = 0U;
  App_Model_DW.Timer_PhoneWarningCheck = 0U;
  App_Model_DW.Timer_WarningComplete = 0U;
  App_Model_DW.Counter_BlinkCnt = 0U;
  App_Model_DW.Timer_AmberINDBlk2 = 0U;
  App_Model_DW.Timer_GreenINDBlk = 0U;
  *rty_MainOut_Sig = WPCWarningOff;
  *rty_MainOut_Sig_g = Off;
  *rty_MainOut_Sig_b = Off;
  *rty_MainOut_Sig_e = Off;
  *rty_MainOut_Sig_gc = Off;
  *rty_MainOut_Sig_j = 0U;
  *rty_MainOut_Sig_n = 0U;
  *rty_MainOut_Sig_nt = 0U;
  *rty_MainOut_Sig_p = Off;
  *rty_MainOut_Sig_po = BlinkOff;
  *rty_MainOut_Sig_k = Off;
  App_Model_DW.b_WPCPhoneExist_prev = Off;
  App_Model_DW.b_WPCPhoneExist_start = Off;
  App_Model_DW.WPC2IndCmdState_prev = WPC2IndCmdState__Default;
  App_Model_DW.WPC2IndCmdState_start = WPC2IndCmdState__Default;
  App_Model_DW.L_IGN1_IN_prev = Off;
  App_Model_DW.L_IGN1_IN_start = Off;
}

/* Output and update for atomic system: '<S14>/WPC_MainControl_Function' */
void App__WPC_MainControl_Function_e(Bool rtu_Main_InSig, Bool rtu_Main_InSig_g, Bool rtu_Main_InSig_b, C_WPCOnOffNvalueSet rtu_Main_InSig_e, Bool rtu_Main_InSig_gc, Bool rtu_Main_InSig_j, Bool
  rtu_Main_InSig_n, DeviceState rtu_Main_InSig_nt, WPCStatus rtu_Main_InSig_p, Bool rtu_Main_InSig_po, WPCIndUSMState rtu_Main_InSig_k, Bool rtu_Main_InSig_nw, WPC2IndCmdState rtu_Main_InSig_h, Bool
  rtu_Main_InSig_n4, C_WPCWarning *rty_MainOut_Sig, Bool *rty_MainOut_Sig_g, Bool *rty_MainOut_Sig_b, Bool *rty_MainOut_Sig_e, Bool *rty_MainOut_Sig_gc, uint16 *rty_MainOut_Sig_j, uint16
  *rty_MainOut_Sig_n, uint16 *rty_MainOut_Sig_nt, Bool *rty_MainOut_Sig_p, BlinkState *rty_MainOut_Sig_po, Bool *rty_MainOut_Sig_k)
{
  /* Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
  App_Model_DW.sfEvent_h = App_Model_CALL_EVENT_ac;
  App_Model_DW.b_WPCPhoneExist_prev = App_Model_DW.b_WPCPhoneExist_start;
  App_Model_DW.b_WPCPhoneExist_start = rtu_Main_InSig_n;
  App_Model_DW.WPC2IndCmdState_prev = App_Model_DW.WPC2IndCmdState_start;
  App_Model_DW.WPC2IndCmdState_start = rtu_Main_InSig_h;
  App_Model_DW.L_IGN1_IN_prev = App_Model_DW.L_IGN1_IN_start;
  App_Model_DW.L_IGN1_IN_start = rtu_Main_InSig_po;
  if (App_Model_DW.is_active_c50_MainControl_Lib == 0U) {
    App_Model_DW.b_WPCPhoneExist_prev = rtu_Main_InSig_n;
    App_Model_DW.WPC2IndCmdState_prev = rtu_Main_InSig_h;
    App_Model_DW.L_IGN1_IN_prev = rtu_Main_InSig_po;
    App_Model_DW.is_active_c50_MainControl_Lib = 1U;
    App_Model_DW.is_active_MainControl = 1U;
    App_Model_DW.is_MainControl = App_Model_IN_WPCMode_Init_o;
    *rty_MainOut_Sig = WPCWarningOff;
    *rty_MainOut_Sig_po = BlinkOff;
    App_Model_DW.Counter_BlinkCnt = 0U;
    App_Model_DW.b_WarnClearEnable = Off;
    *rty_MainOut_Sig_g = Off;
    *rty_MainOut_Sig_b = Off;
    *rty_MainOut_Sig_e = Off;
    *rty_MainOut_Sig_p = Off;
    *rty_MainOut_Sig_k = Off;
    App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneLeft_c;
    if (App_Model_DW.is_active_Tick_Timer_PhoneLeft != 0U) {
      App_Mode_Tick_Timer_PhoneLeft_o();
    }

    App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneWarni_c;
    if (App_Model_DW.is_active_Tick_Timer_PhoneWarni != 0U) {
      Tick_Timer_PhoneWarningCheck_e(rty_MainOut_Sig_n);
    }

    App_Model_DW.sfEvent_h = event_Cancel_Timer_PhoneRemin_k;
    if (App_Model_DW.is_active_Tick_Timer_PhoneRemin != 0U) {
      Tick_Timer_PhoneReminderCheck_h(rty_MainOut_Sig_j);
    }

    App_Model_DW.sfEvent_h = event_Cancel_Timer_WarningCom_m;
    if (App_Model_DW.is_active_Tick_Timer_WarningCom != 0U) {
      Ap_Tick_Timer_WarningComplete_i(rty_MainOut_Sig_nt);
    }

    App_Model_DW.sfEvent_h = event_Cancel_Timer_AmberINDBl_g;
    if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
      App_Mo_Tick_Timer_AmberINDBlk_j();
    }

    App_Model_DW.sfEvent_h = -1;
    App_Model_DW.is_active_Tick_Timer_PhoneLeft = 1U;
    enter_internal_Tick_Timer_Pho_b();
    App_Model_DW.is_active_Tick_Timer_PhoneWarni = 1U;
    enter_internal_Tick_Timer_Ph_bo(rty_MainOut_Sig_n);
    App_Model_DW.is_active_Tick_Timer_PhoneRemin = 1U;
    enter_internal_Tick_Timer_Pho_n(rty_MainOut_Sig_j);
    App_Model_DW.is_active_Tick_Timer_WarningCom = 1U;
    enter_internal_Tick_Timer_War_f(rty_MainOut_Sig_nt);
    App_Model_DW.is_active_Tick_Timer_AmberINDBl = 1U;
    enter_internal_Tick_Timer_Amb_n();
    App_Model_DW.is_active_Tick_Timer_AmberIND_l = 1U;
    enter_internal_Tick_Timer_Amb_h();
    App_Model_DW.is_active_Tick_Timer_GreenINDBl = 1U;
    enter_internal_Tick_Timer_Gre_o();
  } else {
    if (App_Model_DW.is_active_MainControl != 0U) {
      App_Model_MainControl_g(rtu_Main_InSig, rtu_Main_InSig_g, rtu_Main_InSig_b, rtu_Main_InSig_e, rtu_Main_InSig_gc, rtu_Main_InSig_j, rtu_Main_InSig_n, rtu_Main_InSig_nt, rtu_Main_InSig_p,
        rtu_Main_InSig_k, rtu_Main_InSig_nw, rtu_Main_InSig_n4, rty_MainOut_Sig, rty_MainOut_Sig_g, rty_MainOut_Sig_b, rty_MainOut_Sig_e, rty_MainOut_Sig_gc, rty_MainOut_Sig_j, rty_MainOut_Sig_n,
        rty_MainOut_Sig_nt, rty_MainOut_Sig_p, rty_MainOut_Sig_po, rty_MainOut_Sig_k);
    }

    if (App_Model_DW.is_active_Tick_Timer_PhoneLeft != 0U) {
      App_Mode_Tick_Timer_PhoneLeft_o();
    }

    if (App_Model_DW.is_active_Tick_Timer_PhoneWarni != 0U) {
      Tick_Timer_PhoneWarningCheck_e(rty_MainOut_Sig_n);
    }

    if (App_Model_DW.is_active_Tick_Timer_PhoneRemin != 0U) {
      Tick_Timer_PhoneReminderCheck_h(rty_MainOut_Sig_j);
    }

    if (App_Model_DW.is_active_Tick_Timer_WarningCom != 0U) {
      Ap_Tick_Timer_WarningComplete_i(rty_MainOut_Sig_nt);
    }

    if (App_Model_DW.is_active_Tick_Timer_AmberINDBl != 0U) {
      App_Mo_Tick_Timer_AmberINDBlk_j();
    }

    if (App_Model_DW.is_active_Tick_Timer_AmberIND_l != 0U) {
      App_M_Tick_Timer_AmberINDBlk2_n();
    }

    if (App_Model_DW.is_active_Tick_Timer_GreenINDBl != 0U) {
      App_Mo_Tick_Timer_GreenINDBlk_f();
    }
  }

  /* End of Chart: '<S380>/WPC2_MainControl4_GreenSync_240926' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
